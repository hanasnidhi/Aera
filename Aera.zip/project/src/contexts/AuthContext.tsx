import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { autoGenerateHistoricalSummaries } from '../utils/autoGenerateSummaries';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  created_at: string;
  updated_at: string;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  session: Session | null;
  initialLoading: boolean;
  showSplash: boolean;
  showOnboarding: boolean;
  signUp: (email: string, password: string, name: string) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error: any }>;
  completeSplash: () => void;
  completeOnboarding: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Helper function to add timeout to promises
const withTimeout = <T,>(promise: Promise<T>, timeoutMs: number): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error('Operation timed out')), timeoutMs)
    )
  ]);
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [initialLoading, setInitialLoading] = useState(true);
  const [showSplash, setShowSplash] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);

  // Check if user has completed onboarding
  const checkOnboardingStatus = async (userId: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase
        .from('onboarding_responses')
        .select('id')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error checking onboarding status:', error);
        return false;
      }

      return !!data; // Returns true if onboarding record exists
    } catch (error) {
      console.error('Error checking onboarding status:', error);
      return false;
    }
  };

  useEffect(() => {
    let mounted = true;
    let authSubscription: any = null;

    // Initialize auth state with better error handling
    const initializeAuth = async () => {
      try {
        console.log('Initializing auth...');
        
        // Try to get current session with a shorter timeout and better error handling
        try {
          const sessionPromise = supabase.auth.getSession();
          const { data: { session: currentSession }, error } = await withTimeout(sessionPromise, 3000);
          
          if (!mounted) return;

          if (error) {
            console.warn('Session retrieval error:', error);
            // Continue with null session instead of failing
            setSession(null);
            setUser(null);
            setProfile(null);
          } else {
            console.log('Session retrieved:', !!currentSession);
            setSession(currentSession);
            setUser(currentSession?.user ?? null);
            
            if (currentSession?.user) {
              console.log('Fetching profile for user:', currentSession.user.id);
              // Don't await profile fetch to avoid blocking initialization
              fetchProfile(currentSession.user.id).catch(err => {
                console.warn('Profile fetch failed during init:', err);
              });
            }
          }
        } catch (sessionError) {
          console.warn('Session timeout or error:', sessionError);
          // Continue with null session - don't block the app
          if (mounted) {
            setSession(null);
            setUser(null);
            setProfile(null);
          }
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        // Even if there's an error, we should stop loading
        if (mounted) {
          setSession(null);
          setUser(null);
          setProfile(null);
        }
      } finally {
        if (mounted) {
          console.log('Auth initialization complete, setting loading to false');
          setInitialLoading(false);
        }
      }
    };

    // Set up auth state listener with error handling
    const setupAuthListener = () => {
      try {
        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
          if (!mounted) return;
          
          console.log('Auth state changed:', event, !!session);
          
          setSession(session);
          setUser(session?.user ?? null);
          
          if (session?.user) {
            // Only show splash screen for explicit sign up events and first-time sign ins
            if (event === 'SIGNED_UP') {
              console.log('User performed explicit auth action, showing splash screen');
              setShowSplash(true);
            } else if (event === 'SIGNED_IN') {
              // For sign in, only show splash if it's been more than 24 hours since last session
              const lastActivity = localStorage.getItem('lastActivity');
              const now = Date.now();
              const twentyFourHours = 24 * 60 * 60 * 1000;
              
              if (!lastActivity || (now - parseInt(lastActivity)) > twentyFourHours) {
                console.log('User signed in after long absence, showing splash screen');
                setShowSplash(true);
              } else {
                console.log('User signed in recently, skipping splash screen');
              }
              
              // Update last activity timestamp
              localStorage.setItem('lastActivity', now.toString());
            }
            
            // For new sign ups, immediately check onboarding status
            if (event === 'SIGNED_UP') {
              console.log('New user signed up, checking onboarding status...');
              try {
                const hasCompletedOnboarding = await checkOnboardingStatus(session.user.id);
                console.log('Onboarding completed:', hasCompletedOnboarding);
                if (!hasCompletedOnboarding) {
                  setShowOnboarding(true);
                  console.log('Setting showOnboarding to true');
                }
              } catch (error) {
                console.error('Error checking onboarding status:', error);
                // Default to showing onboarding for new signups if check fails
                setShowOnboarding(true);
                console.log('Error checking onboarding, defaulting to show onboarding');
              }
            }
            
            // Fetch profile (don't await to avoid blocking)
            fetchProfile(session.user.id).then(async () => {
              // Auto-generate historical summaries when user signs in (not for existing sessions)
              if (event === 'SIGNED_IN') {
                console.log('User signed in, auto-generating historical summaries...');
                autoGenerateHistoricalSummaries(session.user.id).catch(err => {
                  console.warn('Auto-generation of historical summaries failed:', err);
                });
              }
            }).catch(err => {
              console.warn('Profile fetch failed during auth change:', err);
            });
            
            // Update activity timestamp for any authenticated session
            if (event !== 'SIGNED_UP' && event !== 'SIGNED_IN') {
              localStorage.setItem('lastActivity', Date.now().toString());
            }
          } else {
            setProfile(null);
            setShowSplash(false);
            setShowOnboarding(false);
            // Clear activity timestamp on sign out
            localStorage.removeItem('lastActivity');
          }
          
          // Ensure loading is false after auth state change
          setInitialLoading(false);
        });
        
        authSubscription = subscription;
      } catch (error) {
        console.error('Error setting up auth listener:', error);
        if (mounted) {
          setInitialLoading(false);
        }
      }
    };

    // Start initialization
    initializeAuth();
    setupAuthListener();

    // Shorter fallback timeout - if loading is still true after 5 seconds, force it to false
    const fallbackTimeout = setTimeout(() => {
      if (mounted && initialLoading) {
        console.warn('Auth initialLoading timeout reached, forcing initialLoading to false');
        setInitialLoading(false);
      }
    }, 5000);

    return () => {
      mounted = false;
      clearTimeout(fallbackTimeout);
      if (authSubscription) {
        authSubscription.unsubscribe();
      }
    };
  }, []);

  const fetchProfile = async (userId: string) => {
    try {
      console.log('Fetching profile for user:', userId);
      
      // Add timeout to profile fetch with shorter duration
      const profilePromise = supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();
        
      const { data, error } = await withTimeout(profilePromise, 5000);

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error);
        return;
      }

      console.log('Profile fetched:', !!data);
      setProfile(data || null);
    } catch (error) {
      console.error('Error fetching profile:', error);
      // Don't throw - just log and continue
    }
  };

  const signUp = async (email: string, password: string, name: string) => {
    try {
      const signUpPromise = supabase.auth.signUp({
        email,
        password,
      });
      
      const { data, error } = await withTimeout(signUpPromise, 15000);

      if (error) {
        return { error };
      }

      // Create profile if user was created
      if (data.user) {
        try {
          const profilePromise = supabase
            .from('user_profiles')
            .insert({
              id: data.user.id,
              name,
              email,
            });
            
          const { error: profileError } = await withTimeout(profilePromise, 10000);

          if (profileError) {
            console.log('Auth initialization complete, setting initialLoading to false');
            return { error: profileError };
          }

          // Set profile immediately
          setProfile({
            id: data.user.id,
            name,
            email,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          });
        } catch (profileError) {
          console.error('Profile creation timeout:', profileError);
          return { error: profileError };
        }
      }

      return { error: null };
    } catch (error) {
      console.error('Sign up timeout:', error);
      return { error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const signInPromise = supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      const { error } = await withTimeout(signInPromise, 15000);
      
      return { error };
    } catch (error) {
      console.error('Sign in timeout:', error);
      return { error };
    }
  };

  const signOut = async () => {
    try {
      // Clear activity timestamp before signing out
      localStorage.removeItem('lastActivity');
      
      const signOutPromise = supabase.auth.signOut();
      await withTimeout(signOutPromise, 5000);
      
      setUser(null);
      setProfile(null);
      setSession(null);
      setShowSplash(false);
      setShowOnboarding(false);
    } catch (error) {
      console.error('Sign out timeout:', error);
      // Force sign out locally even if remote call fails
      setUser(null);
      setProfile(null);
      setSession(null);
      setShowSplash(false);
      setShowOnboarding(false);
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return { error: new Error('No user logged in') };

    try {
      const updatePromise = supabase
        .from('user_profiles')
        .update(updates)
        .eq('id', user.id);
        
      const { error } = await withTimeout(updatePromise, 10000);

      if (!error && profile) {
        setProfile({ ...profile, ...updates });
      }

      return { error };
    } catch (error) {
      console.error('Update profile timeout:', error);
      return { error };
    }
  };

  const completeSplash = () => {
    setShowSplash(false);
  };

  const completeOnboarding = () => {
    setShowOnboarding(false);
  };

  const value = {
    user,
    profile,
    session,
    initialLoading,
    showSplash,
    showOnboarding,
    signUp,
    signIn,
    signOut,
    updateProfile,
    completeSplash,
    completeOnboarding,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};