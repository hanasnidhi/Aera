import React, { useState } from 'react';
import { X, Download, Calendar, FileText, Database, Loader, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import JSZip from 'jszip';

interface DataExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
}

interface ExportOptions {
  startDate: string;
  endDate: string;
  selectAll: boolean;
  format: 'txt' | 'md' | 'json';
}

const DataExportModal: React.FC<DataExportModalProps> = ({ isOpen, onClose, isDarkMode }) => {
  const { user } = useAuth();
  const [options, setOptions] = useState<ExportOptions>({
    startDate: '',
    endDate: '',
    selectAll: true,
    format: 'txt'
  });
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState('');

  // Set default date range when modal opens
  React.useEffect(() => {
    if (isOpen && options.selectAll) {
      const today = new Date();
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(today.getFullYear() - 1);
      
      setOptions(prev => ({
        ...prev,
        startDate: oneYearAgo.toISOString().split('T')[0],
        endDate: today.toISOString().split('T')[0]
      }));
    }
  }, [isOpen]);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget && !isExporting) {
      onClose();
    }
  };

  const handleSelectAllChange = (checked: boolean) => {
    setOptions(prev => ({ ...prev, selectAll: checked }));
  };

  const handleDateChange = (field: 'startDate' | 'endDate', value: string) => {
    setOptions(prev => ({ 
      ...prev, 
      [field]: value,
      selectAll: false 
    }));
  };

  const handleFormatChange = (format: 'txt' | 'md' | 'json') => {
    setOptions(prev => ({ ...prev, format }));
  };

  const formatContent = (content: any, format: 'txt' | 'md' | 'json'): string => {
    if (format === 'json') {
      return JSON.stringify(content, null, 2);
    }
    
    if (format === 'md') {
      if (typeof content === 'string') return content;
      return Object.entries(content)
        .map(([key, value]) => `## ${key}\n\n${value}\n`)
        .join('\n');
    }
    
    // Default to txt format
    if (typeof content === 'string') return content;
    return Object.entries(content)
      .map(([key, value]) => `${key}:\n${value}\n`)
      .join('\n');
  };

  const createZipFile = async (files: { name: string; content: string }[]) => {
    const zip = new JSZip();
    const timestamp = new Date().toISOString().split('T')[0];
    
    // Add files to ZIP with proper folder structure
    files.forEach(file => {
      zip.file(file.name, file.content);
    });

    // Generate ZIP file
    const zipBlob = await zip.generateAsync({ type: "blob" });
    
    // Download the ZIP file
    const url = URL.createObjectURL(zipBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Aera_Export_${timestamp}.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const generateFileName = (type: string, date?: string): string => {
    const extension = options.format;
    if (date) {
      // Format: dd Month, yy (Ex: 25 June, 25)
      const dateObj = new Date(date);
      const day = dateObj.getDate();
      const month = dateObj.toLocaleDateString('en-US', { month: 'long' });
      const year = dateObj.getFullYear().toString().slice(-2);
      return `${day} ${month}, ${year}.${extension}`;
    }
    if (type === 'monthly') {
      // For monthly summaries, date parameter contains "YYYY-Month" format
      const [year, month] = date!.split('-');
      const yearShort = year.slice(-2);
      return `${month} ${yearShort}.${extension}`;
    }
    return `${type.toLowerCase().replace(/\s+/g, '_')}.${extension}`;
  };

  const handleExport = async () => {
    if (!user) return;

    try {
      setIsExporting(true);
      setExportProgress('Fetching your data...');

      const startDate = options.selectAll ? '1900-01-01' : options.startDate;
      const endDate = options.selectAll ? '2100-12-31' : options.endDate;

      // Fetch all data
      const [journalEntries, dimensionSummaries, monthlySummaries, insights] = await Promise.all([
        // Journal entries
        supabase
          .from('journal_entries')
          .select('*')
          .eq('user_id', user.id)
          .eq('entry_type', 'individual')
          .gte('entry_date', startDate)
          .lte('entry_date', endDate)
          .order('entry_date', { ascending: true }),
        
        // Dimension summaries
        supabase
          .from('dimension_summaries')
          .select('*')
          .eq('user_id', user.id)
          .gte('summary_date', startDate)
          .lte('summary_date', endDate)
          .order('summary_date', { ascending: true }),
        
        // Monthly summaries
        supabase
          .from('monthly_summaries')
          .select('*')
          .eq('user_id', user.id)
          .order('year', { ascending: true })
          .order('month', { ascending: true }),
        
        // Insights
        supabase
          .from('insights')
          .select('*')
          .eq('user_id', user.id)
          .order('prominence_score', { ascending: false })
      ]);

      if (journalEntries.error) throw journalEntries.error;
      if (dimensionSummaries.error) throw dimensionSummaries.error;
      if (monthlySummaries.error) throw monthlySummaries.error;
      if (insights.error) throw insights.error;

      setExportProgress('Organizing your journal entries...');

      const files: { name: string; content: string }[] = [];

      // 1. Daily Journals
      const entriesByDate = new Map<string, any[]>();
      journalEntries.data?.forEach(entry => {
        if (!entriesByDate.has(entry.entry_date)) {
          entriesByDate.set(entry.entry_date, []);
        }
        entriesByDate.get(entry.entry_date)!.push(entry);
      });

      const dimensionsByDate = new Map<string, any[]>();
      dimensionSummaries.data?.forEach(summary => {
        if (!dimensionsByDate.has(summary.summary_date)) {
          dimensionsByDate.set(summary.summary_date, []);
        }
        dimensionsByDate.get(summary.summary_date)!.push(summary);
      });

      // Create daily journal files
      for (const [date, entries] of entriesByDate) {
        let content = '';
        
        if (options.format === 'json') {
          const dayData = {
            date,
            entries: entries.map(e => ({
              title: e.title,
              content: e.content,
              word_count: e.word_count,
              duration_ms: e.duration_ms,
              created_at: e.created_at
            })),
            ai_summaries: dimensionsByDate.get(date) || []
          };
          content = JSON.stringify(dayData, null, 2);
        } else if (options.format === 'md') {
          content = `# Journal Entry - ${new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}\n\n`;
          
          entries.forEach((entry, index) => {
            if (entry.title) {
              content += `## ${entry.title}\n\n`;
            }
            content += `${entry.content}\n\n`;
            content += `*Duration: ${Math.floor(entry.duration_ms / 60000)}:${Math.floor((entry.duration_ms % 60000) / 1000).toString().padStart(2, '0')} | Words: ${entry.word_count}*\n\n`;
          });

          const dayDimensions = dimensionsByDate.get(date) || [];
          if (dayDimensions.length > 0) {
            content += `## AI-Generated Insights\n\n`;
            dayDimensions.forEach(dim => {
              content += `### ${dim.dimension}\n${dim.entry}\n\n`;
            });
          }
        } else {
          // txt format
          content = `Journal Entry - ${new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}\n\n`;
          
          entries.forEach((entry, index) => {
            if (entry.title) {
              content += `${entry.title}\n${'='.repeat(entry.title.length)}\n\n`;
            }
            content += `${entry.content}\n\n`;
            content += `Duration: ${Math.floor(entry.duration_ms / 60000)}:${Math.floor((entry.duration_ms % 60000) / 1000).toString().padStart(2, '0')} | Words: ${entry.word_count}\n\n`;
          });

          const dayDimensions = dimensionsByDate.get(date) || [];
          if (dayDimensions.length > 0) {
            content += `AI-Generated Insights\n${'='.repeat(22)}\n\n`;
            dayDimensions.forEach(dim => {
              content += `${dim.dimension}:\n${dim.entry}\n\n`;
            });
          }
        }

        files.push({
          name: `Daily Journals/${generateFileName('daily', date)}`,
          content
        });
      }

      setExportProgress('Compiling monthly summaries...');

      // 2. Monthly Summaries
      const monthlyByPeriod = new Map<string, any[]>();
      monthlySummaries.data?.forEach(summary => {
        const key = `${summary.year}-${summary.month}`;
        if (!monthlyByPeriod.has(key)) {
          monthlyByPeriod.set(key, []);
        }
        monthlyByPeriod.get(key)!.push(summary);
      });

      for (const [period, summaries] of monthlyByPeriod) {
        let content = '';
        
        if (options.format === 'json') {
          content = JSON.stringify({ period, summaries }, null, 2);
        } else if (options.format === 'md') {
          const [year, month] = period.split('-');
          content = `# Monthly Summary - ${month} ${year}\n\n`;
          summaries.forEach(summary => {
            content += `## ${summary.dimension}\n\n${summary.summary}\n\n`;
          });
        } else {
          const [year, month] = period.split('-');
          content = `Monthly Summary - ${month} ${year}\n${'='.repeat(30)}\n\n`;
          summaries.forEach(summary => {
            content += `${summary.dimension}:\n${summary.summary}\n\n`;
          });
        }

        files.push({
          name: `Monthly Summaries/${generateFileName('monthly', period)}`,
          content
        });
      }

      setExportProgress('Preparing insights...');

      // 3. Insights
      if (insights.data && insights.data.length > 0) {
        let content = '';
        
        if (options.format === 'json') {
          content = JSON.stringify(insights.data, null, 2);
        } else if (options.format === 'md') {
          content = `# Your Personal Insights\n\n`;
          content += `*Generated from your journal entries*\n\n`;
          
          insights.data.forEach((insight, index) => {
            content += `## ${insight.title}\n\n`;
            content += `**Prominence Score:** ${insight.prominence_score}%\n\n`;
            content += `${insight.summary}\n\n`;
            
            if (insight.quotes && insight.quotes.length > 0) {
              content += `### Key Quotes\n\n`;
              insight.quotes.forEach(quote => {
                content += `> "${quote}"\n\n`;
              });
            }
            
            content += `*Last updated: ${new Date(insight.last_updated).toLocaleDateString()}*\n\n`;
            if (index < insights.data.length - 1) content += '---\n\n';
          });
        } else {
          content = `Your Personal Insights\n${'='.repeat(23)}\n\n`;
          content += `Generated from your journal entries\n\n`;
          
          insights.data.forEach((insight, index) => {
            content += `${insight.title}\n${'-'.repeat(insight.title.length)}\n\n`;
            content += `Prominence Score: ${insight.prominence_score}%\n\n`;
            content += `${insight.summary}\n\n`;
            
            if (insight.quotes && insight.quotes.length > 0) {
              content += `Key Quotes:\n`;
              insight.quotes.forEach(quote => {
                content += `  "${quote}"\n`;
              });
              content += '\n';
            }
            
            content += `Last updated: ${new Date(insight.last_updated).toLocaleDateString()}\n\n`;
            if (index < insights.data.length - 1) content += '---\n\n';
          });
        }

        files.push({
          name: `Insights/${generateFileName('insights')}`,
          content
        });
      }

      setExportProgress('Downloading your data...');

      // Download all files
      await createZipFile(files);

      setExportProgress('Export completed!');
      
      // Close modal after a short delay
      setTimeout(() => {
        onClose();
        setExportProgress('');
      }, 2000);

    } catch (error) {
      console.error('Error exporting data:', error);
      setExportProgress('Export failed. Please try again.');
      setTimeout(() => setExportProgress(''), 3000);
    } finally {
      setIsExporting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={handleBackdropClick}
    >
      <div className="relative w-full max-w-lg bg-black border border-gray-800/50 rounded-2xl backdrop-blur-md shadow-xl">
        {/* Close button */}
        <button
          onClick={onClose}
          disabled={isExporting}
          className="absolute top-4 right-4 p-1.5 text-gray-400 hover:text-white hover:bg-gray-800/50 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="p-6 border-b border-gray-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
              <Download className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-lg font-adamina font-bold text-white">
                Download My Data
              </h3>
              <p className="text-sm text-gray-400 font-montserrat">
                Export your journal entries, summaries, and insights
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Date Range Selection */}
          <div>
            <label className="block text-sm font-montserrat font-medium text-white mb-3">
              Date Range
            </label>
            
            <div className="space-y-3">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={options.selectAll}
                  onChange={(e) => handleSelectAllChange(e.target.checked)}
                  disabled={isExporting}
                  className="w-4 h-4 text-blue-500 bg-gray-800 border-gray-600 rounded focus:ring-blue-500 focus:ring-2"
                />
                <span className="text-sm font-montserrat text-gray-300">
                  Export all data
                </span>
              </label>
              
              {!options.selectAll && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-montserrat text-gray-400 mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={options.startDate}
                      onChange={(e) => handleDateChange('startDate', e.target.value)}
                      disabled={isExporting}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 text-white rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-montserrat text-gray-400 mb-1">
                      End Date
                    </label>
                    <input
                      type="date"
                      value={options.endDate}
                      onChange={(e) => handleDateChange('endDate', e.target.value)}
                      disabled={isExporting}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 text-white rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* File Format Selection */}
          <div>
            <label className="block text-sm font-montserrat font-medium text-white mb-3">
              File Format
            </label>
            
            <div className="space-y-2">
              {[
                { value: 'txt', label: 'Plain Text (.txt)', desc: 'Lightweight and readable' },
                { value: 'md', label: 'Markdown (.md)', desc: 'Structured with formatting' },
                { value: 'json', label: 'JSON (.json)', desc: 'For importing to other apps' }
              ].map((format) => (
                <label key={format.value} className="flex items-start gap-3 p-3 rounded-lg border border-gray-700/50 hover:border-gray-600/50 transition-colors cursor-pointer">
                  <input
                    type="radio"
                    name="format"
                    value={format.value}
                    checked={options.format === format.value}
                    onChange={(e) => handleFormatChange(e.target.value as 'txt' | 'md' | 'json')}
                    disabled={isExporting}
                    className="w-4 h-4 text-blue-500 bg-gray-800 border-gray-600 focus:ring-blue-500 focus:ring-2 mt-0.5"
                  />
                  <div className="flex-1">
                    <div className="text-sm font-montserrat font-medium text-white">
                      {format.label}
                    </div>
                    <div className="text-xs font-montserrat text-gray-400">
                      {format.desc}
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Export Progress */}
          {exportProgress && (
            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <div className="flex items-center gap-2">
                {exportProgress.includes('completed') ? (
                  <CheckCircle className="w-4 h-4 text-green-400" />
                ) : (
                  <Loader className="w-4 h-4 text-blue-400 animate-spin" />
                )}
                <span className="text-sm font-montserrat text-blue-300">
                  {exportProgress}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-800/50 flex gap-3">
          <button
            onClick={onClose}
            disabled={isExporting}
            className="flex-1 px-4 py-2.5 font-montserrat font-medium rounded-lg transition-all duration-200 text-white hover:bg-gray-700/50 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              backgroundColor: '#07080C',
              borderColor: '#10141B'
            }}
          >
            Cancel
          </button>
          
          <button
            onClick={handleExport}
            disabled={isExporting || (!options.selectAll && (!options.startDate || !options.endDate))}
            className="flex-1 px-4 py-2.5 font-montserrat font-medium rounded-lg transition-all duration-200 text-white disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            style={{ backgroundColor: '#0C93FC' }}
          >
            {isExporting ? (
              <>
                <Loader className="w-4 h-4 animate-spin" />
                Exporting...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Download
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DataExportModal;