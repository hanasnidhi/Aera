import React from 'react';
import { ChevronLeft } from 'lucide-react';

interface PrivacyPolicyProps {
  onBack: () => void;
  isDarkMode: boolean;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onBack, isDarkMode }) => {
  return (
    <div className="w-full max-w-7xl px-4 sm:px-6 pb-8">
      <div className="lg:pl-6">
        {/* Header with back button */}
        <div className="flex items-center gap-3 mb-6">
          <button
            onClick={onBack}
            className={`p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200`}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h1 className={`text-2xl sm:text-3xl font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Privacy Policy
          </h1>
        </div>

        {/* Last updated date */}
        <div className="mb-8">
          <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat`}>
            Last Updated: June 30, 2025
          </p>
        </div>

        {/* Content */}
        <div className={`${isDarkMode ? 'text-gray-200' : 'text-gray-800'} font-montserrat space-y-6 max-w-4xl`}>
          <p className="leading-relaxed">
            Welcome to Āera ("we," "our," or "us"). We are committed to protecting your privacy and ensuring you have a positive experience when using our journal application.
          </p>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Information We Collect
            </h2>
            <p className="leading-relaxed mb-2">
              <span className="font-semibold">Account Information:</span> When you register, we collect your name and email address to create and manage your account.
            </p>
            <p className="leading-relaxed mb-2">
              <span className="font-semibold">Journal Content:</span> We store the journal entries, audio recordings, and photos you create within the app.
            </p>
            <p className="leading-relaxed">
              <span className="font-semibold">Usage Data:</span> We collect information about how you interact with our app, including features used and time spent journaling.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              How We Use Your Information
            </h2>
            <p className="leading-relaxed mb-2">
              <span className="font-semibold">Providing Services:</span> To deliver our journaling features, including AI-powered insights and summaries.
            </p>
            <p className="leading-relaxed mb-2">
              <span className="font-semibold">Personalization:</span> To customize your experience and improve our AI analysis capabilities.
            </p>
            <p className="leading-relaxed">
              <span className="font-semibold">Service Improvement:</span> To understand usage patterns and enhance our features.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Data Security
            </h2>
            <p className="leading-relaxed">
              Your journal entries and personal data are encrypted and stored securely. We implement appropriate technical and organizational measures to protect your information.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Data Sharing
            </h2>
            <p className="leading-relaxed mb-3">
              We do not sell your personal information. Your journal content is private and not shared with third parties except in the following circumstances:
            </p>
            <ul className="list-disc pl-5 space-y-2">
              <li>With service providers who help us deliver our services</li>
              <li>When required by law or to protect our rights</li>
              <li>With your explicit consent</li>
            </ul>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              AI Processing
            </h2>
            <p className="leading-relaxed">
              Our app uses artificial intelligence to analyze your journal entries and generate insights. This processing occurs on secure servers. The AI models are designed to identify patterns and themes in your writing but do not store your content for training purposes.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Your Rights
            </h2>
            <p className="leading-relaxed">
              You have the right to access, correct, or delete your personal information. You can export your data at any time through the app's settings.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Data Retention
            </h2>
            <p className="leading-relaxed">
              We retain your data for as long as your account is active. If you delete your account, your personal information and journal entries will be permanently removed from our systems within 30 days.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Children's Privacy
            </h2>
            <p className="leading-relaxed">
              Our services are not directed to individuals under 16. We do not knowingly collect personal information from children under 16. If we become aware that a child under 16 has provided us with personal information, we will take steps to delete such information.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Changes to This Policy
            </h2>
            <p className="leading-relaxed">
              We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last Updated" date.
            </p>
          </div>

          <div>
            <h2 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3`}>
              Contact Us
            </h2>
            <p className="leading-relaxed">
              If you have any questions about this privacy policy or our data practices, please contact us at privacy@aera-journal.com.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;