import React, { useState } from 'react';
import { Plus, BookOpen, Sparkles, Settings, Sun, Moon, Menu, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  currentView, 
  onViewChange, 
  isDarkMode, 
  onToggleDarkMode,
  isCollapsed,
  setIsCollapsed
}) => {
  const { profile } = useAuth();

  const menuItems = [
    {
      id: 'new-entry',
      label: 'Add Journal',
      icon: Plus,
      isHighlighted: true
    },
    {
      id: 'journals',
      label: 'Journals',
      icon: BookOpen,
      isHighlighted: false
    },
    {
      id: 'insights',
      label: 'Insights',
      icon: Sparkles,
      isHighlighted: false
    },
    {
      id: 'profile',
      label: 'Settings',
      icon: Settings,
      isHighlighted: false
    }
  ];

  // Handle menu item click with auto-close functionality
  const handleMenuItemClick = (itemId: string) => {
    onViewChange(itemId);
    // Auto-close menu on mobile after selection
    if (window.innerWidth < 1024) { // lg breakpoint
      setIsCollapsed(true);
    }
  };

  // Handle menu toggle with proper event handling
  const handleMenuToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    console.log('Menu button clicked, current state:', isCollapsed);
    setIsCollapsed(!isCollapsed);
  };

  return (
    <>
      {/* Mobile Menu Button - Fixed positioning with higher z-index */}
      <button
        onClick={handleMenuToggle}
        className={`fixed ${isCollapsed ? 'top-4 left-4 sm:top-6 sm:left-6' : 'top-4 right-4 sm:top-6 sm:right-6'} lg:hidden p-2 sm:p-3 ${isDarkMode ? 'bg-gray-900/90 border-gray-700/50 text-white hover:bg-gray-800/90' : 'bg-white/95 border-gray-300/60 text-gray-900 hover:bg-gray-100/95'} backdrop-blur-md border rounded-lg transition-all duration-300 shadow-lg z-[60]`}
        style={{ 
          WebkitTapHighlightColor: 'transparent',
          touchAction: 'manipulation'
        }}
      >
        {isCollapsed ? <Menu className="w-4 h-4 sm:w-5 sm:h-5" /> : <X className="w-4 h-4 sm:w-5 sm:h-5" />}
      </button>

      {/* Sidebar - Responsive width and positioning */}
      <div className={`
        fixed left-0 top-0 h-screen backdrop-blur-xl border-r border-gray-800/50 z-50 flex flex-col
        transition-all duration-300 ease-in-out
        ${isCollapsed ? '-translate-x-full lg:translate-x-0' : 'translate-x-0'}
        ${isCollapsed ? 'lg:w-20' : 'w-72 sm:w-80 lg:w-80'}
      `} style={{ backgroundColor: '#000000' }}>
        {/* Header - Responsive padding */}
        <div className="p-4 sm:p-6 border-b border-gray-800/50 flex-shrink-0">
          <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'}`}>
            {!isCollapsed && (
              <h1 className="text-lg sm:text-xl font-adamina text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300 tracking-wide">
                Āera
              </h1>
            )}
            {isCollapsed && (
              <h1 className="text-lg sm:text-xl font-adamina text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300 tracking-wide">
                Ā
              </h1>
            )}
          </div>
          
          {/* Collapse Toggle - Desktop Only */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="hidden lg:block absolute -right-3 top-6 sm:top-8 w-6 h-6 bg-gray-800 border border-gray-700 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full flex items-center justify-center transition-all duration-200 text-xs"
          >
            {isCollapsed ? '→' : '←'}
          </button>
        </div>

        {/* Navigation Menu - Responsive spacing */}
        <nav className="flex-1 p-3 sm:p-4 overflow-y-auto">
          <div className="space-y-1 sm:space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => handleMenuItemClick(item.id)}
                  className={`
                    w-full flex items-center gap-3 px-3 sm:px-4 py-2.5 sm:py-3 rounded-xl transition-all duration-300 group text-sm sm:text-base
                    ${isActive && !item.isHighlighted
                      ? 'text-blue-400'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                    }
                    ${item.isHighlighted
                      ? 'bg-gradient-to-r from-blue-500 to-teal-500 text-white hover:from-blue-600 hover:to-teal-600 shadow-lg shadow-blue-500/25'
                      : ''
                    }
                    ${isCollapsed ? 'justify-center' : ''}
                  `}
                  style={{ 
                    WebkitTapHighlightColor: 'transparent',
                    touchAction: 'manipulation'
                  }}
                >
                  <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${isActive && !item.isHighlighted ? 'text-blue-400' : ''} ${item.isHighlighted ? 'text-white' : ''}`} />
                  {!isCollapsed && (
                    <span className="font-montserrat font-medium">
                      {item.label}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Bottom Section - Responsive spacing */}
        <div className="mt-auto p-3 sm:p-4 border-t border-gray-800/50 space-y-3 sm:space-y-4 flex-shrink-0">
          {/* Bottom section content removed - keeping structure for future additions */}
        </div>
      </div>

      {/* Mobile Overlay - Higher z-index and better touch handling */}
      {!isCollapsed && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsCollapsed(true)}
          style={{ 
            WebkitTapHighlightColor: 'transparent',
            touchAction: 'manipulation'
          }}
        />
      )}
    </>
  );
};

export default Sidebar;