import React, { useState, useEffect } from 'react';
import { User, Mail, Lock, Eye, EyeOff, Save, Trash2, LogOut, AlertTriangle, Check, Edit, Download } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import ConfirmationModal from './ConfirmationModal';
import DataExportModal from './DataExportModal';
import PrivacyPolicy from './PrivacyPolicy';

interface ProfileSettingsProps {
  isDarkMode: boolean;
}

const ProfileSettings: React.FC<ProfileSettingsProps> = ({ isDarkMode }) => {
  const { user, profile, updateProfile, signOut } = useAuth();
  const [formData, setFormData] = useState({
    name: profile?.name || '',
    email: profile?.email || ''
  });
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [loading, setLoading] = useState({
    profile: false,
    password: false,
    delete: false
  });
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [success, setSuccess] = useState<{[key: string]: boolean}>({});
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [editingField, setEditingField] = useState<string | null>(null);
  const [showDataExportModal, setShowDataExportModal] = useState(false);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    itemType: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    itemType: '',
    onConfirm: () => {}
  });

  // Check if password form has any data
  const hasPasswordData = passwordData.currentPassword || passwordData.newPassword || passwordData.confirmPassword;

  useEffect(() => {
    if (profile) {
      setFormData({
        name: profile.name,
        email: profile.email
      });
    }
  }, [profile]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateProfileForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validatePasswordForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!passwordData.currentPassword) {
      newErrors.currentPassword = 'Current password is required';
    }
    
    if (!passwordData.newPassword) {
      newErrors.newPassword = 'New password is required';
    } else if (passwordData.newPassword.length < 6) {
      newErrors.newPassword = 'Password must be at least 6 characters';
    }
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleProfileUpdate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!validateProfileForm()) return;
    
    setLoading(prev => ({ ...prev, profile: true }));
    setErrors({});
    
    try {
      // Update email in Supabase Auth if it changed
      if (formData.email !== profile?.email) {
        const { error: emailError } = await supabase.auth.updateUser({
          email: formData.email
        });
        
        if (emailError) {
          setErrors({ email: emailError.message });
          return;
        }
      }
      
      // Update profile in database
      const { error } = await updateProfile({
        name: formData.name,
        email: formData.email
      });
      
      if (error) {
        setErrors({ general: error.message || 'Failed to update profile' });
      } else {
        setSuccess({ profile: true });
        setEditingField(null); // Exit editing mode
        setTimeout(() => setSuccess({}), 3000);
      }
    } catch (error) {
      setErrors({ general: 'An unexpected error occurred' });
    } finally {
      setLoading(prev => ({ ...prev, profile: false }));
    }
  };

  const handlePasswordUpdate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!validatePasswordForm()) return;
    
    setLoading(prev => ({ ...prev, password: true }));
    setErrors({});
    
    try {
      // First verify current password by attempting to sign in
      const { error: verifyError } = await supabase.auth.signInWithPassword({
        email: profile?.email || '',
        password: passwordData.currentPassword
      });
      
      if (verifyError) {
        setErrors({ currentPassword: 'Current password is incorrect' });
        return;
      }
      
      // Update password
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword
      });
      
      if (error) {
        setErrors({ password: error.message });
      } else {
        setSuccess({ password: true });
        setPasswordData({
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
        setTimeout(() => setSuccess({}), 3000);
      }
    } catch (error) {
      setErrors({ password: 'An unexpected error occurred' });
    } finally {
      setLoading(prev => ({ ...prev, password: false }));
    }
  };

  const handleDeleteAccount = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Delete Account',
      message: 'Your account and all associated data including journal entries, photos, and insights will be permanently deleted.',
      itemType: 'your account',
      onConfirm: confirmDeleteAccount
    });
  };

  const confirmDeleteAccount = async () => {
    setLoading(prev => ({ ...prev, delete: true }));
    setErrors({});
    setConfirmModal(prev => ({ ...prev, isOpen: false }));
    
    try {
      // Delete user data first (this will cascade due to foreign key constraints)
      const { error: profileError } = await supabase
        .from('user_profiles')
        .delete()
        .eq('id', user?.id);
      
      if (profileError) {
        setErrors({ delete: 'Failed to delete account data' });
        return;
      }
      
      // Sign out user (Supabase will handle auth user deletion)
      await signOut();
    } catch (error) {
      setErrors({ delete: 'An unexpected error occurred' });
    } finally {
      setLoading(prev => ({ ...prev, delete: false }));
    }
  };

  const togglePasswordVisibility = (field: 'current' | 'new' | 'confirm') => {
    setShowPasswords(prev => ({
      ...prev,
      [field]: !prev[field]
    }));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const handleFieldEdit = (fieldName: string) => {
    setEditingField(fieldName);
  };

  const handleFieldBlur = (fieldName: string) => {
    // Only exit editing mode if the field is empty or unchanged
    if (fieldName === 'name' && formData.name === profile?.name) {
      setEditingField(null);
    } else if (fieldName === 'email' && formData.email === profile?.email) {
      setEditingField(null);
    }
  };

  // If privacy policy is shown, render that instead
  if (showPrivacyPolicy) {
    return <PrivacyPolicy onBack={() => setShowPrivacyPolicy(false)} isDarkMode={isDarkMode} />;
  }

  return (
    <div className="w-full max-w-7xl px-4 sm:px-6 pb-8">
      {/* Mobile Layout */}
      <div className="block lg:hidden">
        <div className="space-y-6">
          {/* User Header */}
          <div className="flex items-center gap-4 py-6">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center">
              <span className="text-white font-montserrat font-bold text-sm">
                {profile?.name ? getInitials(profile.name) : 'U'}
              </span>
            </div>
            <div>
              <h3 className="text-lg font-adamina font-semibold text-white">
                {profile?.name || 'User'}
              </h3>
              <p className="text-sm text-[#8C8C8C] font-montserrat">
                {profile?.email || 'user@example.com'}
              </p>
            </div>
          </div>

          {/* Basic Information Section */}
          <div>
            <h4 className="text-lg font-adamina font-semibold text-white mb-4">
              Basic Information
            </h4>
            
            <div className="space-y-4">
              {/* Full Name Field */}
              <div>
                <div className="relative">
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    onFocus={() => handleFieldEdit('name')}
                    onBlur={() => handleFieldBlur('name')}
                    className="w-full px-4 pt-8 pb-3 pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg text-sm font-montserrat focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200"
                    placeholder={editingField === 'name' ? "Enter your full name" : ""}
                  />
                  
                  {/* Label and Icon - Show when not editing, positioned below the value */}
                  {editingField !== 'name' && (
                    <div className="absolute left-4 top-3 flex items-center gap-3 pointer-events-none">
                      <User className="w-4 h-4" style={{ color: '#959BA7' }} />
                      <span className="text-xs font-montserrat" style={{ color: '#959BA7' }}>
                        Full Name
                      </span>
                    </div>
                  )}
                  
                  {/* Edit Icon */}
                  <button
                    onClick={() => handleFieldEdit('name')}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
                  >
                    <Edit className="w-4 h-4" style={{ color: '#959BA7' }} />
                  </button>
                </div>
                {errors.name && (
                  <p className="text-red-400 text-xs mt-1">{errors.name}</p>
                )}
              </div>

              {/* Email Address Field */}
              <div>
                <div className="relative">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    onFocus={() => handleFieldEdit('email')}
                    onBlur={() => handleFieldBlur('email')}
                    className="w-full px-4 pt-8 pb-3 pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg text-sm font-montserrat focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200"
                    placeholder={editingField === 'email' ? "Enter your email address" : ""}
                  />
                  
                  {/* Label and Icon - Show when not editing, positioned below the value */}
                  {editingField !== 'email' && (
                    <div className="absolute left-4 top-3 flex items-center gap-3 pointer-events-none">
                      <Mail className="w-4 h-4" style={{ color: '#959BA7' }} />
                      <span className="text-xs font-montserrat" style={{ color: '#959BA7' }}>
                        Email Address
                      </span>
                    </div>
                  )}
                  
                  {/* Edit Icon */}
                  <button
                    onClick={() => handleFieldEdit('email')}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
                  >
                    <Edit className="w-4 h-4" style={{ color: '#959BA7' }} />
                  </button>
                </div>
                {errors.email && (
                  <p className="text-red-400 text-xs mt-1">{errors.email}</p>
                )}
              </div>
            </div>

            {errors.general && (
              <div className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg p-3 mt-4">
                {errors.general}
              </div>
            )}

            {success.profile && (
              <div className="text-green-400 text-sm bg-green-500/10 border border-green-500/20 rounded-lg p-3 flex items-center gap-2 mt-4">
                <Check className="w-4 h-4" />
                Profile updated successfully!
              </div>
            )}
          </div>

          {/* Change Password Section */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-adamina font-semibold text-white">
                Change Password
              </h4>
              <button
                onClick={handlePasswordUpdate}
                disabled={!hasPasswordData || loading.password}
                className={`px-4 py-2 rounded-lg text-sm font-montserrat font-medium transition-all duration-200 ${
                  hasPasswordData && !loading.password
                    ? 'bg-[#0C93FC] text-white hover:bg-[#0C93FC]/90'
                    : 'bg-[#161616] text-[#959BA7] cursor-not-allowed'
                }`}
              >
                {loading.password ? 'Saving...' : 'Save'}
              </button>
            </div>
            
            <div className="space-y-4">
              {/* Current Password */}
              <div className="relative">
                <input
                  type={showPasswords.current ? 'text' : 'password'}
                  name="currentPassword"
                  value={passwordData.currentPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-4 py-3 pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg text-sm font-montserrat focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  placeholder="Enter current password"
                />
                <button
                  type="button"
                  onClick={() => togglePasswordVisibility('current')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
                >
                  {showPasswords.current ? 
                    <EyeOff className="w-4 h-4" style={{ color: '#959BA7' }} /> : 
                    <Eye className="w-4 h-4" style={{ color: '#959BA7' }} />
                  }
                </button>
                {errors.currentPassword && (
                  <p className="text-red-400 text-xs mt-1">{errors.currentPassword}</p>
                )}
              </div>

              {/* New Password */}
              <div className="relative">
                <input
                  type={showPasswords.new ? 'text' : 'password'}
                  name="newPassword"
                  value={passwordData.newPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-4 py-3 pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg text-sm font-montserrat focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  placeholder="Enter new password"
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => togglePasswordVisibility('new')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
                >
                  {showPasswords.new ? 
                    <EyeOff className="w-4 h-4" style={{ color: '#959BA7' }} /> : 
                    <Eye className="w-4 h-4" style={{ color: '#959BA7' }} />
                  }
                </button>
                {errors.newPassword && (
                  <p className="text-red-400 text-xs mt-1">{errors.newPassword}</p>
                )}
              </div>

              {/* Confirm New Password */}
              <div className="relative">
                <input
                  type={showPasswords.confirm ? 'text' : 'password'}
                  name="confirmPassword"
                  value={passwordData.confirmPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-4 py-3 pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg text-sm font-montserrat focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  placeholder="Re-enter new password"
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => togglePasswordVisibility('confirm')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
                >
                  {showPasswords.confirm ? 
                    <EyeOff className="w-4 h-4" style={{ color: '#959BA7' }} /> : 
                    <Eye className="w-4 h-4" style={{ color: '#959BA7' }} />
                  }
                </button>
                {errors.confirmPassword && (
                  <p className="text-red-400 text-xs mt-1">{errors.confirmPassword}</p>
                )}
              </div>
            </div>

            {errors.password && (
              <div className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg p-3 mt-4">
                {errors.password}
              </div>
            )}

            {success.password && (
              <div className="text-green-400 text-sm bg-green-500/10 border border-green-500/20 rounded-lg p-3 flex items-center gap-2 mt-4">
                <Check className="w-4 h-4" />
                Password updated successfully!
              </div>
            )}
          </div>

          {/* Sign Out & Delete Account */}
          <div className="space-y-3 pt-4">
            <button
              onClick={() => setShowDataExportModal(true)}
              className="w-full flex items-center gap-3 px-4 py-3 text-left rounded-lg transition-all duration-200 hover:bg-gray-800/20"
            >
              <Download className="w-4 h-4" style={{ color: '#959BA7' }} />
              <span className="font-montserrat text-white">
                Download My Data
              </span>
            </button>
            
            <button
              onClick={signOut}
              className="w-full flex items-center gap-3 px-4 py-3 text-left rounded-lg transition-all duration-200 hover:bg-gray-800/20"
            >
              <LogOut className="w-4 h-4" style={{ color: '#959BA7' }} />
              <span className="font-montserrat text-white">
                Sign Out
              </span>
            </button>

            {!showDeleteConfirm ? (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full flex items-center gap-3 px-4 py-3 text-left rounded-lg transition-all duration-200 hover:bg-red-500/10"
              >
                <Trash2 className="w-4 h-4 text-red-400" />
                <span className="font-montserrat text-red-400">Delete Account</span>
              </button>
            ) : (
              <div className="space-y-3">
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setShowDeleteConfirm(false);
                      setErrors({});
                    }}
                    className="flex-1 px-3 py-2 text-gray-400 hover:text-white border border-gray-600 hover:border-gray-500 rounded-lg text-sm transition-all duration-200"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteAccount}
                    disabled={loading.delete}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading.delete ? (
                      <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <Trash2 className="w-3 h-3" />
                    )}
                    Continue
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Desktop Layout - Using same premium design */}
      <div className="hidden lg:grid grid-cols-1 xl:grid-cols-12 gap-4 lg:gap-6 h-full">
        {/* Profile Information - 64% width (same as journals calendar) */}
        <div className="xl:col-span-8 overflow-hidden">
          <div className="lg:pl-6 space-y-0">
            
            {/* Profile Header */}
            <div className="py-6 sm:py-8">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-0">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg sm:text-xl font-adamina font-bold text-white">{profile?.name}</h3>
                    <p className="text-sm sm:text-base text-[#8C8C8C] font-montserrat">{profile?.email}</p>
                  </div>
                </div>
                
                {/* Save Changes Button - Top Right for larger screens */}
                <div className="hidden lg:block">
                  <button
                    onClick={handleProfileUpdate}
                    disabled={loading.profile}
                    className="flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 bg-[#0C93FC] text-white font-montserrat font-medium rounded-lg hover:bg-[#0C93FC]/90 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm sm:text-base"
                  >
                    {loading.profile ? (
                      <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <Save className="w-3 h-3 sm:w-4 sm:h-4" />
                    )}
                    {loading.profile ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </div>
            </div>

            {/* Divider */}
            <div className="border-gray-700/30 border-t"></div>

            {/* Basic Information Section */}
            <div className="py-6 sm:py-8">
              <h4 className="text-xl sm:text-xl font-adamina font-bold text-white mb-4 sm:mb-6">Basic Information</h4>
              
              <form onSubmit={handleProfileUpdate} className="space-y-4 sm:space-y-6">
                <div>
                  <div className="relative">
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      onFocus={() => handleFieldEdit('name')}
                      onBlur={() => handleFieldBlur('name')}
                      className="w-full px-4 pt-8 pb-3 pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200 text-sm sm:text-base"
                      placeholder={editingField === 'name' ? "Enter your full name" : ""}
                    />
                    
                    {/* Label and Icon - Show when not editing, positioned below the value */}
                    {editingField !== 'name' && (
                      <div className="absolute left-4 top-3 flex items-center gap-3 pointer-events-none">
                        <User className="w-4 h-4" style={{ color: '#959BA7' }} />
                        <span className="text-xs font-montserrat font-medium" style={{ color: '#959BA7' }}>
                          Full Name
                        </span>
                      </div>
                    )}
                    
                    {/* Edit Icon */}
                    <button
                      type="button"
                      onClick={() => handleFieldEdit('name')}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
                    >
                      <Edit className="w-4 h-4" style={{ color: '#959BA7' }} />
                    </button>
                  </div>
                  {errors.name && (
                    <p className="text-red-400 text-xs sm:text-sm mt-1">{errors.name}</p>
                  )}
                </div>

                <div>
                  <div className="relative">
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      onFocus={() => handleFieldEdit('email')}
                      onBlur={() => handleFieldBlur('email')}
                      className="w-full px-4 pt-8 pb-3 pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200 text-sm sm:text-base"
                      placeholder={editingField === 'email' ? "Enter your email address" : ""}
                    />
                    
                    {/* Label and Icon - Show when not editing, positioned below the value */}
                    {editingField !== 'email' && (
                      <div className="absolute left-4 top-3 flex items-center gap-3 pointer-events-none">
                        <Mail className="w-4 h-4" style={{ color: '#959BA7' }} />
                        <span className="text-xs font-montserrat font-medium" style={{ color: '#959BA7' }}>
                          Email Address
                        </span>
                      </div>
                    )}
                    
                    {/* Edit Icon */}
                    <button
                      type="button"
                      onClick={() => handleFieldEdit('email')}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
                    >
                      <Edit className="w-4 h-4" style={{ color: '#959BA7' }} />
                    </button>
                  </div>
                  {errors.email && (
                    <p className="text-red-400 text-xs sm:text-sm mt-1">{errors.email}</p>
                  )}
                </div>

                {errors.general && (
                  <div className="text-red-400 text-xs sm:text-sm bg-red-500/10 border-red-500/20 border rounded-lg p-3">
                    {errors.general}
                  </div>
                )}

                {success.profile && (
                  <div className="text-green-400 text-xs sm:text-sm bg-green-500/10 border-green-500/20 border rounded-lg p-3 flex items-center gap-2">
                    <Check className="w-3 h-3 sm:w-4 sm:h-4" />
                    Profile updated successfully!
                  </div>
                )}

                {/* Save Changes Button - Mobile only */}
                <div className="lg:hidden">
                  <button
                    type="submit"
                    disabled={loading.profile}
                    className="flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 bg-[#0C93FC] text-white font-montserrat font-medium rounded-lg hover:bg-[#0C93FC]/90 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm sm:text-base"
                  >
                    {loading.profile ? (
                      <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <Save className="w-3 h-3 sm:w-4 sm:h-4" />
                    )}
                    {loading.profile ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            </div>

            {/* Divider */}
            <div className="border-gray-700/30 border-t"></div>

            {/* Password Change Section */}
            <div className="py-6 sm:py-8">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0 mb-4 sm:mb-6">
                <div className="flex items-center gap-2 sm:gap-3">
                  <Lock className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: '#959BA7' }} />
                  <h4 className="text-xl sm:text-xl font-adamina font-bold text-white">Change Password</h4>
                </div>
                
                {/* Update Password Button - Top Right for larger screens */}
                <div className="hidden lg:block">
                  <button
                    onClick={handlePasswordUpdate}
                    disabled={!hasPasswordData || loading.password}
                    className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 font-montserrat font-medium rounded-lg transition-all duration-300 disabled:cursor-not-allowed text-sm sm:text-base ${
                      hasPasswordData && !loading.password
                        ? 'bg-[#0C93FC] text-white hover:bg-[#0C93FC]/90'
                        : 'bg-[#161616] text-[#959BA7]'
                    }`}
                  >
                    {loading.password ? (
                      <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <Lock className="w-3 h-3 sm:w-4 sm:h-4" />
                    )}
                    {loading.password ? 'Updating...' : 'Save'}
                  </button>
                </div>
              </div>

              <form onSubmit={handlePasswordUpdate} className="space-y-4 sm:space-y-6">
                <div>
                  <label className="block text-sm font-montserrat font-medium text-white mb-2">Current Password</label>
                  <div className="relative">
                    <input
                      type={showPasswords.current ? 'text' : 'password'}
                      name="currentPassword"
                      value={passwordData.currentPassword}
                      onChange={handlePasswordChange}
                      className="w-full px-3 sm:px-4 py-2.5 sm:py-3 pr-10 sm:pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200 text-sm sm:text-base"
                      placeholder="Enter current password"
                    />
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility('current')}
                      className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2"
                    >
                      {showPasswords.current ? <EyeOff className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#959BA7' }} /> : <Eye className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#959BA7' }} />}
                    </button>
                  </div>
                  {errors.currentPassword && (
                    <p className="text-red-400 text-xs sm:text-sm mt-1">{errors.currentPassword}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-montserrat font-medium text-white mb-2">New Password</label>
                  <div className="relative">
                    <input
                      type={showPasswords.new ? 'text' : 'password'}
                      name="newPassword"
                      value={passwordData.newPassword}
                      onChange={handlePasswordChange}
                      className="w-full px-3 sm:px-4 py-2.5 sm:py-3 pr-10 sm:pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200 text-sm sm:text-base"
                      placeholder="Enter new password"
                      minLength={6}
                    />
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility('new')}
                      className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2"
                    >
                      {showPasswords.new ? <EyeOff className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#959BA7' }} /> : <Eye className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#959BA7' }} />}
                    </button>
                  </div>
                  {errors.newPassword && (
                    <p className="text-red-400 text-xs sm:text-sm mt-1">{errors.newPassword}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-montserrat font-medium text-white mb-2">Confirm New Password</label>
                  <div className="relative">
                    <input
                      type={showPasswords.confirm ? 'text' : 'password'}
                      name="confirmPassword"
                      value={passwordData.confirmPassword}
                      onChange={handlePasswordChange}
                      className="w-full px-3 sm:px-4 py-2.5 sm:py-3 pr-10 sm:pr-12 bg-[#07080C] border border-[#10141B] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all duration-200 text-sm sm:text-base"
                      placeholder="Confirm new password"
                      minLength={6}
                    />
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility('confirm')}
                      className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2"
                    >
                      {showPasswords.confirm ? <EyeOff className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#959BA7' }} /> : <Eye className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#959BA7' }} />}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-red-400 text-xs sm:text-sm mt-1">{errors.confirmPassword}</p>
                  )}
                </div>

                {errors.password && (
                  <div className="text-red-400 text-xs sm:text-sm bg-red-500/10 border-red-500/20 border rounded-lg p-3">
                    {errors.password}
                  </div>
                )}

                {success.password && (
                  <div className="text-green-400 text-xs sm:text-sm bg-green-500/10 border-green-500/20 border rounded-lg p-3 flex items-center gap-2">
                    <Check className="w-3 h-3 sm:w-4 sm:h-4" />
                    Password updated successfully!
                  </div>
                )}

                {/* Update Password Button - Mobile only */}
                <div className="lg:hidden">
                  <button
                    type="submit"
                    disabled={!hasPasswordData || loading.password}
                    className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 font-montserrat font-medium rounded-lg transition-all duration-300 disabled:cursor-not-allowed text-sm sm:text-base ${
                      hasPasswordData && !loading.password
                        ? 'bg-[#0C93FC] text-white hover:bg-[#0C93FC]/90'
                        : 'bg-[#161616] text-[#959BA7]'
                    }`}
                  >
                    {loading.password ? (
                      <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <Lock className="w-3 h-3 sm:w-4 sm:h-4" />
                    )}
                    {loading.password ? 'Updating...' : 'Save'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* Account Actions - 36% width (same as journals right column) */}
        <div className="xl:col-span-4 mt-3 xl:mt-0">
          <div className="space-y-3 sm:space-y-4">
            {/* Account Stats */}
            <div className="py-6 sm:py-8">
              <h4 className="text-xl sm:text-xl font-adamina font-bold text-white mb-4 sm:mb-6">Account Info</h4>
              
              <div className="space-y-3 sm:space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-white text-sm font-montserrat font-medium">Member Since</span>
                  <span className="text-[#8C8C8C] text-sm font-montserrat">
                    {profile?.created_at ? formatDate(profile.created_at) : 'N/A'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white text-sm font-montserrat font-medium">Last Updated</span>
                  <span className="text-[#8C8C8C] text-sm font-montserrat">
                    {profile?.updated_at ? formatDate(profile.updated_at) : 'N/A'}
                  </span>
                </div>
              </div>
            </div>

            {/* Divider */}
            <div className="border-gray-700/30 border-t"></div>

            {/* Quick Actions */}
            <div className="py-6 sm:py-8">
              <h4 className="text-xl sm:text-xl font-adamina font-bold text-white mb-4 sm:mb-6">Quick Actions</h4>
              
              <div className="space-y-2 sm:space-y-3">
                <button
                  onClick={() => setShowDataExportModal(true)}
                  className="w-full flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3 text-white hover:bg-gray-800/50 rounded-lg transition-all duration-200 text-sm sm:text-base"
                >
                  <Download className="w-3 h-3 sm:w-4 sm:h-4" style={{ color: '#959BA7' }} />
                  <span className="font-montserrat font-medium">Download My Data</span>
                </button>
                
                <button
                  onClick={() => setShowPrivacyPolicy(true)}
                  className="w-full flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3 text-white hover:bg-gray-800/50 rounded-lg transition-all duration-200 text-sm sm:text-base"
                >
                  <Lock className="w-3 h-3 sm:w-4 sm:h-4" style={{ color: '#959BA7' }} />
                  <span className="font-montserrat font-medium">Privacy Policy</span>
                </button>
                
                <button
                  onClick={signOut}
                  className="w-full flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3 text-white hover:bg-gray-800/50 rounded-lg transition-all duration-200 text-sm sm:text-base"
                >
                  <LogOut className="w-3 h-3 sm:w-4 sm:h-4" style={{ color: '#959BA7' }} />
                  <span className="font-montserrat font-medium">Sign Out</span>
                </button>
              </div>
            </div>

            {/* Divider */}
            <div className="border-gray-700/30 border-t"></div>

            {/* Danger Zone */}
            <div className="py-6 sm:py-8">
              <div className="flex items-center gap-2 mb-4 sm:mb-6">
                <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-red-400" />
                <h4 className="text-xl sm:text-xl font-adamina font-bold text-red-400">Danger Zone</h4>
              </div>
              
              <p className="text-xs sm:text-sm text-[#8C8C8C] font-montserrat mb-4 sm:mb-6">
                Once you delete your account, there is no going back. This will permanently delete all your journal entries and data.
              </p>
              
              {!showDeleteConfirm ? (
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="w-full flex items-center justify-center gap-2 px-3 sm:px-4 py-2.5 sm:py-3 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 hover:border-red-500/50 text-red-400 hover:text-red-300 font-montserrat font-medium rounded-lg transition-all duration-200 text-sm sm:text-base"
                >
                  <Trash2 className="w-3 h-3 sm:w-4 sm:h-4" />
                  Delete Account
                </button>
              ) : (
                <div className="space-y-2 sm:space-y-3">
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setShowDeleteConfirm(false);
                        setErrors({});
                      }}
                      className="flex-1 px-2.5 sm:px-3 py-2 text-gray-400 hover:text-white border border-gray-600 hover:border-gray-500 rounded-lg text-xs sm:text-sm transition-all duration-200"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleDeleteAccount}
                      disabled={loading.delete}
                      className="flex-1 flex items-center justify-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-xs sm:text-sm transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {loading.delete ? (
                        <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      ) : (
                        <Trash2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                      )}
                      Continue
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        itemType={confirmModal.itemType}
        isLoading={loading.delete}
        isDarkMode={isDarkMode}
      />
      
      {/* Data Export Modal */}
      <DataExportModal
        isOpen={showDataExportModal}
        onClose={() => setShowDataExportModal(false)}
        isDarkMode={isDarkMode}
      />
    </div>
  );
};

export default ProfileSettings;