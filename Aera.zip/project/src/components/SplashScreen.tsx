import React, { useState, useEffect } from 'react';

interface SplashScreenProps {
  isVisible: boolean;
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ isVisible, onComplete }) => {
  const [firstLineText, setFirstLineText] = useState('');
  const [secondLineText, setSecondLineText] = useState('');
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [showSecondLine, setShowSecondLine] = useState(false);
  const [isEnding, setIsEnding] = useState(false);
  
  const firstLine = "You cannot add days to your life,";
  const secondLine = "but you can add life to your days";
  const appearanceSpeed = 80; // milliseconds per character
  const pauseBetweenLines = 1000; // 1 second pause between lines
  const pauseAfterAnimation = 3000; // 3 seconds after animation ends
  const fadeOutDuration = 1000; // 1 second fade out

  useEffect(() => {
    if (!isVisible) {
      // Reset all state when splash screen is hidden
      setFirstLineText('');
      setSecondLineText('');
      setCurrentLineIndex(0);
      setCurrentCharIndex(0);
      setShowSecondLine(false);
      setIsEnding(false);
      return;
    }

    // First line letter appearance
    if (currentLineIndex === 0 && currentCharIndex < firstLine.length) {
      const timer = setTimeout(() => {
        setFirstLineText(prev => prev + firstLine[currentCharIndex]);
        setCurrentCharIndex(prev => prev + 1);
      }, appearanceSpeed);

      return () => clearTimeout(timer);
    }
    
    // Pause after first line, then start second line
    if (currentLineIndex === 0 && currentCharIndex === firstLine.length) {
      const pauseTimer = setTimeout(() => {
        setShowSecondLine(true);
        setCurrentLineIndex(1);
        setCurrentCharIndex(0);
      }, pauseBetweenLines);

      return () => clearTimeout(pauseTimer);
    }

    // Second line letter appearance
    if (currentLineIndex === 1 && currentCharIndex < secondLine.length) {
      const timer = setTimeout(() => {
        setSecondLineText(prev => prev + secondLine[currentCharIndex]);
        setCurrentCharIndex(prev => prev + 1);
      }, appearanceSpeed);

      return () => clearTimeout(timer);
    }

    // Animation complete, wait 3 seconds then start fade out
    if (currentLineIndex === 1 && currentCharIndex === secondLine.length && !isEnding) {
      const completeTimer = setTimeout(() => {
        setIsEnding(true);
        
        // After fade out duration, call onComplete
        setTimeout(() => {
          onComplete();
        }, fadeOutDuration);
      }, pauseAfterAnimation);

      return () => clearTimeout(completeTimer);
    }
  }, [currentLineIndex, currentCharIndex, isVisible, isEnding, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black z-[100] flex items-center justify-center px-6">
      {/* Letter Appearance Text with Fade Out Effect */}
      <div 
        className={`text-center max-w-4xl transition-all duration-1000 ease-out ${
          isEnding 
            ? 'opacity-0 blur-md scale-95' 
            : 'opacity-100 blur-0 scale-100'
        }`}
      >
        <div className="space-y-2 sm:space-y-4">
          {/* First Line - 25% smaller text */}
          <p className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-adamina italic text-white leading-relaxed tracking-wide">
            {firstLineText.split('').map((char, index) => (
              <span
                key={index}
                className="inline-block animate-in fade-in duration-300"
                style={{
                  animationDelay: `${index * 80}ms`,
                  animationFillMode: 'both'
                }}
              >
                {char === ' ' ? '\u00A0' : char}
              </span>
            ))}
          </p>
          
          {/* Second Line - 25% smaller text */}
          {showSecondLine && (
            <p className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-adamina italic text-white leading-relaxed tracking-wide">
              {secondLineText.split('').map((char, index) => (
                <span
                  key={index}
                  className="inline-block animate-in fade-in duration-300"
                  style={{
                    animationDelay: `${index * 80}ms`,
                    animationFillMode: 'both'
                  }}
                >
                  {char === ' ' ? '\u00A0' : char}
                </span>
              ))}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;