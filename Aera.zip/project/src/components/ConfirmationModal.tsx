import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  itemType: string;
  isLoading?: boolean;
  isDarkMode?: boolean;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  itemType,
  isLoading = false,
  isDarkMode = false
}) => {
  if (!isOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={handleBackdropClick}
    >
      <div className={`
        relative w-full max-w-md rounded-2xl border shadow-xl
        bg-black border-gray-800/50
        backdrop-blur-md
      `}>
        {/* Close button */}
        <button
          onClick={onClose}
          disabled={isLoading}
          className={`
            absolute top-4 right-4 p-1.5 rounded-lg transition-all duration-200
            text-gray-400 hover:text-white hover:bg-gray-800/50
            disabled:opacity-50 disabled:cursor-not-allowed
          `}
        >
          <X className="w-4 h-4" />
        </button>

        {/* Content */}
        <div className="p-6">
          {/* Icon and Title */}
          <div className="flex items-center gap-3 mb-4">
            <div className={`
              w-10 h-10 rounded-full flex items-center justify-center
              bg-red-500/20
            `}>
              <AlertTriangle className="w-5 h-5 text-red-400" />
            </div>
            <h3 className="text-lg font-adamina font-bold text-white">
              {title}
            </h3>
          </div>

          {/* Warning Message */}
          <div className="mb-6">
            <p className="font-montserrat mb-3 text-gray-200">
              Are you sure you want to delete {itemType}?
            </p>
            <p className="font-montserrat text-sm text-gray-400">
              {message}
            </p>
            <p className="font-montserrat text-sm font-medium mt-2 text-red-400">
              This action cannot be undone.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            {/* Primary Cancel Button */}
            <button
              onClick={onClose}
              disabled={isLoading}
              className={`
                flex-1 px-4 py-2.5 font-montserrat font-medium rounded-lg transition-all duration-200
                text-white hover:bg-gray-700/50
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
              style={{
                backgroundColor: '#07080C',
                borderColor: '#10141B'
              }}
            >
              Cancel
            </button>

            {/* Secondary Delete Button */}
            <button
              onClick={onConfirm}
              disabled={isLoading}
              className={`
                flex-1 px-4 py-2.5 font-montserrat font-medium rounded-lg transition-all duration-200
                bg-red-500 text-white hover:bg-red-600 border border-red-500
                disabled:opacity-50 disabled:cursor-not-allowed
                flex items-center justify-center gap-2
              `}
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;