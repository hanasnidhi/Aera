import React, { useState, useEffect, useRef } from 'react';
import { Save, Calendar, Clock, Hash, X, Edit3, Camera } from 'lucide-react';
import PhotoUpload, { PhotoUpload as PhotoUploadType } from './PhotoUpload';
import { uploadPhotos, initializeStorage } from '../lib/storage';

interface JournalEditorProps {
  transcript: string;
  duration: number;
  wordCount: number;
  userId: string;
  onSave: (content: string, title?: string, photoUrls?: string[]) => Promise<void>;
  onCancel: () => void;
  isVisible: boolean;
  isSidebarCollapsed: boolean;
  isDarkMode: boolean;
}

const JournalEditor: React.FC<JournalEditorProps> = ({
  transcript,
  duration,
  wordCount,
  userId,
  onSave,
  onCancel,
  isVisible,
  isSidebarCollapsed,
  isDarkMode
}) => {
  const [content, setContent] = useState(transcript);
  const [title, setTitle] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [currentWordCount, setCurrentWordCount] = useState(wordCount);
  const [photos, setPhotos] = useState<PhotoUploadType[]>([]);
  const [uploadingPhotos, setUploadingPhotos] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const titleRef = useRef<HTMLInputElement>(null);

  // Update content when transcript changes
  useEffect(() => {
    console.log('JournalEditor: transcript prop received:', transcript);
    console.log('JournalEditor: transcript length:', transcript?.length || 0);
    setContent(transcript);
  }, [transcript]);

  // Update word count when content changes
  useEffect(() => {
    const words = content.trim().split(/\s+/).filter(word => word.length > 0);
    setCurrentWordCount(words.length);
  }, [content]);

  // Auto-focus the textarea when editor opens
  useEffect(() => {
    if (isVisible) {
      // Initialize storage when editor opens
      initializeStorage();
      // Focus title input first when editor opens
      if (titleRef.current) {
        titleRef.current.focus();
      }
    }
  }, [isVisible]);

  const formatDuration = (ms: number): string => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleSave = async () => {
    if (!content.trim()) return;
    
    console.log('Saving journal entry with content:', content);
    console.log('Content length:', content.length);
    console.log('Photos to upload:', photos.length);
    
    setIsSaving(true);
    setUploadingPhotos(true);
    
    try {
      let photoUrls: string[] = [];
      
      // Upload photos if any
      if (photos.length > 0) {
        const today = new Date().toLocaleDateString('en-CA');
        const savedPhotos = await uploadPhotos(userId, photos, today);
        photoUrls = savedPhotos.map(photo => photo.url);
        console.log('Photos uploaded:', photoUrls);
      }
      
      await onSave(content.trim(), title.trim() || undefined, photoUrls);
      console.log('Journal entry saved successfully');
    } finally {
      setIsSaving(false);
      setUploadingPhotos(false);
    }
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  const handlePhotosChange = (newPhotos: PhotoUploadType[]) => {
    setPhotos(newPhotos);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && textareaRef.current) {
      e.preventDefault();
      textareaRef.current.focus();
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Header with Close/Cancel Button */}
      <div className={`${isDarkMode ? 'border-gray-800/50' : 'border-gray-200/50'} border-b px-4 sm:px-6 py-4 sm:py-6 flex justify-between items-center`}>
        <div className="flex items-center">
          <button
            onClick={onCancel}
            className={`flex items-center gap-2 ${isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'} transition-colors duration-200`}
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="font-montserrat text-sm sm:text-base">Cancel</span>
          </button>
        </div>
        <h3 className={`text-lg font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
          Edit Entry
        </h3>
        <div className="w-24">
          {/* Empty div for spacing */}
        </div>
      </div>

      {/* Title Input Section */}
      <div className={`${isDarkMode ? 'border-gray-800/50' : 'border-gray-200/50'} border-b px-4 sm:px-6 py-4 sm:py-6`}>
        <input
          ref={titleRef}
          type="text"
          value={title}
          onChange={handleTitleChange}
          onKeyDown={handleKeyDown}
          placeholder="Give your entry a title..."
          className={`w-full bg-transparent ${isDarkMode ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-500'} focus:outline-none font-adamina text-lg sm:text-xl tracking-wide border-none`}
          maxLength={100}
        />
      </div>

      {/* Transcript Content */}
      <div className="flex-1 relative overflow-hidden">
        {/* Content Editor */}
        <div className="relative p-4 sm:p-6 h-full">
          <div className="relative flex flex-col justify-start flex-1 h-full">
            <textarea
              ref={textareaRef}
              value={content}
              onChange={handleContentChange}
              placeholder="Your transcription will appear here..."
              className={`w-full h-full bg-transparent ${isDarkMode ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-500'} focus:outline-none resize-none font-montserrat text-base sm:text-lg leading-relaxed tracking-wide`}
              style={{
                textShadow: isDarkMode ? '0 0 20px rgba(255, 255, 255, 0.1)' : '0 0 20px rgba(0, 0, 0, 0.05)'
              }}
            />
          </div>
        </div>
      </div>

      {/* Stats Bar - Fixed at bottom */}
      <div className={`px-4 sm:px-6 py-3 sm:py-4 ${isDarkMode ? 'bg-gray-900/30 border-gray-800/50' : 'bg-white/90 border-gray-200/50'} border-t z-50`}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
          {/* Stats */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-6">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Calendar className={`w-3 h-3 sm:w-4 sm:h-4 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              <span className={`text-xs sm:text-sm font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                {formatDate(new Date())}
              </span>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Clock className={`w-3 h-3 sm:w-4 sm:h-4 ${isDarkMode ? 'text-green-400' : 'text-green-600'}`} />
              <span className={`text-xs sm:text-sm font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                {new Date().toLocaleTimeString('en-US', { 
                  hour: '2-digit', 
                  minute: '2-digit',
                  hour12: true 
                })}
              </span>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Clock className={`w-3 h-3 sm:w-4 sm:h-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <span className={`text-xs sm:text-sm font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                {formatDuration(duration)}
              </span>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Hash className={`w-3 h-3 sm:w-4 sm:h-4 ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`} />
              <span className={`text-xs sm:text-sm font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                {currentWordCount} {currentWordCount === 1 ? 'word' : 'words'}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto">
            {/* Save Button */}
            <button
              onClick={handleSave}
              disabled={!content.trim() || isSaving || uploadingPhotos}
              className="flex-1 sm:flex-none px-4 sm:px-6 py-2 sm:py-3 text-white font-montserrat font-medium rounded-lg transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none bg-blue-500 hover:bg-blue-600 text-sm sm:text-base min-h-[44px] flex items-center justify-center"
            >
              {isSaving || uploadingPhotos ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  {uploadingPhotos ? 'Uploading...' : 'Saving...'}
                </div>
              ) : (
                'Save Entry'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JournalEditor;