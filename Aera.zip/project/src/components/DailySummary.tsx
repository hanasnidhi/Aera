import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Clock, Hash, Calendar, ChevronLeft, BookOpen, Save, Brain, Loader, Target, Heart, Lightbulb, Eye, Users, Star, AlertCircle } from 'lucide-react';
import { supabase, getDimensionSummariesForDate, analyzeDailySummary } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import PhotoGallery from './PhotoGallery';
import { getPhotosForDate } from '../lib/storage';

interface JournalEntry {
  id: string;
  title: string | null;
  content: string;
  entry_date: string;
  duration_ms: number;
  word_count: number;
  created_at: string;
  updated_at: string;
  photos?: string[];
}

interface DimensionSummary {
  id: string;
  dimension: string;
  entry: string;
  created_at: string;
  updated_at: string;
}

interface DailySummaryProps {
  date: Date;
  onBack: () => void;
  isDarkMode: boolean;
}

const DailySummary: React.FC<DailySummaryProps> = ({ date, onBack, isDarkMode }) => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [dimensionSummaries, setDimensionSummaries] = useState<DimensionSummary[]>([]);
  const [photos, setPhotos] = useState<string[]>([]);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [generatingSummary, setGeneratingSummary] = useState(false);
  const [expandedEntry, setExpandedEntry] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'summary' | 'transcripts'>('summary');
  
  // New state for emotions and summary content
  const [dominantEmotion, setDominantEmotion] = useState<string | null>(null);
  const [summaryContent, setSummaryContent] = useState<string | null>(null);

  // Dimension icons mapping
  const dimensionIcons: { [key: string]: React.ComponentType<any> } = {
    'Achievement': Target,
    'Introspection': Brain,
    'Memories': Heart,
    'Little Things': Eye,
    'Connections': Users,
    'Major life event': Star
  };

  // Dimension colors mapping
  const dimensionColors: { [key: string]: string } = {
    'Achievement': '#2FA7C6',
    'Introspection': '#0C93FC',
    'Memories': '#93A7F1',
    'Little Things': '#08B5A8',
    'Connections': '#8D51DA',
    'Major life event': '#FFD700'
  };

  // Emotion icons mapping
  const emotionIcons: { [key: string]: string } = {
    'Excitement': '/icons/Excitement.png',
    'Joy': '/icons/Joy.png',
    'Contentment': '/icons/Contentment.png',
    'Pride': '/icons/Pride.png',
    'Sad': '/icons/Sadness.png',
    'Anxiety': '/icons/Anxiety.png',
    'Inadequacy': '/icons/Inadequacy.png',
    'Regret': '/icons/Regret.png',
    'Anger': '/icons/Anger.png',
    'Emptiness': '/icons/Emptiness.png',
    'Restless': '/icons/Restlessness.png',
    'Overwhelm': '/icons/Overwhelm.png'
  };

  // Emotion colors mapping
  const emotionColors: { [key: string]: string } = {
    'Excitement': '#FFD700',
    'Joy': '#32CD32',
    'Contentment': '#87CEEB',
    'Pride': '#FF6347',
    'Sad': '#4682B4',
    'Anxiety': '#FF4500',
    'Inadequacy': '#8B4513',
    'Regret': '#9370DB',
    'Anger': '#DC143C',
    'Emptiness': '#696969',
    'Restless': '#20B2AA',
    'Overwhelm': '#4169E1'
  };

  // Component to render glow sphere
  const GlowSphere: React.FC<{ color: string; size?: 'sm' | 'md' }> = ({ color, size = 'md' }) => {
    const sizeClasses = size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';
    
    return (
      <div className="relative flex items-center justify-center">
        {/* Background glow layers */}
        <div 
          className={`absolute inset-0 ${sizeClasses} rounded-full animate-pulse`}
          style={{
            background: `radial-gradient(circle, ${color}40, transparent 70%)`,
            filter: 'blur(4px)',
            animationDuration: '3s'
          }}
        />
        <div 
          className={`absolute inset-0 ${sizeClasses} rounded-full animate-pulse`}
          style={{
            background: `radial-gradient(circle, ${color}30, transparent 60%)`,
            filter: 'blur(6px)',
            animationDuration: '4s',
            animationDelay: '0.5s'
          }}
        />
        
        {/* Main sphere */}
        <div 
          className={`${sizeClasses} rounded-full relative z-10 ${isDarkMode ? 'bg-black' : 'bg-gray-900'}`}
          style={{
            boxShadow: `0 0 15px ${color}60, inset 0 0 8px rgba(0, 0, 0, 0.3)`
          }}
        />
      </div>
    );
  };

  useEffect(() => {
    if (user) {
      fetchDataForDate();
    }
  }, [user, date, isDarkMode]);

  const fetchDataForDate = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setPhotoError(null); // Reset photo error state
      const dateString = date.toLocaleDateString('en-CA'); // Format as YYYY-MM-DD in local timezone
      
      // Fetch journal entries
      const { data: entriesData, error: entriesError } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('user_id', user.id)
        .eq('entry_date', dateString)
        .eq('entry_type', 'individual')
        .order('created_at', { ascending: true });

      if (entriesError) {
        console.error('Error fetching entries for date:', entriesError);
      } else {
        setEntries(entriesData || []);
      }

      // Fetch dimension summaries
      const { data: dimensionData, error: dimensionError } = await getDimensionSummariesForDate(user.id, dateString);
      
      if (dimensionError && dimensionError.code !== 'PGRST116') {
        console.error('Error fetching dimension summaries for date:', dimensionError);
      } else {
        setDimensionSummaries(dimensionData || []);
      }

      // Fetch summary with emotions - renamed error variable to avoid conflict
      const { data: summaryData, error: summaryFetchError } = await supabase
        .from('summaries')
        .select('*')
        .eq('user_id', user.id)
        .eq('summary_date', dateString)
        .single();

      if (summaryFetchError && summaryFetchError.code !== 'PGRST116') {
        console.error('Error fetching summary for date:', summaryFetchError);
      } else if (summaryData) {
        setSummaryContent(summaryData.content);
        
        // Extract dominant emotion
        if (summaryData.emotions && summaryData.emotions.length > 0) {
          setDominantEmotion(summaryData.emotions[0].emotion);
        } else {
          setDominantEmotion(null);
        }
      } else {
        setSummaryContent(null);
        setDominantEmotion(null);
      }

      // Fetch photos for this date
      try {
        const photosForDate = await getPhotosForDate(user.id, dateString);
        setPhotos(photosForDate);
      } catch (photoFetchError) {
        console.error('Error fetching photos for date:', photoFetchError);
        setPhotoError('Unable to load photos. Please check your connection and try again.');
        setPhotos([]); // Set empty array as fallback
      }

    } catch (error) {
      console.error('Error fetching data for date:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateSummary = async () => {
    if (!user || entries.length === 0) return;

    try {
      setGeneratingSummary(true);
      const dateString = date.toLocaleDateString('en-CA');
      
      const result = await analyzeDailySummary(user.id, dateString);
      
      if (result.dimensions) {
        // Refresh the dimension summaries data
        await fetchDataForDate();
      }
      
    } catch (error) {
      console.error('Error generating summary:', error);
    } finally {
      setGeneratingSummary(false);
    }
  };

  // Generate a very specific heading for each dimension based on its content
  const generateDimensionHeading = (dimension: string, entry: string): string => {
    // Extract key phrases and specific details from the entry
    const content = entry.toLowerCase();
    const originalEntry = entry; // Keep original case for extraction
    
    // Helper function to extract specific mentions
    const extractSpecificMentions = (text: string, keywords: string[]): string[] => {
      const mentions = [];
      for (const keyword of keywords) {
        if (text.toLowerCase().includes(keyword.toLowerCase())) {
          // Try to extract the context around the keyword
          const regex = new RegExp(`([^.!?]*${keyword.toLowerCase()}[^.!?]*)`, 'i');
          const match = text.match(regex);
          if (match) {
            mentions.push(match[1].trim());
          }
        }
      }
      return mentions;
    };

    // Helper function to extract proper nouns and specific details
    const extractSpecificDetails = (text: string): string[] => {
      // Look for capitalized words that might be specific names, places, technologies
      const words = text.split(/\s+/);
      const specificDetails = [];
      
      for (let i = 0; i < words.length; i++) {
        const word = words[i];
        // Check for capitalized words (but not sentence starters)
        if (word.length > 2 && /^[A-Z][a-z]/.test(word) && i > 0) {
          // Check if it's likely a proper noun or specific term
          if (!['The', 'This', 'That', 'When', 'Where', 'How', 'Why', 'What', 'Who'].includes(word)) {
            specificDetails.push(word);
          }
        }
        
        // Look for technology/tool mentions
        if (/\b(app|application|website|platform|tool|software|code|coding|programming|development|project)\b/i.test(word)) {
          // Get surrounding context
          const context = words.slice(Math.max(0, i-3), i+4).join(' ');
          specificDetails.push(context);
        }
      }
      
      return specificDetails;
    };

    switch (dimension) {
      case 'Achievement':
        // Look for very specific achievements, technologies, projects
        if (content.includes('bolt') && (content.includes('coding') || content.includes('vibe'))) {
          return 'Learning Vibe Coding with Bolt';
        }
        if (content.includes('video') && content.includes('journal')) {
          return 'Building a Video Journal App';
        }
        if (content.includes('react') || content.includes('javascript') || content.includes('typescript')) {
          const techMentions = extractSpecificMentions(originalEntry, ['React', 'JavaScript', 'TypeScript', 'Node.js', 'Python']);
          if (techMentions.length > 0) {
            return `Learning ${techMentions[0].split(' ').slice(0, 4).join(' ')}`;
          }
        }
        if (content.includes('deploy') || content.includes('launch')) {
          return 'Deploying and Launching Projects';
        }
        if (content.includes('algorithm') || content.includes('data structure')) {
          return 'Studying Algorithms and Data Structures';
        }
        if (content.includes('interview') && content.includes('prep')) {
          return 'Preparing for Technical Interviews';
        }
        if (content.includes('course') || content.includes('tutorial')) {
          const courseMentions = extractSpecificMentions(originalEntry, ['course', 'tutorial', 'class', 'lesson']);
          if (courseMentions.length > 0) {
            return `Completing ${courseMentions[0].split(' ').slice(0, 4).join(' ')}`;
          }
        }
        // Extract specific project or skill mentions
        const achievementDetails = extractSpecificDetails(originalEntry);
        if (achievementDetails.length > 0) {
          return `Working on ${achievementDetails[0]}`;
        }
        return 'Personal Achievements';
        
      case 'Connections':
        // Look for specific people and relationship details
        if (content.includes('cousin')) {
          if (content.includes('santa cruz') || content.includes('beach') || content.includes('trip')) {
            return 'Trip to Santa Cruz with Cousins';
          }
          if (content.includes('dinner') || content.includes('meal')) {
            return 'Family Dinner with Cousins';
          }
          return 'Spending Time with Cousins';
        }
        if (content.includes('friend')) {
          const friendMentions = extractSpecificMentions(originalEntry, ['friend', 'buddy', 'pal']);
          if (content.includes('coffee') || content.includes('cafe')) {
            return 'Coffee Catch-up with Friends';
          }
          if (content.includes('game') || content.includes('play')) {
            return 'Gaming Session with Friends';
          }
          return 'Quality Time with Friends';
        }
        if (content.includes('family')) {
          if (content.includes('call') || content.includes('phone')) {
            return 'Family Video Call';
          }
          if (content.includes('visit') || content.includes('home')) {
            return 'Family Visit at Home';
          }
          return 'Family Time';
        }
        if (content.includes('colleague') || content.includes('coworker')) {
          return 'Connecting with Colleagues';
        }
        if (content.includes('date') || content.includes('romantic')) {
          return 'Romantic Date Experience';
        }
        // Extract specific relationship mentions
        const connectionDetails = extractSpecificDetails(originalEntry);
        if (connectionDetails.length > 0) {
          return `Time with ${connectionDetails[0]}`;
        }
        return 'Building Connections';
        
      case 'Memories':
        // Look for specific memorable experiences and locations
        if (content.includes('santa cruz')) {
          if (content.includes('beach') || content.includes('ocean')) {
            return 'Beach Day at Santa Cruz';
          }
          if (content.includes('boardwalk') || content.includes('rides')) {
            return 'Santa Cruz Boardwalk Adventure';
          }
          return 'Trip to Santa Cruz';
        }
        if (content.includes('birthday') || content.includes('celebration')) {
          return 'Birthday Celebration Memories';
        }
        if (content.includes('wedding') || content.includes('ceremony')) {
          return 'Wedding Ceremony Experience';
        }
        if (content.includes('graduation') || content.includes('ceremony')) {
          return 'Graduation Day Memories';
        }
        if (content.includes('vacation') || content.includes('holiday')) {
          const locationMentions = extractSpecificMentions(originalEntry, ['vacation', 'trip', 'travel', 'visit']);
          if (locationMentions.length > 0) {
            return `${locationMentions[0].split(' ').slice(0, 4).join(' ')}`;
          }
          return 'Vacation Memories';
        }
        if (content.includes('concert') || content.includes('music')) {
          return 'Live Music Experience';
        }
        // Extract specific location or event mentions
        const memoryDetails = extractSpecificDetails(originalEntry);
        if (memoryDetails.length > 0) {
          return `Memories from ${memoryDetails[0]}`;
        }
        return 'Creating Memories';
        
      case 'Little Things':
        // Look for specific mindful observations and small pleasures
        if (content.includes('coffee') && content.includes('morning')) {
          return 'Morning Coffee Ritual';
        }
        if (content.includes('sunset') || content.includes('sunrise')) {
          return 'Watching the Sunrise/Sunset';
        }
        if (content.includes('walk') && content.includes('park')) {
          return 'Peaceful Park Walk';
        }
        if (content.includes('rain') || content.includes('weather')) {
          return 'Appreciating the Weather';
        }
        if (content.includes('book') && content.includes('read')) {
          return 'Quiet Reading Time';
        }
        if (content.includes('garden') || content.includes('flowers')) {
          return 'Garden Observations';
        }
        if (content.includes('tea') || content.includes('warm')) {
          return 'Cozy Tea Moments';
        }
        if (content.includes('music') && content.includes('listen')) {
          return 'Mindful Music Listening';
        }
        // Extract specific small moment mentions
        const littleThingsDetails = extractSpecificMentions(originalEntry, ['noticed', 'observed', 'appreciated', 'enjoyed', 'peaceful', 'quiet', 'gentle']);
        if (littleThingsDetails.length > 0) {
          return `${littleThingsDetails[0].split(' ').slice(0, 5).join(' ')}`;
        }
        return 'Mindful Moments';
        
      case 'Introspection':
        // Look for specific reflective themes and personal insights
        if (content.includes('purpose') || content.includes('meaning')) {
          return 'Reflecting on Life Purpose';
        }
        if (content.includes('change') && content.includes('growth')) {
          return 'Personal Growth and Change';
        }
        if (content.includes('perspective') || content.includes('worldview')) {
          return 'Shifting Perspectives on Life';
        }
        if (content.includes('values') || content.includes('beliefs')) {
          return 'Examining Core Values';
        }
        if (content.includes('future') || content.includes('goals')) {
          return 'Contemplating Future Direction';
        }
        if (content.includes('past') || content.includes('childhood')) {
          return 'Reflecting on Past Experiences';
        }
        if (content.includes('identity') || content.includes('who am i')) {
          return 'Questions of Identity';
        }
        if (content.includes('relationship') && content.includes('pattern')) {
          return 'Understanding Relationship Patterns';
        }
        // Extract specific introspective themes
        const introspectionDetails = extractSpecificMentions(originalEntry, ['realized', 'understood', 'learned', 'discovered', 'reflected', 'contemplated']);
        if (introspectionDetails.length > 0) {
          return `${introspectionDetails[0].split(' ').slice(0, 6).join(' ')}`;
        }
        return 'Deep Self-Reflection';
        
      case 'Major life event':
        // Look for specific significant life changes
        if (content.includes('job') || content.includes('career')) {
          if (content.includes('quit') || content.includes('leave')) {
            return 'Career Break Decision';
          }
          if (content.includes('new') || content.includes('start')) {
            return 'Starting New Job';
          }
          if (content.includes('promotion') || content.includes('advance')) {
            return 'Career Advancement';
          }
          return 'Career Transition';
        }
        if (content.includes('move') || content.includes('relocate')) {
          const locationMentions = extractSpecificMentions(originalEntry, ['move', 'relocate', 'city', 'state', 'country']);
          if (locationMentions.length > 0) {
            return `${locationMentions[0].split(' ').slice(0, 4).join(' ')}`;
          }
          return 'Major Relocation';
        }
        if (content.includes('marriage') || content.includes('wedding')) {
          return 'Marriage Milestone';
        }
        if (content.includes('graduation') || content.includes('degree')) {
          return 'Educational Achievement';
        }
        if (content.includes('health') || content.includes('medical')) {
          return 'Significant Health Event';
        }
        if (content.includes('loss') || content.includes('grief')) {
          return 'Processing Major Loss';
        }
        // Extract specific life event mentions
        const lifeEventDetails = extractSpecificDetails(originalEntry);
        if (lifeEventDetails.length > 0) {
          return `${lifeEventDetails[0]} Life Change`;
        }
        return 'Significant Life Event';
        
      default:
        // Fallback: extract the most specific details from the beginning
        const sentences = entry.split(/[.!?]+/);
        if (sentences.length > 0) {
          const firstSentence = sentences[0].trim();
          const words = firstSentence.split(' ').slice(0, 6).join(' ');
          return words.charAt(0).toUpperCase() + words.slice(1);
        }
        return 'Daily Reflection';
    }
  };

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatDay = (date: Date): string => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long'
    });
  };

  const formatTime = (dateString: string): string => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatDuration = (ms: number): string => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getTotalDuration = (): string => {
    const totalMs = entries.reduce((sum, entry) => sum + entry.duration_ms, 0);
    const totalMinutes = Math.floor(totalMs / 60000);
    const remainingSeconds = Math.floor((totalMs % 60000) / 1000);
    return `${totalMinutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const toggleEntry = (entryId: string) => {
    setExpandedEntry(expandedEntry === entryId ? null : entryId);
  };

  const isToday = () => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  return (
    <div className="w-full max-w-7xl lg:pt-[60px]">
      {/* Header - Responsive */}
      <div className="mb-6 sm:mb-8 px-4 sm:px-6 lg:pl-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-0">
          <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto">
            <button
              onClick={onBack}
              className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200`}
            >
              <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-0">
              <h1 className={`text-xl sm:text-2xl font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{formatDate(date)}</h1>
              {/* Day below date on mobile, inline on desktop */}
              <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-sm sm:text-base sm:text-lg block sm:hidden`}>
                {formatDay(date)}
              </p>
            </div>
          </div>
          {/* Day on desktop only */}
          <div className="hidden sm:flex items-center gap-4">
            <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-base sm:text-lg`}>
              {formatDay(date)}
            </p>
          </div>
        </div>
      </div>

      {/* Mobile Tab Interface - Only show on mobile */}
      <div className="block lg:hidden px-4 sm:px-6 mb-6">
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('summary')}
            className={`flex-1 px-4 py-2.5 rounded-lg font-montserrat font-medium text-sm transition-all duration-200 ${
              activeTab === 'summary'
                ? 'bg-gradient-to-r from-blue-500 to-teal-500 text-white shadow-lg'
                : isDarkMode
                  ? 'bg-[#161616] text-[#8C8C8C]'
                  : 'bg-gray-200 text-gray-600'
            }`}
          >
            Summary
          </button>
          <button
            onClick={() => setActiveTab('transcripts')}
            className={`flex-1 px-4 py-2.5 rounded-lg font-montserrat font-medium text-sm transition-all duration-200 ${
              activeTab === 'transcripts'
                ? 'bg-gradient-to-r from-blue-500 to-teal-500 text-white shadow-lg'
                : isDarkMode
                  ? 'bg-[#161616] text-[#8C8C8C]'
                  : 'bg-gray-200 text-gray-600'
            }`}
          >
            Transcripts
          </button>
        </div>
      </div>

      {/* Desktop Layout - Hidden on mobile */}
      <div className="hidden lg:grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
        {/* Summary Section - 64% width */}
        <div className="xl:col-span-8">
          {loading ? (
            <div className="flex items-center justify-center py-12 pl-6">
              <div className={`w-8 h-8 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin`}></div>
            </div>
          ) : (
            <div>
              {entries.length === 0 ? (
                <div className="text-center py-12 pl-6">
                  <BookOpen className={`w-16 h-16 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-4`} />
                  <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-lg`}>No journal entries for this day</p>
                </div>
              ) : (
                <div className="space-y-6 pl-6">
                  {/* Emotion Display - Above AI Summary */}
                  {dominantEmotion && (
                    <div className="mb-6">
                      <div className="flex items-center gap-4">
                        <img
                          src={emotionIcons[dominantEmotion] || '/icons/No Emotion.png'}
                          alt={dominantEmotion}
                          className="w-12 h-12"
                          style={{ filter: `drop-shadow(0 0 8px ${emotionColors[dominantEmotion] || '#6B7280'}40)` }}
                        />
                        <div className="flex flex-col">
                          <h3 className={`text-lg font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                            Today you felt {dominantEmotion}
                          </h3>
                          {/* Representative quote from entry */}
                          {entries.length > 0 && (
                            <p className={`text-sm font-montserrat italic ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mt-1 max-w-md`}>
                              "{entries[0].content.split('.')[0].substring(0, 80)}..."
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Photos Section */}
                  {photoError ? (
                    <div className={`p-4 rounded-lg border ${isDarkMode ? 'bg-red-500/10 border-red-500/20' : 'bg-red-50 border-red-200'} mb-6`}>
                      <div className="flex items-center gap-2">
                        <AlertCircle className={`w-4 h-4 ${isDarkMode ? 'text-red-400' : 'text-red-600'}`} />
                        <span className={`text-sm font-montserrat ${isDarkMode ? 'text-red-400' : 'text-red-600'}`}>
                          {photoError}
                        </span>
                      </div>
                    </div>
                  ) : photos.length > 0 ? (
                    <PhotoGallery photos={photos} isDarkMode={isDarkMode} />
                  ) : null}

                  {/* Dimension Summaries Display */}
                  {dimensionSummaries.length > 0 ? (
                    <div className="space-y-6">
                      {dimensionSummaries.map((summary) => {
                        const IconComponent = dimensionIcons[summary.dimension] || Brain;
                        const colorClass = dimensionColors[summary.dimension] || (isDarkMode ? 'text-gray-400' : 'text-gray-600');
                        const dimensionHeading = generateDimensionHeading(summary.dimension, summary.entry);
                        
                        return (
                          <div key={summary.id} className="mb-6">
                            <div className="flex items-center gap-3 mb-2">
                              <IconComponent className={`w-5 h-5`} style={{ color: colorClass }} />
                              <h4 className={`text-lg font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{summary.dimension}</h4>
                            </div>
                            <h5 className={`text-base font-montserrat font-medium mb-3 pl-8 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dimensionHeading}
                            </h5>
                            <div className={`${isDarkMode ? 'text-gray-200' : 'text-gray-800'} font-montserrat leading-relaxed pl-8`}>
                              {summary.entry}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Brain className={`w-12 h-12 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-4`} />
                      <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat mb-4`}>
                        {isToday() 
                          ? "AI summaries are generated at the end of each day"
                          : "No AI summary available for this day"
                        }
                      </p>
                      {!isToday() && (
                        <button
                          onClick={handleGenerateSummary}
                          disabled={generatingSummary}
                          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-montserrat font-medium rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed mx-auto"
                        >
                          {generatingSummary ? (
                            <>
                              <Loader className="w-4 h-4 animate-spin" />
                              Generating...
                            </>
                          ) : (
                            <>
                              <Brain className="w-4 h-4" />
                              Generate AI Summary
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Entries Section - 36% width */}
        <div className="xl:col-span-4">
          {/* Header with stats */}
          <div className="mb-6">
            <h3 className={`text-xl font-adamina font-bold text-white mb-2`}>
              {loading ? 'Loading...' : `${entries.length} ${entries.length === 1 ? 'Entry' : 'Entries'}, ${getTotalDuration()}`}
            </h3>
            <p className={`text-sm font-montserrat ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Tap to expand and read full transcripts
            </p>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className={`w-6 h-6 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin`}></div>
            </div>
          ) : entries.length === 0 ? (
            <div className="text-center py-8">
              <BookOpen className={`w-12 h-12 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-4`} />
              <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat`}>No entries for this day</p>
            </div>
          ) : (
            /* Entries Accordion */
            <div className="space-y-3">
              {entries.map((entry, index) => (
                <div key={entry.id} className={`${isDarkMode ? 'border-gray-700/30' : 'border-gray-300/30'} border-b last:border-b-0`}>
                  <button
                    onClick={() => toggleEntry(entry.id)}
                    className={`w-full text-left py-4 ${isDarkMode ? 'hover:bg-gray-800/20' : 'hover:bg-gray-100/20'} transition-colors duration-200 group`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className={`text-base font-montserrat font-medium ${isDarkMode ? 'text-white group-hover:text-blue-300' : 'text-gray-900 group-hover:text-blue-600'} transition-colors duration-200`}>
                          {entry.title || `Journal Entry ${index + 1}`}
                        </h4>
                        <div className="flex items-center gap-4 mt-1 mb-2">
                          <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                            {formatTime(entry.created_at)}
                          </span>
                          <div className="flex items-center gap-1">
                            <Clock className={`w-3 h-3 ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`} />
                            <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                              {formatDuration(entry.duration_ms)}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Hash className={`w-3 h-3 ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`} />
                            <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                              {entry.word_count} words
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="ml-4">
                        {expandedEntry === entry.id ? (
                          <ChevronUp className={`w-5 h-5 ${isDarkMode ? 'text-gray-400 group-hover:text-white' : 'text-gray-600 group-hover:text-gray-900'} transition-colors duration-200`} />
                        ) : (
                          <ChevronDown className={`w-5 h-5 ${isDarkMode ? 'text-gray-400 group-hover:text-white' : 'text-gray-600 group-hover:text-gray-900'} transition-colors duration-200`} />
                        )}
                      </div>
                    </div>
                  </button>

                  {/* Expanded Content */}
                  {expandedEntry === entry.id && (
                    <div className="pb-4">
                      <p className={`text-sm font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} leading-relaxed whitespace-pre-wrap mt-2`}>
                        {entry.content}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Content - Show based on active tab */}
      <div className="block lg:hidden px-4 sm:px-6">
        {activeTab === 'summary' ? (
          /* Mobile Summary View */
          <div>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className={`w-8 h-8 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin`}></div>
              </div>
            ) : entries.length === 0 ? (
              <div className="text-center py-12">
                <BookOpen className={`w-16 h-16 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-4`} />
                <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-lg`}>No journal entries for this day</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Emotion Display - Above AI Summary */}
                {dominantEmotion && (
                  <div className="mb-6">
                    <div className="flex items-center gap-4">
                      <img
                        src={emotionIcons[dominantEmotion] || '/icons/No Emotion.png'}
                        alt={dominantEmotion}
                        className="w-12 h-12"
                        style={{ filter: `drop-shadow(0 0 8px ${emotionColors[dominantEmotion] || '#6B7280'}40)` }}
                      />
                      <div className="flex flex-col">
                        <h3 className={`text-lg font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          Today you felt {dominantEmotion}
                        </h3>
                        {/* Representative quote from entry */}
                        {entries.length > 0 && (
                          <p className={`text-sm font-montserrat italic ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mt-1 max-w-md`}>
                            "{entries[0].content.split('.')[0].substring(0, 80)}..."
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Photos Section */}
                {photoError ? (
                  <div className={`p-4 rounded-lg border ${isDarkMode ? 'bg-red-500/10 border-red-500/20' : 'bg-red-50 border-red-200'} mb-6`}>
                    <div className="flex items-center gap-2">
                      <AlertCircle className={`w-4 h-4 ${isDarkMode ? 'text-red-400' : 'text-red-600'}`} />
                      <span className={`text-sm font-montserrat ${isDarkMode ? 'text-red-400' : 'text-red-600'}`}>
                        {photoError}
                      </span>
                    </div>
                  </div>
                ) : photos.length > 0 ? (
                  <PhotoGallery photos={photos} isDarkMode={isDarkMode} />
                ) : null}

                {/* Dimension Summaries Display */}
                {dimensionSummaries.length > 0 ? (
                  <div className="space-y-6">
                    {dimensionSummaries.map((summary) => {
                      const sphereColor = dimensionColors[summary.dimension] || '#6B7280';
                      const dimensionHeading = generateDimensionHeading(summary.dimension, summary.entry);
                      return (
                        <div key={summary.id} className="mb-6">
                          <div className="flex items-center gap-3 mb-2">
                            <GlowSphere color={sphereColor} />
                            <h4 className={`text-lg font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{summary.dimension}</h4>
                          </div>
                          <h5 className={`text-base font-montserrat font-medium mb-3 pl-8 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                            {dimensionHeading}
                          </h5>
                          <div className={`${isDarkMode ? 'text-gray-200' : 'text-gray-800'} font-montserrat leading-relaxed pl-8 text-sm sm:text-base`}>
                            {summary.entry}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Brain className={`w-12 h-12 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-4`} />
                    <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat mb-4 text-sm sm:text-base`}>
                      {isToday() 
                        ? "AI summaries are generated at the end of each day"
                        : "No AI summary available for this day"
                      }
                    </p>
                    {!isToday() && (
                      <button
                        onClick={handleGenerateSummary}
                        disabled={generatingSummary}
                        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-montserrat font-medium rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed mx-auto text-sm"
                      >
                        {generatingSummary ? (
                          <>
                            <Loader className="w-4 h-4 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Brain className="w-4 h-4" />
                            Generate AI Summary
                          </>
                        )}
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          /* Mobile Transcripts View */
          <div>
            {/* Header with stats */}
            <div className="mb-6">
              <h3 className={`text-lg font-montserrat font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
                {loading ? 'Loading...' : `${entries.length} ${entries.length === 1 ? 'Entry' : 'Entries'}, ${getTotalDuration()}`}
              </h3>
              <p className={`text-sm font-montserrat ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Tap to expand and read full transcripts
              </p>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className={`w-6 h-6 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin`}></div>
              </div>
            ) : entries.length === 0 ? (
              <div className="text-center py-8">
                <BookOpen className={`w-12 h-12 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-4`} />
                <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat`}>No entries for this day</p>
              </div>
            ) : (
              /* Mobile Entries Accordion */
              <div className="space-y-3">
                {entries.map((entry, index) => (
                  <div key={entry.id} className={`${isDarkMode ? 'border-gray-700/30' : 'border-gray-300/30'} border-b last:border-b-0`}>
                    <button
                      onClick={() => toggleEntry(entry.id)}
                      className={`w-full text-left py-4 ${isDarkMode ? 'hover:bg-gray-800/20' : 'hover:bg-gray-100/20'} transition-colors duration-200 group`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className={`text-base font-montserrat font-medium ${isDarkMode ? 'text-white group-hover:text-blue-300' : 'text-gray-900 group-hover:text-blue-600'} transition-colors duration-200`}>
                            {entry.title || `Journal Entry ${index + 1}`}
                          </h4>
                          <div className="flex items-center gap-4 mt-1 mb-2">
                            <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                              {formatTime(entry.created_at)}
                            </span>
                            <div className="flex items-center gap-1">
                              <Clock className={`w-3 h-3 ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`} />
                              <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                                {formatDuration(entry.duration_ms)}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Hash className={`w-3 h-3 ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`} />
                              <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                                {entry.word_count} words
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="ml-4">
                          {expandedEntry === entry.id ? (
                            <ChevronUp className={`w-5 h-5 ${isDarkMode ? 'text-gray-400 group-hover:text-white' : 'text-gray-600 group-hover:text-gray-900'} transition-colors duration-200`} />
                          ) : (
                            <ChevronDown className={`w-5 h-5 ${isDarkMode ? 'text-gray-400 group-hover:text-white' : 'text-gray-600 group-hover:text-gray-900'} transition-colors duration-200`} />
                          )}
                        </div>
                      </div>
                    </button>

                    {/* Expanded Content */}
                    {expandedEntry === entry.id && (
                      <div className="pb-4">
                        <p className={`text-sm font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} leading-relaxed whitespace-pre-wrap mt-2`}>
                          {entry.content}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default DailySummary;