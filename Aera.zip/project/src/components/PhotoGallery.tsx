import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Trash2, Loader } from 'lucide-react';

interface PhotoGalleryProps {
  photos: string[];
  isDarkMode: boolean;
  onDeletePhoto?: (photoUrl: string) => void;
  deletingPhotoUrl?: string | null;
}

const PhotoGallery: React.FC<PhotoGalleryProps> = ({ 
  photos, 
  isDarkMode, 
  onDeletePhoto, 
  deletingPhotoUrl 
}) => {
  const [selectedPhoto, setSelectedPhoto] = useState<number | null>(null);

  console.log('PhotoGallery: Rendering with photos:', photos);

  if (!photos || photos.length === 0) {
    console.log('PhotoGallery: No photos to display');
    return null;
  }

  const openLightbox = (index: number) => {
    console.log(`PhotoGallery: Opening lightbox for photo at index ${index}:`, photos[index]);
    setSelectedPhoto(index);
  };

  const closeLightbox = () => {
    console.log('PhotoGallery: Closing lightbox');
    setSelectedPhoto(null);
  };

  const navigatePhoto = (direction: 'prev' | 'next') => {
    if (selectedPhoto === null) return;
    
    if (direction === 'prev') {
      setSelectedPhoto(selectedPhoto > 0 ? selectedPhoto - 1 : photos.length - 1);
    } else {
      setSelectedPhoto(selectedPhoto < photos.length - 1 ? selectedPhoto + 1 : 0);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') navigatePhoto('prev');
    if (e.key === 'ArrowRight') navigatePhoto('next');
  };

  const handleImageError = (index: number) => {
    console.error(`PhotoGallery: Error loading image at index ${index}:`, photos[index]);
  };

  return (
    <>
      {/* Photo Grid */}
      <div className="mb-6">
        <h4 className={`text-lg font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
          Photos
        </h4>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {photos.map((photo, index) => (
            <div
              key={index}
              className="relative aspect-square rounded-lg overflow-hidden bg-gray-100 group"
            >
              <button
                onClick={() => openLightbox(index)}
                className="w-full h-full hover:opacity-90 transition-opacity duration-200"
              >
                <img
                  src={photo}
                  alt={`Photo ${index + 1}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  loading="lazy"
                  onError={() => handleImageError(index)}
                />
              </button>
              
              {/* Delete Button - Only show if onDeletePhoto is provided */}
              {onDeletePhoto && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeletePhoto(photo);
                  }}
                  disabled={deletingPhotoUrl === photo}
                  className={`
                    absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center
                    bg-red-500 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200
                    hover:bg-red-600 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed
                  `}
                  title="Delete photo"
                >
                  {deletingPhotoUrl === photo ? (
                    <Loader className="w-3 h-3 animate-spin" />
                  ) : (
                    <Trash2 className="w-3 h-3" />
                  )}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedPhoto !== null && (
        <div 
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={closeLightbox}
          onKeyDown={handleKeyDown}
          tabIndex={0}
        >
          {/* Close button */}
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 transition-colors duration-200 flex items-center justify-center z-10"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Delete button in lightbox - Only show if onDeletePhoto is provided */}
          {onDeletePhoto && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDeletePhoto(photos[selectedPhoto]);
              }}
              disabled={deletingPhotoUrl === photos[selectedPhoto]}
              className="absolute top-4 right-16 w-10 h-10 rounded-full bg-red-500/80 backdrop-blur-sm text-white hover:bg-red-600/80 transition-colors duration-200 flex items-center justify-center z-10 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Delete photo"
            >
              {deletingPhotoUrl === photos[selectedPhoto] ? (
                <Loader className="w-5 h-5 animate-spin" />
              ) : (
                <Trash2 className="w-5 h-5" />
              )}
            </button>
          )}

          {/* Navigation buttons */}
          {photos.length > 1 && (
            <>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  navigatePhoto('prev');
                }}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 transition-colors duration-200 flex items-center justify-center z-10"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  navigatePhoto('next');
                }}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 transition-colors duration-200 flex items-center justify-center z-10"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}

          {/* Photo counter */}
          {photos.length > 1 && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-3 py-1 bg-white/10 backdrop-blur-sm text-white text-sm rounded-full">
              {selectedPhoto + 1} of {photos.length}
            </div>
          )}

          {/* Main photo */}
          <div 
            className="max-w-full max-h-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={photos[selectedPhoto]}
              alt={`Photo ${selectedPhoto + 1}`}
              className="max-w-full max-h-full object-contain rounded-lg"
              onError={() => handleImageError(selectedPhoto)}
            />
          </div>
        </div>
      )}
    </>
  );
};

export default PhotoGallery;