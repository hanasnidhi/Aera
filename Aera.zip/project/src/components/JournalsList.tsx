import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Hash, Edit3, Trash2, Plus, BookOpen } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import ConfirmationModal from './ConfirmationModal';

interface JournalEntry {
  id: string;
  title: string | null;
  content: string;
  entry_date: string;
  word_count: number;
  duration_ms: number;
  created_at: string;
  updated_at: string;
}

interface JournalsListProps {
  isVisible: boolean;
  onClose: () => void;
  onNewEntry: () => void;
  onEditEntry?: (entry: JournalEntry) => void;
  isDarkMode: boolean;
}

const JournalsList: React.FC<JournalsListProps> = ({ isVisible, onClose, onNewEntry, onEditEntry, isDarkMode }) => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);
  const [deletingEntryId, setDeletingEntryId] = useState<string | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    itemType: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    itemType: '',
    onConfirm: () => {}
  });

  useEffect(() => {
    if (isVisible && user) {
      fetchEntries();
    }
  }, [isVisible, user]);

  const fetchEntries = async () => {
    if (!user) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('user_id', user.id)
        .eq('entry_type', 'individual')
        .order('entry_date', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching journal entries:', error);
      } else {
        setEntries(data || []);
      }
    } catch (error) {
      console.error('Error fetching journal entries:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteEntry = (entry: JournalEntry) => {
    const displayTitle = entry.title || 'Untitled Entry';
    setConfirmModal({
      isOpen: true,
      title: 'Delete Journal Entry',
      message: `"${displayTitle}" will be permanently removed from your journal.`,
      itemType: 'this journal entry',
      onConfirm: () => confirmDeleteEntry(entry.id)
    });
  };

  const confirmDeleteEntry = async (entryId: string) => {
    try {
      setDeletingEntryId(entryId);
      setConfirmModal(prev => ({ ...prev, isOpen: false }));
      
      const { error } = await supabase
        .from('journal_entries')
        .delete()
        .eq('id', entryId);

      if (error) {
        console.error('Error deleting entry:', error);
      } else {
        setEntries(prev => prev.filter(entry => entry.id !== entryId));
        if (selectedEntry?.id === entryId) {
          setSelectedEntry(null);
        }
      }
    } catch (error) {
      console.error('Error deleting entry:', error);
    } finally {
      setDeletingEntryId(null);
    }
  };

  const handleEditEntry = (entry: JournalEntry) => {
    if (onEditEntry) {
      onEditEntry(entry);
      onClose();
    }
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined
      });
    }
  };

  const formatDuration = (ms: number): string => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getPreview = (content: string): string => {
    return content.length > 150 ? content.substring(0, 150) + '...' : content;
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4">
      <div className={`${isDarkMode ? 'bg-gray-900/95 border-gray-700/30' : 'bg-white/95 border-gray-300/30'} backdrop-blur-md border rounded-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col lg:flex-row`}>
        {/* Sidebar - Entries List - Responsive layout */}
        <div className={`w-full lg:w-1/3 ${isDarkMode ? 'border-gray-700/30' : 'border-gray-300/30'} lg:border-r flex flex-col max-h-[40vh] lg:max-h-none`}>
          {/* Header - Responsive padding */}
          <div className={`p-4 sm:p-6 ${isDarkMode ? 'border-gray-700/30' : 'border-gray-300/30'} border-b`}>
            <div className="flex items-center justify-between mb-3 sm:mb-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <h2 className={`text-lg sm:text-xl font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Your Journals</h2>
              </div>
              <button
                onClick={onClose}
                className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200 text-lg sm:text-xl`}
              >
                ×
              </button>
            </div>
            
            <button
              onClick={onNewEntry}
              className="w-full flex items-center gap-2 px-3 sm:px-4 py-2.5 sm:py-3 bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-montserrat font-medium rounded-lg transition-all duration-300 transform hover:scale-[1.02] text-sm sm:text-base"
            >
              <Plus className="w-3 h-3 sm:w-4 sm:h-4" />
              New Entry
            </button>
          </div>

          {/* Entries List - Responsive sizing */}
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="flex items-center justify-center p-6 sm:p-8">
                <div className={`w-6 h-6 sm:w-8 sm:h-8 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin`}></div>
              </div>
            ) : entries.length === 0 ? (
              <div className="p-6 sm:p-8 text-center">
                <BookOpen className={`w-10 h-10 sm:w-12 sm:h-12 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-3 sm:mb-4`} />
                <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-sm sm:text-base`}>No journal entries yet</p>
                <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} font-montserrat mt-2`}>
                  Start recording to create your first entry
                </p>
              </div>
            ) : (
              <div className="p-3 sm:p-4 space-y-2 sm:space-y-3">
                {entries.map((entry) => (
                  <div
                    key={entry.id}
                    onClick={() => setSelectedEntry(entry)}
                    className={`p-3 sm:p-4 rounded-lg border cursor-pointer transition-all duration-200 ${
                      selectedEntry?.id === entry.id
                        ? isDarkMode ? 'bg-blue-500/10 border-blue-500/30' : 'bg-blue-50 border-blue-200'
                        : isDarkMode ? 'bg-gray-800/30 border-gray-700/30 hover:bg-gray-800/50' : 'bg-gray-50/50 border-gray-200/50 hover:bg-gray-100/50'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h3 className={`font-montserrat font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'} text-xs sm:text-sm line-clamp-1`}>
                        {entry.title || 'Untitled Entry'}
                      </h3>
                      <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat whitespace-nowrap ml-2`}>
                        {formatDate(entry.entry_date)}
                      </span>
                    </div>
                    
                    <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} font-montserrat line-clamp-2 mb-2 sm:mb-3`}>
                      {getPreview(entry.content)}
                    </p>
                    
                    <div className={`flex items-center gap-3 sm:gap-4 text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`}>
                      <div className="flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                        {formatDuration(entry.duration_ms)}
                      </div>
                      <div className="flex items-center gap-1">
                        <Hash className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                        {entry.word_count}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Main Content - Entry Detail - Responsive layout */}
        <div className="flex-1 flex flex-col min-h-[50vh] lg:min-h-0">
          {selectedEntry ? (
            <>
              {/* Entry Header - Responsive padding and sizing */}
              <div className={`p-4 sm:p-6 ${isDarkMode ? 'border-gray-700/30' : 'border-gray-300/30'} border-b`}>
                <div className="flex flex-col sm:flex-row items-start justify-between gap-3 sm:gap-0 mb-3 sm:mb-4">
                  <div className="flex-1">
                    <h1 className={`text-xl sm:text-2xl font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
                      {selectedEntry.title || 'Untitled Entry'}
                    </h1>
                    <div className={`flex flex-wrap items-center gap-3 sm:gap-6 text-xs sm:text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      <div className="flex items-center gap-1.5 sm:gap-2">
                        <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                        {formatDate(selectedEntry.entry_date)}
                      </div>
                      <div className="flex items-center gap-1.5 sm:gap-2">
                        <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                        {formatDuration(selectedEntry.duration_ms)}
                      </div>
                      <div className="flex items-center gap-1.5 sm:gap-2">
                        <Hash className="w-3 h-3 sm:w-4 sm:h-4" />
                        {selectedEntry.word_count} words
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEditEntry(selectedEntry)}
                      className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200`}
                    >
                      <Edit3 className="w-3 h-3 sm:w-4 sm:h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteEntry(selectedEntry)}
                      disabled={deletingEntryId === selectedEntry.id}
                      className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-red-400 hover:bg-red-500/10' : 'text-gray-600 hover:text-red-600 hover:bg-red-50'} rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                      {deletingEntryId === selectedEntry.id ? (
                        <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Trash2 className="w-3 h-3 sm:w-4 sm:h-4" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Entry Content - Responsive padding and text sizing */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6">
                <div className="prose prose-invert max-w-none">
                  <p className={`${isDarkMode ? 'text-gray-200' : 'text-gray-800'} font-montserrat leading-relaxed whitespace-pre-wrap text-sm sm:text-base`}>
                    {selectedEntry.content}
                  </p>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center p-4 sm:p-6">
              <div className="text-center">
                <BookOpen className={`w-12 h-12 sm:w-16 sm:h-16 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-3 sm:mb-4`} />
                <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-base sm:text-lg`}>Select an entry to view</p>
                <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} font-montserrat mt-2`}>
                  Choose a journal entry from the list to read or edit
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        itemType={confirmModal.itemType}
        isLoading={deletingEntryId !== null}
        isDarkMode={isDarkMode}
      />
    </div>
  );
};

export default JournalsList;