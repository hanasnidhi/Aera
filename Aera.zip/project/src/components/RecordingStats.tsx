import React from 'react';
import { Clock, Hash } from 'lucide-react';

interface RecordingStatsProps {
  duration: number;
  wordCount: number;
  isRecording: boolean;
  showOnlyTime?: boolean;
  showOnlyWords?: boolean;
  isDarkMode: boolean;
}

const RecordingStats: React.FC<RecordingStatsProps> = ({ 
  duration, 
  wordCount, 
  isRecording,
  showOnlyTime = false,
  showOnlyWords = false,
  isDarkMode
}) => {
  const formatDuration = (ms: number): string => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  if (showOnlyTime) {
    return (
      <div className={`flex items-center gap-2 px-3 py-1.5 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30' : 'bg-white/90 border-gray-300/50'} backdrop-blur-sm border rounded-full`}>
        <Clock className={`w-3.5 h-3.5 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
        <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} tracking-wider`}>
          {formatDuration(duration)}
        </span>
      </div>
    );
  }

  if (showOnlyWords) {
    return (
      <div className={`flex items-center gap-2 px-3 py-1.5 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30' : 'bg-white/90 border-gray-300/50'} backdrop-blur-sm border rounded-full`}>
        <Hash className={`w-3.5 h-3.5 ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`} />
        <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} tracking-wider`}>
          {wordCount} {wordCount === 1 ? 'word' : 'words'}
        </span>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex items-center gap-6">
        {/* Recording Duration */}
        <div className={`flex items-center gap-2 px-3 py-1.5 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30' : 'bg-white/90 border-gray-300/50'} backdrop-blur-sm border rounded-full`}>
          <Clock className={`w-3.5 h-3.5 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
          <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} tracking-wider`}>
            {formatDuration(duration)}
          </span>
        </div>

        {/* Word Count */}
        <div className={`flex items-center gap-2 px-3 py-1.5 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30' : 'bg-white/90 border-gray-300/50'} backdrop-blur-sm border rounded-full`}>
          <Hash className={`w-3.5 h-3.5 ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`} />
          <span className={`text-xs font-montserrat ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} tracking-wider`}>
            {wordCount} {wordCount === 1 ? 'word' : 'words'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default RecordingStats;