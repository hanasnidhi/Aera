import React, { useState, useEffect } from 'react';
import { Brain, Sparkles, Quote, Calendar, Loader, RefreshCw, Trash2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { generateInsights, getInsights, insightsGeneratedThisWeek, deleteInsight } from '../lib/insights';
import ConfirmationModal from './ConfirmationModal';

interface Theme {
  id: string;
  title: string;
  summary: string;
  quotes: string[];
  prominence_score: number;
  last_updated: string;
  created_at: string;
}

interface InsightsViewProps {
  isDarkMode: boolean;
}

const InsightsView: React.FC<InsightsViewProps> = ({ isDarkMode }) => {
  const { user } = useAuth();
  const [themes, setThemes] = useState<Theme[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [deletingThemeId, setDeletingThemeId] = useState<string | null>(null);
  const [generatedThisWeek, setGeneratedThisWeek] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    itemType: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    itemType: '',
    onConfirm: () => {}
  });

  // Brand colors for theme orbs
  const brandColors = [
    '#0C93FC', // Primary blue
    '#2FA7C6', // Teal
    '#93A7F1', // Light purple
    '#08B5A8', // Green
    '#8D51DA', // Purple
    '#93F3EC', // Light teal
    '#FFD700', // Gold
    '#FF6B6B'  // Coral
  ];

  useEffect(() => {
    if (user) {
      loadInsights();
      checkWeeklyStatus();
    }
  }, [user]);

  const loadInsights = async () => {
    if (!user) return;

    try {
      setLoading(true);
      const insights = await getInsights(user.id);
      setThemes(insights || []);
    } catch (error) {
      console.error('Error loading insights:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkWeeklyStatus = async () => {
    if (!user) return;

    try {
      const generated = await insightsGeneratedThisWeek(user.id);
      setGeneratedThisWeek(generated);
    } catch (error) {
      console.error('Error checking weekly status:', error);
    }
  };

  const handleGenerateInsights = async () => {
    if (!user) return;

    try {
      setGenerating(true);
      await generateInsights(user.id);
      await loadInsights();
      setGeneratedThisWeek(true);
    } catch (error) {
      console.error('Error generating insights:', error);
    } finally {
      setGenerating(false);
    }
  };

  const handleDeleteTheme = (themeId: string, themeTitle: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Delete Insight Theme',
      message: `The theme "${themeTitle}" and all its associated insights will be permanently removed.`,
      itemType: 'this insight theme',
      onConfirm: () => confirmDeleteTheme(themeId)
    });
  };

  const confirmDeleteTheme = async (themeId: string) => {
    try {
      setDeletingThemeId(themeId);
      setConfirmModal(prev => ({ ...prev, isOpen: false }));
      
      await deleteInsight(themeId);
      
      // Remove the theme from the local state
      setThemes(prev => prev.filter(theme => theme.id !== themeId));
      
    } catch (error) {
      console.error('Error deleting theme:', error);
      // Could add a toast notification here instead of alert
    } finally {
      setDeletingThemeId(null);
    }
  };

  // Helper function to check if it's the start of the week (Monday)
  const isStartOfWeek = () => {
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
    return dayOfWeek === 1; // Monday
  };

  // Helper function to get days until next Monday
  const getDaysUntilNextMonday = () => {
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
    
    if (dayOfWeek === 1) return 7; // If today is Monday, next Monday is 7 days away
    if (dayOfWeek === 0) return 1; // If today is Sunday, next Monday is 1 day away
    return 8 - dayOfWeek; // For Tuesday-Saturday
  };

  // Helper function to check if insights were generated this week

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric'
    });
  };

  // Determine button state
  const shouldShowNewInsights = isStartOfWeek() && !generatedThisWeek;
  const daysUntilNext = getDaysUntilNextMonday();
  const buttonText = shouldShowNewInsights 
    ? 'New Insights' 
    : `New Insights in ${daysUntilNext} day${daysUntilNext === 1 ? '' : 's'}`;
  const buttonIcon = shouldShowNewInsights ? Sparkles : RefreshCw;

  // Component to render glow orb
  const GlowOrb: React.FC<{ color: string; size?: 'sm' | 'md' }> = ({ color, size = 'md' }) => {
    const sizeClasses = size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';
    
    return (
      <div className="relative flex items-center justify-center">
        {/* Background glow layers */}
        <div 
          className={`absolute inset-0 ${sizeClasses} rounded-full animate-pulse`}
          style={{
            background: `radial-gradient(circle, ${color}40, transparent 70%)`,
            filter: 'blur(4px)',
            animationDuration: '3s'
          }}
        />
        <div 
          className={`absolute inset-0 ${sizeClasses} rounded-full animate-pulse`}
          style={{
            background: `radial-gradient(circle, ${color}30, transparent 60%)`,
            filter: 'blur(6px)',
            animationDuration: '4s',
            animationDelay: '0.5s'
          }}
        />
        
        {/* Main orb */}
        <div 
          className={`${sizeClasses} rounded-full relative z-10 ${isDarkMode ? 'bg-black' : 'bg-gray-900'}`}
          style={{
            boxShadow: `0 0 15px ${color}60, inset 0 0 8px rgba(0, 0, 0, 0.3)`
          }}
        />
      </div>
    );
  };

  if (loading) {
    return (
      <div className="w-full max-w-7xl px-4 sm:px-6 pb-8 lg:pt-[60px]">
        <div className="flex items-center justify-center py-12">
          <div className={`w-8 h-8 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin`}></div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl px-4 sm:px-6 pb-8 lg:pt-[60px]">
      {/* Header */}
      <div className="mb-6 sm:mb-8 lg:pl-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-0">
          <div>
            <h1 className={`text-2xl sm:text-3xl font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
              Your Insights
            </h1>
            <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-sm sm:text-base`}>
              Recurring themes and patterns discovered in your journal entries
            </p>
          </div>
          
          {/* Generate/Update Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleGenerateInsights}
              disabled={generating || !shouldShowNewInsights}
              className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 font-montserrat font-medium rounded-lg 
                transition-all duration-300 disabled:cursor-not-allowed text-sm sm:text-base ${
                shouldShowNewInsights && !generating
                  ? 'bg-gradient-to-r from-blue-500 to-teal-500 text-white hover:from-blue-600 hover:to-teal-600 shadow-lg shadow-blue-500/25'
                  : 'bg-[#161616] text-[#959BA7]'
              }`}
            >
              {generating ? (
                <>
                  <Loader className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  {React.createElement(buttonIcon, { className: "w-4 h-4 sm:w-5 sm:h-5" })}
                  {buttonText}
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="lg:pl-6">
        {themes.length === 0 ? (
          <div className="text-center py-12">
            <Sparkles className={`w-16 h-16 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'} mx-auto mb-4`} />
            <h3 className={`text-lg font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
              No insights yet
            </h3>
            <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat mb-6 text-sm sm:text-base`}>
              {shouldShowNewInsights 
                ? "Click 'New Insights' to discover recurring themes and patterns in your journal entries"
                : themes.length === 0 
                  ? `New insights will be available in ${daysUntilNext} day${daysUntilNext === 1 ? '' : 's'}`
                  : "Your insights are updated weekly on Mondays"
              }
            </p>
          </div>
        ) : (
          <div className="space-y-0">
            {themes.map((theme, index) => (
              <div key={theme.id}>
                <div className="py-6 sm:py-8">
                  {/* Theme Title with Glowing Orb */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3 flex-1">
                      <h2 className={`text-xl sm:text-2xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        {theme.title}
                      </h2>
                      {/* Prominence indicator */}
                      <div className={`px-2 py-1 rounded-full text-xs font-montserrat font-medium ${
                        theme.prominence_score >= 80 
                          ? 'bg-green-500/20 text-green-400' 
                          : theme.prominence_score >= 60 
                          ? 'bg-yellow-500/20 text-yellow-400'
                          : 'bg-gray-500/20 text-gray-400'
                      }`}>
                        {theme.prominence_score}%
                      </div>
                    </div>
                    
                    {/* Delete Button */}
                    <button
                      onClick={() => handleDeleteTheme(theme.id, theme.title)}
                      disabled={deletingThemeId === theme.id}
                      className={`p-2 rounded-lg transition-all duration-200 ${
                        isDarkMode 
                          ? 'text-gray-500 hover:text-red-400 hover:bg-red-500/10' 
                          : 'text-gray-400 hover:text-red-600 hover:bg-red-50'
                      } disabled:opacity-50 disabled:cursor-not-allowed`}
                      title="Delete theme"
                    >
                      {deletingThemeId === theme.id ? (
                        <Loader className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                      )}
                    </button>
                  </div>
                  
                  {/* Theme Summary */}
                  <p className={`${isDarkMode ? 'text-gray-200' : 'text-gray-800'} font-montserrat leading-relaxed mb-6 text-sm sm:text-base`}>
                    {theme.summary}
                  </p>
                  
                  {/* Quotes Section */}
                  {theme.quotes && theme.quotes.length > 0 && (
                    <div className="mb-4">
                      <div className="space-y-4">
                        {theme.quotes.map((quote, quoteIndex) => (
                          <div key={quoteIndex} className={`relative pl-6 ${isDarkMode ? 'border-l-2 border-purple-500/30' : 'border-l-2 border-purple-400/40'}`}>
                            <Quote className={`absolute left-0 top-0 w-4 h-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'} -translate-x-1/2`} />
                            <p className={`${isDarkMode ? 'text-gray-300' : 'text-gray-700'} font-montserrat italic text-sm sm:text-base leading-relaxed`}>
                              "{quote}"
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Last Updated */}
                  <div className="flex items-center gap-2">
                    <Calendar className={`w-3 h-3 sm:w-4 sm:h-4 ${isDarkMode ? 'text-gray-500' : 'text-gray-600'}`} />
                    <span className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-500' : 'text-gray-600'} font-montserrat`}>
                      Last updated {formatDate(theme.last_updated)}
                    </span>
                  </div>
                </div>
                
                {/* Divider - Only show between themes, not after the last one */}
                {index < themes.length - 1 && (
                  <div className="border-t" style={{ borderColor: '#10141B' }}></div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        itemType={confirmModal.itemType}
        isLoading={deletingThemeId !== null}
        isDarkMode={isDarkMode}
      />
    </div>
  );
};

export default InsightsView;