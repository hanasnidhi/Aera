import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Mic } from 'lucide-react';

interface ResponsiveRecordSliderProps {
  isDarkMode: boolean;
  isSidebarCollapsed: boolean;
  selectedDimensionColor?: string;
  onRecordStart: () => void;
}

const ResponsiveRecordSlider: React.FC<ResponsiveRecordSliderProps> = ({
  isDarkMode,
  selectedDimensionColor = '#93F3EC',
  onRecordStart
}) => {
  // Internal state for slider management
  const [sliderPosition, setSliderPosition] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);
  const handleRef = useRef<HTMLDivElement>(null);
  const currentClientXRef = useRef<number>(0);

  // Slider calculation function
  const calculateSliderPosition = useCallback((clientX: number): number => {
    if (sliderRef.current && handleRef.current) {
      const sliderRect = sliderRef.current.getBoundingClientRect();
      const handleWidth = handleRef.current.offsetWidth;
      const trackWidth = sliderRect.width - handleWidth;
      const relativeX = clientX - sliderRect.left - (handleWidth / 2);
      const position = Math.max(0, Math.min(100, (relativeX / trackWidth) * 100));
      return position;
    }
    return 0;
  }, []);

  // Slider event handlers
  const updateSliderPosition = useCallback((clientX: number) => {
    const position = calculateSliderPosition(clientX);
    setSliderPosition(position);
    currentClientXRef.current = clientX;
  }, [calculateSliderPosition]);

  const handleSliderStart = useCallback((clientX: number) => {
    setIsDragging(true);
    updateSliderPosition(clientX);
  }, [updateSliderPosition]);

  const handleSliderMove = useCallback((clientX: number) => {
    if (isDragging) {
      updateSliderPosition(clientX);
    }
  }, [isDragging, updateSliderPosition]);

  const handleSliderEnd = useCallback(() => {
    if (isDragging) {
      const finalPosition = calculateSliderPosition(currentClientXRef.current);
      console.log('Slider released at position:', finalPosition);
      
      if (finalPosition >= 70) {
        console.log('Triggering recording...');
        onRecordStart();
      } else {
        setSliderPosition(0);
      }
      setIsDragging(false);
    }
  }, [isDragging, calculateSliderPosition, onRecordStart]);

  // Mouse event handlers
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    handleSliderStart(e.clientX);
  }, [handleSliderStart]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    handleSliderMove(e.clientX);
  }, [handleSliderMove]);

  const handleMouseUp = useCallback(() => {
    handleSliderEnd();
  }, [handleSliderEnd]);

  // Touch event handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    handleSliderStart(e.touches[0].clientX);
  }, [handleSliderStart]);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    e.preventDefault();
    handleSliderMove(e.touches[0].clientX);
  }, [handleSliderMove]);

  const handleTouchEnd = useCallback(() => {
    handleSliderEnd();
  }, [handleSliderEnd]);

  // Handle mouse/touch events for slider
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.addEventListener('touchmove', handleTouchMove);
      document.addEventListener('touchend', handleTouchEnd);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, [isDragging, handleMouseMove, handleMouseUp, handleTouchMove, handleTouchEnd]);

  return (
    <div className="w-full max-w-80 mx-auto">
      <div 
        ref={sliderRef}
        className={`relative w-full h-16 ${
          isDarkMode ? 'bg-gray-900/30 border-gray-700/30' : 'bg-white/90 border-gray-300/50'
        } backdrop-blur-md border rounded-full overflow-hidden slider-container shadow-lg transition-all duration-300`}
        style={{
          background: `linear-gradient(to right, 
            ${isDarkMode 
              ? `${selectedDimensionColor}20 0%, ${selectedDimensionColor}10 ${sliderPosition}%, rgba(17, 24, 39, 0.3) ${sliderPosition}%, rgba(17, 24, 39, 0.3) 100%`
              : `${selectedDimensionColor}20 0%, ${selectedDimensionColor}10 ${sliderPosition}%, rgba(255, 255, 255, 0.9) ${sliderPosition}%, rgba(255, 255, 255, 0.9) 100%`
            }
          )`
        }}
      >
        {/* Glow effect */}
        <div 
          className="absolute inset-0 rounded-full transition-opacity duration-300"
          style={{
            background: `radial-gradient(ellipse at ${20 + (sliderPosition * 0.6)}% center, ${selectedDimensionColor}40, transparent 70%)`,
            opacity: isDragging ? 1 : 0.5
          }}
        />
        
        {/* Track fill */}
        <div 
          className="absolute left-0 top-0 h-full rounded-full transition-all duration-200"
          style={{ 
            width: `${Math.max(15, sliderPosition)}%`,
            background: `linear-gradient(to right, ${selectedDimensionColor}40, ${selectedDimensionColor}60)`
          }}
        />
        
        {/* Handle */}
        <div 
          ref={handleRef}
          className={`absolute top-2 left-2 w-12 h-12 ${
            isDarkMode ? 'bg-black' : 'bg-gray-900'
          } rounded-full shadow-lg transition-all duration-200 flex items-center justify-center cursor-grab active:cursor-grabbing`}
          style={{ 
            transform: `translateX(${sliderRef.current ? (sliderPosition / 100) * (sliderRef.current.offsetWidth - 56) : 0}px) scale(${isDragging ? 1.1 : 1})`,
            boxShadow: `0 4px 20px ${selectedDimensionColor}60, 0 0 0 ${isDragging ? 4 : 0}px ${selectedDimensionColor}40`
          }}
          onMouseDown={handleMouseDown}
          onTouchStart={handleTouchStart}
        >
          <Mic className="w-6 h-6 text-white" />
        </div>
        
        {/* Text */}
        <div 
          className="absolute inset-0 flex items-center justify-center pointer-events-none transition-opacity duration-300"
          style={{ opacity: Math.max(0, 1 - (sliderPosition / 50)) }}
        >
          <span className={`${
            isDarkMode ? 'text-gray-300' : 'text-gray-600'
          } font-montserrat text-sm tracking-wider`}>
            Slide to record
          </span>
        </div>
      </div>
    </div>
  );
};

export default ResponsiveRecordSlider;