import React, { useState } from 'react';
import { Brain, Calendar, CheckCircle, AlertCircle, Loader, Target, Heart, Lightbulb, Eye, Users, Star } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { generateHistoricalSummaries, getSummaryStats } from '../utils/generateHistoricalSummaries';

const SummaryGenerator: React.FC = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Dimension icons mapping
  const dimensionIcons: { [key: string]: React.ComponentType<any> } = {
    'Achievement': Target,
    'Introspection': Lightbulb,
    'Memories': Heart,
    'Little Things': Eye,
    'Connections': Users,
    'Major life event': Star
  };

  const handleGenerateSummaries = async () => {
    if (!user) return;

    setLoading(true);
    setError(null);
    setResults(null);

    try {
      console.log('Starting dimension summary generation...');
      const result = await generateHistoricalSummaries(user.id);
      setResults(result);
      
      // Refresh stats after generation
      const newStats = await getSummaryStats(user.id);
      setStats(newStats);
      
    } catch (err) {
      console.error('Error generating dimension summaries:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate dimension summaries');
    } finally {
      setLoading(false);
    }
  };

  const handleGetStats = async () => {
    if (!user) return;

    try {
      const statsResult = await getSummaryStats(user.id);
      setStats(statsResult);
    } catch (err) {
      console.error('Error getting stats:', err);
      setError(err instanceof Error ? err.message : 'Failed to get stats');
    }
  };

  React.useEffect(() => {
    if (user) {
      handleGetStats();
    }
  }, [user]);

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-gray-900/30 backdrop-blur-sm border border-gray-700/30 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <Brain className="w-8 h-8 text-purple-400" />
          <div>
            <h2 className="text-2xl font-adamina text-white">AI Dimension Summary Generator</h2>
            <p className="text-gray-400 font-montserrat">Generate structured AI summaries for your historical journal entries</p>
          </div>
        </div>

        {/* Stats Section */}
        {stats && (
          <div className="mb-6 p-4 bg-gray-800/30 rounded-lg">
            <h3 className="text-lg font-montserrat font-semibold text-white mb-3">Summary Statistics</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-adamina text-blue-400">{stats.totalEntryDates}</div>
                <div className="text-sm text-gray-400">Days with Entries</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-adamina text-green-400">{stats.totalSummaries}</div>
                <div className="text-sm text-gray-400">AI Dimension Summaries</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-adamina text-orange-400">{stats.missingDates.length}</div>
                <div className="text-sm text-gray-400">Missing Summaries</div>
              </div>
            </div>
            
            {stats.missingDates.length > 0 && (
              <div className="mt-4">
                <h4 className="text-sm font-montserrat font-medium text-gray-300 mb-2">Dates Missing Dimension Summaries:</h4>
                <div className="flex flex-wrap gap-2">
                  {stats.missingDates.map((date: string) => (
                    <span key={date} className="px-2 py-1 bg-orange-500/20 text-orange-300 rounded text-xs font-montserrat">
                      {new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Action Button */}
        <div className="mb-6">
          <button
            onClick={handleGenerateSummaries}
            disabled={loading || (stats && stats.missingDates.length === 0)}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-montserrat font-medium rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                Generating Dimension Summaries...
              </>
            ) : (
              <>
                <Brain className="w-5 h-5" />
                Generate Missing Dimension Summaries
              </>
            )}
          </button>
          
          {stats && stats.missingDates.length === 0 && (
            <p className="text-sm text-green-400 mt-2">All available dates already have AI dimension summaries!</p>
          )}
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <span className="text-red-400 font-montserrat">{error}</span>
          </div>
        )}

        {/* Results Display */}
        {results && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-green-400 font-montserrat font-medium">{results.message}</span>
            </div>
            
            {results.summaries && results.summaries.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-lg font-montserrat font-semibold text-white">Processing Results:</h4>
                {results.summaries.map((summary: any, index: number) => (
                  <div key={index} className={`p-3 rounded-lg border ${
                    summary.success 
                      ? 'bg-green-500/10 border-green-500/20' 
                      : 'bg-red-500/10 border-red-500/20'
                  }`}>
                    <div className="flex items-center gap-2">
                      {summary.success ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-400" />
                      )}
                      <span className="font-montserrat font-medium text-white">
                        {new Date(summary.date).toLocaleDateString('en-US', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </span>
                    </div>
                    <p className={`text-sm mt-1 ${
                      summary.success ? 'text-green-300' : 'text-red-300'
                    }`}>
                      {summary.success ? summary.message : summary.error}
                    </p>
                    
                    {/* Show dimensions if successful */}
                    {summary.success && summary.dimensions && summary.dimensions.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {summary.dimensions.map((dimension: string, dimIndex: number) => {
                          const IconComponent = dimensionIcons[dimension] || Brain;
                          return (
                            <div key={dimIndex} className="flex items-center gap-1 px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs">
                              <IconComponent className="w-3 h-3" />
                              <span>{dimension}</span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SummaryGenerator;