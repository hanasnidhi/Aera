import React from 'react';
import { TrendingUp, BarChart3, Calendar, Clock, Hash, BookOpen, User, Settings, ChevronLeft, ChevronRight, Target, TrendingDown, Award, Zap, ChevronDown, Brain, Loader, Sparkles, Heart, Lightbulb, Eye, Users, Star } from 'lucide-react';
import DailySummary from './DailySummary';
import ProfileSettings from './ProfileSettings';
import DimensionFrequency from './DimensionFrequency';
import InsightsView from './InsightsView';
import { useAuth } from '../contexts/AuthContext';
import { supabase, generateMonthlySummary, getMonthlySummaries, checkMonthlySummariesExist } from '../lib/supabase';

interface MainContentProps {
  currentView: string;
  isDarkMode: boolean;
}

const MainContent: React.FC<MainContentProps> = ({ currentView, isDarkMode }) => {
  const { user } = useAuth();
  const [currentDate, setCurrentDate] = React.useState(new Date());
  const [selectedDate, setSelectedDate] = React.useState<Date | null>(null);
  const [showDailySummary, setShowDailySummary] = React.useState(false);
  const [monthEntries, setMonthEntries] = React.useState<{[key: string]: any[]}>({});
  const [monthEmotions, setMonthEmotions] = React.useState<{[key: string]: string}>({});
  const [loading, setLoading] = React.useState(false);
  
  // Monthly summary states
  const [selectedDimension, setSelectedDimension] = React.useState('Overall');
  const [monthlySummaries, setMonthlySummaries] = React.useState<{[key: string]: string}>({});
  const [loadingMonthlySummary, setLoadingMonthlySummary] = React.useState(false);
  const [showDimensionDropdown, setShowDimensionDropdown] = React.useState(false);

  // Emotion icons mapping for calendar
  const emotionIcons: { [key: string]: string } = {
    'Excitement': '/icons/Excitement.png',
    'Joy': '/icons/Joy.png',
    'Contentment': '/icons/Contentment.png',
    'Pride': '/icons/Pride.png',
    'Sad': '/icons/Sadness.png',
    'Anxiety': '/icons/Anxiety.png',
    'Inadequacy': '/icons/Inadequacy.png',
    'Regret': '/icons/Regret.png',
    'Anger': '/icons/Anger.png',
    'Emptiness': '/icons/Emptiness.png',
    'Restless': '/icons/Restlessness.png',
    'Overwhelm': '/icons/Overwhelm.png'
  };

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Available dimensions for monthly summary
  const availableDimensions = [
    'Overall',
    'Achievement', 
    'Introspection',
    'Memories',
    'Little Things',
    'Connections',
    'Major life event'
  ];

  const today = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  // Get first day of the month and number of days
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
  const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);
  const firstDayWeekday = firstDayOfMonth.getDay();
  const daysInMonth = lastDayOfMonth.getDate();

  // Get previous month's last days to fill the calendar
  const prevMonth = new Date(currentYear, currentMonth - 1, 0);
  const daysInPrevMonth = prevMonth.getDate();

  // Fetch entries for the current month
  const fetchMonthEntries = async () => {
    if (!user) return;

    try {
      setLoading(true);
      
      // Get first and last day of current month in YYYY-MM-DD format
      const firstDay = new Date(currentYear, currentMonth, 1);
      const lastDay = new Date(currentYear, currentMonth + 1, 0);
      
      const startDate = firstDay.toLocaleDateString('en-CA');
      const endDate = lastDay.toLocaleDateString('en-CA');
      
      console.log('Fetching entries for month:', { startDate, endDate, userId: user.id });
      
      const { data, error } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('user_id', user.id)
        .eq('entry_type', 'individual')
        .gte('entry_date', startDate)
        .lte('entry_date', endDate)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Supabase error fetching month entries:', error);
        return;
      }

      console.log('Fetched entries:', data);
      
      // Group entries by date
      const entriesByDate: {[key: string]: any[]} = {};
      if (data) {
        data.forEach(entry => {
          const dateKey = entry.entry_date;
          if (!entriesByDate[dateKey]) {
            entriesByDate[dateKey] = [];
          }
          entriesByDate[dateKey].push(entry);
        });
      }
      
      console.log('Entries grouped by date:', entriesByDate);
      setMonthEntries(entriesByDate);

      // Fetch emotions for the month
      const { data: summariesData, error: summariesError } = await supabase
        .from('summaries')
        .select('summary_date, emotions')
        .eq('user_id', user.id)
        .gte('summary_date', startDate)
        .lte('summary_date', endDate);

      if (summariesError) {
        console.error('Error fetching summaries:', summariesError);
      } else {
        // Extract dominant emotion for each date
        const emotionsByDate: {[key: string]: string} = {};
        summariesData?.forEach(summary => {
          if (summary.emotions && summary.emotions.length > 0) {
            // Get the first (dominant) emotion
            emotionsByDate[summary.summary_date] = summary.emotions[0].emotion;
          }
        });
        setMonthEmotions(emotionsByDate);
      }
    } catch (error) {
      console.error('Network error fetching month entries:', error);
      console.error('Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
      console.error('Supabase Key exists:', !!import.meta.env.VITE_SUPABASE_ANON_KEY);
    } finally {
      setLoading(false);
    }
  };

  // Fetch monthly summaries
  const fetchMonthlySummaries = async () => {
    if (!user) return;

    try {
      const monthName = months[currentMonth];
      
      // Check if monthly summaries exist for this specific month/year
      const summariesExist = await checkMonthlySummariesExist(user.id, currentYear, monthName);
      
      if (!summariesExist) {
        // Clear existing summaries if we're looking at a different month
        setMonthlySummaries({});
      } else {
        // Fetch existing summaries
        const { data, error } = await getMonthlySummaries(user.id, currentYear, monthName);
        
        if (error) {
          console.error('Error fetching monthly summaries:', error);
          setMonthlySummaries({});
          return;
        }

        // Convert to object for easy access
        const summariesObj: {[key: string]: string} = {};
        if (data) {
          data.forEach(summary => {
            summariesObj[summary.dimension] = summary.summary;
          });
        }
        
        setMonthlySummaries(summariesObj);
      }
    } catch (error) {
      console.error('Network error fetching monthly summaries:', error);
      setMonthlySummaries({});
    }
  };

  // Generate monthly summaries for current month
  const generateMonthlySummariesForCurrentMonth = async () => {
    if (!user) return;

    try {
      setLoadingMonthlySummary(true);
      const monthName = months[currentMonth];
      
      console.log(`Generating monthly summaries for ${monthName} ${currentYear}`);
      
      const result = await generateMonthlySummary(user.id, monthName, currentYear);
      
      if (result.summaries) {
        // Convert to object for easy access
        const summariesObj: {[key: string]: string} = {};
        result.summaries.forEach((summary: any) => {
          summariesObj[summary.dimension] = summary.summary;
        });
        
        setMonthlySummaries(summariesObj);
        console.log('Monthly summaries generated successfully');
      }
    } catch (error) {
      console.error('Error generating monthly summaries:', error);
    } finally {
      setLoadingMonthlySummary(false);
    }
  };

  // Fetch entries when month/year changes or user changes
  React.useEffect(() => {
    fetchMonthEntries();
  }, [currentMonth, currentYear, user]);

  // Fetch monthly summaries when month/year changes
  React.useEffect(() => {
    if (currentView === 'journals') {
      fetchMonthlySummaries();
    }
  }, [currentMonth, currentYear, user, currentView]);

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const navigateYear = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setFullYear(prev.getFullYear() - 1);
      } else {
        newDate.setFullYear(prev.getFullYear() + 1);
      }
      return newDate;
    });
  };

  const isToday = (day: number) => {
    return today.getDate() === day && 
           today.getMonth() === currentMonth && 
           today.getFullYear() === currentYear;
  };

  const isSelected = (day: number) => {
    if (!selectedDate) return false;
    return selectedDate.getDate() === day && 
           selectedDate.getMonth() === currentMonth && 
           selectedDate.getFullYear() === currentYear;
  };

  const selectDate = (day: number) => {
    const selected = new Date(currentYear, currentMonth, day);
    setSelectedDate(selected);
    
    // Check if this date has entries
    const dateKey = selected.toLocaleDateString('en-CA');
    const hasEntries = monthEntries[dateKey] && monthEntries[dateKey].length > 0;
    
    console.log('Date selected:', dateKey, 'Has entries:', hasEntries);
    
    if (hasEntries) {
      setShowDailySummary(true);
    }
  };

  const handleBackToCalendar = () => {
    setShowDailySummary(false);
  };

  // Check if current month has any entries
  const hasEntriesForCurrentMonth = () => {
    return Object.keys(monthEntries).length > 0;
  };

  // Check if monthly summaries exist for current month
  const hasMonthlySummariesForCurrentMonth = () => {
    return Object.keys(monthlySummaries).length > 0;
  };

  // Determine if we should show generate button
  const shouldShowGenerateButton = () => {
    const hasEntries = hasEntriesForCurrentMonth();
    const hasSummaries = hasMonthlySummariesForCurrentMonth();
    return hasEntries && !hasSummaries;
  };

  const renderCalendarDays = () => {
    const days = [];
    
    // Previous month's trailing days
    for (let i = 0; i < firstDayWeekday; i++) {
      const day = daysInPrevMonth - firstDayWeekday + i + 1;
      days.push(
        <button
          key={`prev-${day}`}
          className={`w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 flex items-center justify-center text-xs sm:text-sm ${isDarkMode ? 'text-gray-600 hover:text-gray-400' : 'text-gray-400 hover:text-gray-600'} transition-colors duration-200 rounded-full`}
          disabled
        >
          {day}
        </button>
      );
    }

    // Current month's days
    for (let day = 1; day <= daysInMonth; day++) {
      const isTodayDate = isToday(day);
      
      // Check if this day has entries
      const dayDate = new Date(currentYear, currentMonth, day);
      const dateKey = dayDate.toLocaleDateString('en-CA');
      const hasEntries = monthEntries[dateKey] && monthEntries[dateKey].length > 0;
      const emotion = monthEmotions[dateKey];
      
      days.push(
        <button
          key={day}
          onClick={() => hasEntries && selectDate(day)}
          className={`
            w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 flex items-center justify-center text-xs sm:text-sm md:text-base font-montserrat font-medium rounded-full transition-all duration-200 border-2
            relative flex-col
            ${isTodayDate 
              ? 'border-transparent text-white' 
              : hasEntries
              ? isDarkMode 
                ? 'border-transparent hover:scale-105 cursor-pointer text-white'
                : 'border-transparent hover:scale-105 cursor-pointer text-gray-900'
              : isDarkMode
              ? 'text-gray-300 border-transparent hover:bg-gray-800/50 hover:text-white'
              : 'text-gray-700 border-transparent hover:bg-gray-100/50 hover:text-gray-900'
            }
          `}
        >
          {/* Emotion Icon - Show emotion for entries, "No Emotion" for dates without entries */}
          {hasEntries ? (
            <>
              <div className="mb-2.5">
                <img
                  src={emotionIcons[emotion] || '/icons/No Emotion.png'}
                  alt={emotion}
                  className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10"
                />
              </div>
              <span>{day}</span>
            </>
          ) : (
            <>
              <div className="mb-2.5">
                <img src="/icons/No Emotion.png" alt="No Entry" className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 opacity-30" />
              </div>
              <span>{day}</span>
            </>
          )}
        </button>
      );
    }

    // Next month's leading days
    // Calculate how many cells we need to complete the last row
    const totalDaysShown = firstDayWeekday + daysInMonth;
    const remainingCells = totalDaysShown % 7 === 0 ? 0 : 7 - (totalDaysShown % 7);
    
    for (let day = 1; day <= remainingCells; day++) {
      days.push(
        <button
          key={`next-${day}`}
          className={`w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 flex items-center justify-center text-xs sm:text-sm ${isDarkMode ? 'text-gray-600 hover:text-gray-400' : 'text-gray-400 hover:text-gray-600'} transition-colors duration-200 rounded-full`}
          disabled
        >
          {day}
        </button>
      );
    }

    return days;
  };

  const renderContent = () => {
    switch (currentView) {
      case 'new-entry':
        return (
          <div className="text-center max-w-3xl mx-auto px-4">
            <p className={`text-xl sm:text-2xl md:text-3xl font-adamina mb-16 ${isDarkMode ? 'text-gray-100' : 'text-gray-800'} leading-relaxed tracking-wide`}>
              Tell me anything. What's on your mind today?
            </p>
          </div>
        );

      case 'journals':
        if (showDailySummary && selectedDate) {
          return (
            <DailySummary 
              date={selectedDate}
              onBack={handleBackToCalendar}
              isDarkMode={isDarkMode}
            />
          );
        }
        
        return (
          <div className="w-full max-w-7xl px-4 sm:px-6 pb-8 lg:pt-[60px]">
            {/* Main Content Grid - Responsive layout with decreased gaps */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 lg:gap-6 h-full">
              {/* Calendar Section - Full width on mobile, 64% on desktop */}
              <div className="xl:col-span-8 overflow-hidden">
                <div className="lg:pl-6">
                  {/* Calendar Header - Responsive spacing and sizing */}
                  <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start gap-4 sm:gap-6 mb-4 sm:mb-6">
                      {/* Month Navigation */}
                      <div className="flex items-center gap-2 sm:gap-3">
                        <button
                          onClick={() => navigateMonth('prev')}
                          className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200`}
                        >
                          <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
                        </button>
                        <h2 className={`text-xl sm:text-2xl font-adamina ${isDarkMode ? 'text-white' : 'text-gray-900'} min-w-[120px] sm:min-w-[140px] text-center`}>
                          {months[currentMonth]}
                        </h2>
                        <button
                          onClick={() => navigateMonth('next')}
                          className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200`}
                        >
                          <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
                        </button>
                      </div>

                      {/* Year Navigation */}
                      <div className="flex items-center gap-2 sm:gap-3">
                        <button
                          onClick={() => navigateYear('prev')}
                          className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200`}
                        >
                          <ChevronLeft className="w-3 h-3 sm:w-4 sm:h-4" />
                        </button>
                        <span className={`text-lg sm:text-xl font-montserrat font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} min-w-[50px] sm:min-w-[60px] text-center`}>
                          {currentYear}
                        </span>
                        <button
                          onClick={() => navigateYear('next')}
                          className={`p-1.5 sm:p-2 ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800/50' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'} rounded-lg transition-all duration-200`}
                        >
                          <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                        </button>
                      </div>
                  </div>

                  {/* Calendar Subtitle */}
                  <div className="text-center mb-6">
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat`}>
                      Click on a date to view the day's summary
                    </p>
                  </div>

                  {/* Days of Week Header - Responsive sizing */}
                  <div className="grid grid-cols-7 gap-x-1 sm:gap-x-2 mb-3 sm:mb-4">
                    {daysOfWeek.map((day) => (
                      <div key={day} className="w-8 sm:w-10 md:w-12 flex justify-center py-2 sm:py-3">
                        <span className={`text-xs sm:text-sm font-montserrat font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {day}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Calendar Grid - Responsive spacing */}
                  <div className="grid grid-cols-7 gap-x-1 sm:gap-x-2 gap-y-6 sm:gap-y-8 md:gap-y-10 mb-4 sm:mb-6">
                    {renderCalendarDays()}
                  </div>

                  {/* Month Stats - Hidden on mobile, responsive grid and sizing on larger screens */}
                  <div className="hidden sm:grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-6">
                    {/* Total Entries */}
                    <div className={`flex items-center justify-between p-3 sm:p-4 ${isDarkMode ? 'bg-gray-800/30' : 'bg-white/80 shadow-sm'} rounded-lg`}>
                      <div className="flex items-center gap-2 sm:gap-3">
                        <div className={`w-5 h-5 sm:w-6 sm:h-6 ${isDarkMode ? 'bg-blue-500/20' : 'bg-blue-100'} rounded-lg flex items-center justify-center`}>
                          <BookOpen className={`w-2.5 h-2.5 sm:w-3 sm:h-3 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                        </div>
                        <div>
                          <p className={`text-xs sm:text-sm font-montserrat ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Entries</p>
                          <p className={`text-xs sm:text-sm font-montserrat font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                            {Object.values(monthEntries).reduce((total, entries) => total + entries.length, 0)}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs sm:text-sm text-green-500 font-montserrat">+15%</p>
                      </div>
                    </div>

                    {/* Words Written */}
                    <div className={`flex items-center justify-between p-3 sm:p-4 ${isDarkMode ? 'bg-gray-800/30' : 'bg-white/80 shadow-sm'} rounded-lg`}>
                      <div className="flex items-center gap-2 sm:gap-3">
                        <div className={`w-5 h-5 sm:w-6 sm:h-6 ${isDarkMode ? 'bg-teal-500/20' : 'bg-teal-100'} rounded-lg flex items-center justify-center`}>
                          <Hash className={`w-2.5 h-2.5 sm:w-3 sm:h-3 ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`} />
                        </div>
                        <div>
                          <p className={`text-xs sm:text-sm font-montserrat ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Words</p>
                          <p className={`text-xs sm:text-sm font-montserrat font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                            {Object.values(monthEntries).reduce((total, entries) => 
                              total + entries.reduce((entryTotal, entry) => entryTotal + entry.word_count, 0), 0
                            ).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs sm:text-sm text-green-500 font-montserrat">+28%</p>
                      </div>
                    </div>

                    {/* Recording Time */}
                    <div className={`flex items-center justify-between p-3 sm:p-4 ${isDarkMode ? 'bg-gray-800/30' : 'bg-white/80 shadow-sm'} rounded-lg`}>
                      <div className="flex items-center gap-2 sm:gap-3">
                        <div className={`w-5 h-5 sm:w-6 sm:h-6 ${isDarkMode ? 'bg-purple-500/20' : 'bg-purple-100'} rounded-lg flex items-center justify-center`}>
                          <Clock className={`w-2.5 h-2.5 sm:w-3 sm:h-3 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
                        </div>
                        <div>
                          <p className={`text-xs sm:text-sm font-montserrat ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Time</p>
                          <p className={`text-xs sm:text-sm font-montserrat font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                            {(() => {
                              const totalMs = Object.values(monthEntries).reduce((total, entries) => 
                                total + entries.reduce((entryTotal, entry) => entryTotal + entry.duration_ms, 0), 0
                              );
                              const hours = Math.floor(totalMs / 3600000);
                              const minutes = Math.floor((totalMs % 3600000) / 60000);
                              return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
                            })()}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs sm:text-sm text-green-500 font-montserrat">+12%</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Divider between calendar and monthly summary */}
              <div className="hidden xl:block xl:col-span-12 border-t border-[#10141B] mb-6"></div>

              {/* Right Side Column - Full width on mobile, 36% on desktop */}
              <div className="xl:col-span-4 mt-3 xl:mt-0">
                <div>
                  {/* Monthly Summary Section - Updated layout */}
                  <div className="mb-3">
                    <h3 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3 sm:mb-4`}>Monthly Summary</h3>
                    
                    <div className="flex items-center justify-between mb-3 sm:mb-4">
                      
                      {/* Dimension Dropdown - Always on the right */}
                      <div className="relative">
                        <button
                          onClick={() => setShowDimensionDropdown(!showDimensionDropdown)}
                          className={`flex items-center gap-2 px-4 py-2 ${isDarkMode ? 'bg-gray-800/50 border-gray-700/50 text-gray-300 hover:text-white hover:bg-gray-800/70' : 'bg-white border-gray-300 text-gray-700 hover:text-gray-900 hover:bg-gray-50'} border rounded-md text-sm font-montserrat transition-all duration-200`}
                        >
                          {selectedDimension}
                          <ChevronDown className="w-4 h-4" />
                        </button>
                        
                        {showDimensionDropdown && (
                          <>
                            <div
                              className="fixed inset-0 z-10"
                              onClick={() => setShowDimensionDropdown(false)}
                            />
                            <div className={`absolute top-full right-0 mt-1 w-48 ${isDarkMode ? 'bg-gray-900/95 border-gray-700/50' : 'bg-white border-gray-300'} backdrop-blur-md border rounded-lg shadow-xl z-20`}>
                              {availableDimensions.map((dimension) => (
                                <button
                                  key={dimension}
                                  onClick={() => {
                                    setSelectedDimension(dimension);
                                    setShowDimensionDropdown(false);
                                  }}
                                  className={`w-full text-left px-3 py-2 text-sm font-montserrat transition-colors duration-200 first:rounded-t-lg last:rounded-b-lg ${
                                    selectedDimension === dimension
                                      ? isDarkMode ? 'bg-blue-500/20 text-blue-300' : 'bg-blue-50 text-blue-700'
                                      : isDarkMode ? 'text-gray-300 hover:text-white hover:bg-gray-800/50' : 'text-gray-700 hover:text-gray-900 hover:bg-gray-50'
                                  }`}
                                >
                                  {dimension}
                                </button>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                    
                    {/* Monthly Summary Content - Font weight medium and size 14px */}
                    <div className={`min-h-[150px] sm:min-h-[200px] overflow-y-auto ${isDarkMode ? 'text-white' : 'text-gray-900'} font-montserrat font-medium leading-relaxed space-y-3 text-sm border-0 bg-black`}>
                      {loadingMonthlySummary ? (
                        <div className="flex items-center gap-2 py-4">
                          <Loader className={`w-3 h-3 sm:w-4 sm:h-4 animate-spin ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                          <span className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Generating AI summary...</span>
                        </div>
                      ) : monthlySummaries[selectedDimension] ? (
                        <div className="whitespace-pre-line">
                          {monthlySummaries[selectedDimension]}
                        </div> 
                      ) : (
                        <div className="py-4 sm:py-6 border-0 bg-black">
                          {Object.keys(monthEntries).length === 0 ? (
                            <>
                              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                No Entries This Month
                              </p>
                            </>
                          ) : (
                            <>
                              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                No monthly summary
                              </p>
                            </>
                          )}
                          {shouldShowGenerateButton() && (
                            <button
                              onClick={generateMonthlySummariesForCurrentMonth}
                              disabled={loadingMonthlySummary} 
                              className="mt-3 flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-montserrat font-medium rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-xs sm:text-sm"
                            >
                              <Sparkles className="w-3 h-3 sm:w-4 sm:h-4" />
                              Generate AI Summary
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Dimension Frequency Visualization - Reduced gap and matching title style */}
                  <div className="mt-0">
                    <h4 className={`text-xl font-adamina font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-3 sm:mb-4`}>Your Dimensions</h4>
                    <DimensionFrequency 
                      currentMonth={currentMonth}
                      currentYear={currentYear}
                      isDarkMode={isDarkMode}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'insights':
        return (
          <InsightsView isDarkMode={isDarkMode} />
        );

      case 'profile':
        return (
          <ProfileSettings isDarkMode={isDarkMode} />
        );

      default:
        return (
          <div className="text-center max-w-3xl mx-auto px-4">
            <p className={`text-xl sm:text-2xl md:text-3xl font-adamina mb-16 ${isDarkMode ? 'text-gray-100' : 'text-gray-800'} leading-relaxed tracking-wide`}>
              Tell me anything. What's on your mind today?
            </p>
          </div>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col">
      {renderContent()}
    </div>
  );
};

export default MainContent;