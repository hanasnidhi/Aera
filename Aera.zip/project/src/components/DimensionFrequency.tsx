import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface DimensionFrequencyProps {
  currentMonth: number;
  currentYear: number;
  isDarkMode: boolean;
}

interface DimensionData {
  dimension: string;
  dayCount: number;
  filledBlocks: number;
  color: string;
}

const DimensionFrequency: React.FC<DimensionFrequencyProps> = ({ currentMonth, currentYear, isDarkMode }) => {
  const { user } = useAuth();
  const [dimensionData, setDimensionData] = useState<DimensionData[]>([]);
  const [loading, setLoading] = useState(false);

  // Dimension configuration with colors from the requirements
  const dimensionConfig = [
    { dimension: 'Introspection', color: '#0C93FC' },
    { dimension: 'Achievement', color: '#2FA7C6' },
    { dimension: 'Memories', color: '#93A7F1' },
    { dimension: 'Little Things', color: '#08B5A8' },
    { dimension: 'Connections', color: '#8D51DA' }
  ];

  const emptyBlockColor = isDarkMode ? '#161616' : '#E5E7EB';

  useEffect(() => {
    if (user) {
      fetchDimensionFrequency();
    }
  }, [user, currentMonth, currentYear, isDarkMode]);

  const fetchDimensionFrequency = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Calculate date range for the month
      const startDate = new Date(currentYear, currentMonth, 1).toLocaleDateString('en-CA');
      const endDate = new Date(currentYear, currentMonth + 1, 0).toLocaleDateString('en-CA');

      console.log(`Fetching dimension frequency from ${startDate} to ${endDate}`);

      // Fetch dimension summaries for the month
      const { data: dimensionSummaries, error } = await supabase
        .from('dimension_summaries')
        .select('dimension, summary_date')
        .eq('user_id', user.id)
        .gte('summary_date', startDate)
        .lte('summary_date', endDate)
        .order('summary_date', { ascending: true });

      if (error) {
        console.error('Error fetching dimension summaries:', error);
        return;
      }

      // Count unique days for each dimension
      const dimensionDayCounts: { [key: string]: Set<string> } = {};
      
      if (dimensionSummaries) {
        dimensionSummaries.forEach(summary => {
          if (!dimensionDayCounts[summary.dimension]) {
            dimensionDayCounts[summary.dimension] = new Set();
          }
          dimensionDayCounts[summary.dimension].add(summary.summary_date);
        });
      }

      // Calculate filled blocks for each dimension (every 3 days = 1 block)
      const processedData: DimensionData[] = dimensionConfig.map(config => {
        const dayCount = dimensionDayCounts[config.dimension]?.size || 0;
        const filledBlocks = Math.round(dayCount / 3); // Round to nearest full block
        
        return {
          dimension: config.dimension,
          dayCount,
          filledBlocks: Math.min(filledBlocks, 10), // Cap at 10 blocks
          color: config.color
        };
      });

      setDimensionData(processedData);
      console.log('Dimension frequency data:', processedData);

    } catch (error) {
      console.error('Error fetching dimension frequency:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderBlocks = (filledCount: number, color: string) => {
    const blocks = [];
    
    for (let i = 0; i < 10; i++) {
      blocks.push(
        <div
          key={i}
          className="w-3 h-3 rounded-sm transition-all duration-300"
          style={{
            backgroundColor: i < filledCount ? color : emptyBlockColor,
            boxShadow: i < filledCount ? `0 0 4px ${color}40` : 'none'
          }}
        />
      );
    }
    
    return blocks;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-4">
        <div className={`w-4 h-4 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin`}></div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {dimensionData.map((data) => (
        <div key={data.dimension} className="flex items-center justify-between">
          {/* Dimension Label */}
          <div className="flex-1 min-w-0 mr-4">
            <span className={`text-sm font-montserrat font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {data.dimension}
            </span>
          </div>
          
          {/* Blocks Grid */}
          <div className="flex gap-1">
            {renderBlocks(data.filledBlocks, data.color)}
          </div>
        </div>
      ))}
      
      {/* Legend */}
      <div className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-600'} font-montserrat mt-3 pt-3 ${isDarkMode ? 'border-gray-700/30' : 'border-gray-300/30'} border-t`}>
        Each block represents ~3 days of entries for that dimension
      </div>
    </div>
  );
};

export default DimensionFrequency;