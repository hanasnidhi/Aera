import React, { useState, useRef } from 'react';
import ResponsiveRecordSlider from './ResponsiveRecordSlider';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Dimension {
  id: string;
  name: string;
  description: string;
  dialog: string;
  color: string;
}

interface DimensionSelectorProps {
  isDarkMode: boolean;
  recordingState: 'idle' | 'recording' | 'paused';
  onStartRecording: (dimension: Dimension) => void;
  sliderPosition: number;
  sliderRef: React.RefObject<HTMLDivElement>;
  handleRef: React.RefObject<HTMLDivElement>;
  handleMouseDown: (e: React.MouseEvent) => void;
  handleTouchStart: (e: React.TouchEvent) => void;
  isDragging: boolean;
  isSidebarCollapsed: boolean;
}

const dimensions: Dimension[] = [
  {
    id: 'aera',
    name: 'Āera',
    description: 'Open',
    dialog: 'Tell me anything. What\'s on your mind today?',
    color: '#93F3EC'
  },
  {
    id: 'una',
    name: 'Una',
    description: 'Emotion',
    dialog: 'How are you really feeling today? I\'ll hold space for you.',
    color: '#6B8BFF'
  },
  {
    id: 'mira',
    name: 'Mira',
    description: 'Introspection',
    dialog: 'What narratives do you have in your head right now?',
    color: '#0C93FC'
  },
  {
    id: 'rae',
    name: 'Rae',
    description: 'Achievement',
    dialog: 'What did you build or learn today? What are you proud of?',
    color: '#2FA7C6'
  },
  {
    id: 'nova',
    name: 'Nova',
    description: 'Memories',
    dialog: 'What did you do today that was fun? Share your little stories.',
    color: '#93A7F1'
  },
  {
    id: 'iko',
    name: 'Iko',
    description: 'Little Things',
    dialog: 'Tell me about the small pieces of poetry you found today. A sunset, A cafe, An old book...',
    color: '#08B5A8'
  },
  {
    id: 'mitri',
    name: 'Mitri',
    description: 'Connections',
    dialog: 'Who did you share laughter, deep conversations and a moment of belongingness with?',
    color: '#8D51DA'
  }
];

const DimensionSelector: React.FC<DimensionSelectorProps> = ({
  isDarkMode,
  recordingState,
  onStartRecording,
  sliderPosition,
  sliderRef,
  handleRef,
  handleMouseDown,
  handleTouchStart,
  isDragging,
  isSidebarCollapsed
}) => {
  const [selectedDimension, setSelectedDimension] = useState<Dimension>(dimensions[0]);
  const dimensionListRef = useRef<HTMLDivElement>(null);

  const handleDimensionSelect = (dimension: Dimension) => {
    setSelectedDimension(dimension);
  };

  const scrollDimensions = (direction: 'left' | 'right') => {
    if (dimensionListRef.current) {
      const scrollAmount = 120;
      const currentScroll = dimensionListRef.current.scrollLeft;
      const newScroll = direction === 'left' 
        ? currentScroll - scrollAmount 
        : currentScroll + scrollAmount;
      
      dimensionListRef.current.scrollTo({
        left: newScroll,
        behavior: 'smooth'
      });
    }
  };

  // Helper function to get Aera gradient colors
  const getAeraGradientStyle = () => {
    return {
      background: 'linear-gradient(to right, #FFFFFF, #90caf9, #4db6ac)'
    };
  };

  // Helper function to get Aera glow colors - now using teal
  const getAeraGlowStyle = (opacity: number, blur: number) => {
    return {
      background: `radial-gradient(circle, rgba(77, 182, 172, ${opacity}), transparent 70%)`,
      filter: `blur(${blur}px)`
    };
  };

  return (
    <>
      {/* Desktop Layout */}
      <div className="hidden lg:grid grid-cols-12 gap-8">
        {/* Left Column - 65% - Selected Dimension Details */}
        <div className="col-span-8 flex flex-col justify-between items-center relative">
          {/* Orb + Name & Description - Top section */}
          <div className="flex justify-center" style={{ paddingTop: '1.7rem' }}>
            <div className="flex items-center gap-4">
              {/* Animated Orb - smaller size */}
              <div className="relative flex items-center justify-center">
                {/* Background glow layers */}
                <div 
                  className="absolute inset-0 w-10 h-10 rounded-full animate-pulse"
                  style={selectedDimension.id === 'aera' 
                    ? getAeraGlowStyle(0.4, 8)
                    : {
                        background: `radial-gradient(circle, ${selectedDimension.color}40, transparent 70%)`,
                        filter: 'blur(6px)',
                        animationDuration: '3s'
                      }
                  }
                />
                <div 
                  className="absolute inset-0 w-10 h-10 rounded-full animate-pulse"
                  style={selectedDimension.id === 'aera'
                    ? getAeraGlowStyle(0.3, 12)
                    : {
                        background: `radial-gradient(circle, ${selectedDimension.color}30, transparent 60%)`,
                        filter: 'blur(10px)',
                        animationDuration: '4s',
                        animationDelay: '0.5s'
                      }
                  }
                />
                
                {/* Main dark orb */}
                <div 
                  className={`w-10 h-10 rounded-full relative z-10 ${isDarkMode ? 'bg-black' : 'bg-gray-900'}`}
                  style={selectedDimension.id === 'aera'
                    ? {
                        boxShadow: `0 0 16px #4db6ac60, inset 0 0 8px rgba(0, 0, 0, 0.3)`
                      }
                    : {
                        boxShadow: `0 0 16px ${selectedDimension.color}60, inset 0 0 8px rgba(0, 0, 0, 0.3)`
                      }
                  }
                />
              </div>

              {/* Name & Description - smaller size */}
              <div className="space-y-1">
                <h2 
                  className={`text-2xl font-adamina font-bold tracking-wide transition-all duration-500 ${
                    selectedDimension.id === 'aera' 
                      ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300'
                      : ''
                  }`}
                  style={selectedDimension.id === 'aera' ? {} : { color: selectedDimension.color }}
                >
                  {selectedDimension.name}
                </h2>
                <p className={`text-sm font-montserrat ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} transition-all duration-500`}>
                  {selectedDimension.description}
                </p>
              </div>
            </div>
          </div>

          {/* Main Dialog - Center section with flex-1 to take available space */}
          <div className="flex-1 flex items-center justify-center px-4">
            <div className="text-center max-w-4xl">
              <p className={`text-xl md:text-2xl lg:text-3xl font-adamina leading-relaxed tracking-wide ${isDarkMode ? 'text-gray-100' : 'text-gray-800'} transition-all duration-500`}>
                {selectedDimension.dialog}
              </p>
            </div>
          </div>

          {/* Responsive Record Slider - Bottom section */}
          <div className="pb-10 w-full">
            <ResponsiveRecordSlider
              isDarkMode={isDarkMode}
              isSidebarCollapsed={isSidebarCollapsed}
              selectedDimensionColor={selectedDimension.color}
              onRecordStart={() => onStartRecording(selectedDimension)}
            />
          </div>
        </div>

        {/* Right Column - 35% - Select Dimension */}
        <div className="col-span-4 flex flex-col justify-center">
          <div className="space-y-1">
            <div className="space-y-3">
              {dimensions.map((dimension) => {
                const isSelected = selectedDimension.id === dimension.id;
                
                return (
                  <button
                    key={dimension.id}
                    onClick={() => handleDimensionSelect(dimension)}
                    className={`w-full text-left p-4 rounded-xl transition-all duration-300 group ${
                      isSelected 
                        ? isDarkMode 
                          ? 'bg-gray-800/50 border border-gray-700/50' 
                          : 'bg-white/80 border border-gray-200/50 shadow-sm'
                        : isDarkMode
                          ? 'hover:bg-gray-800/30 border border-transparent hover:border-gray-700/30'
                          : 'hover:bg-white/60 border border-transparent hover:border-gray-200/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {/* Small orb indicator */}
                      <div 
                        className={`w-3 h-3 rounded-full transition-all duration-300 ${
                          isSelected ? 'opacity-100' : 'opacity-40 group-hover:opacity-70'
                        }`}
                        style={dimension.id === 'aera' && isSelected
                          ? getAeraGradientStyle()
                          : {
                              backgroundColor: dimension.color,
                              boxShadow: isSelected ? `0 0 10px ${dimension.color}60` : 'none'
                            }
                        }
                      />
                      
                      <div className="flex-1">
                        <h4 
                          className={`font-adamina font-bold text-lg transition-all duration-300 ${
                            isSelected 
                              ? dimension.id === 'aera'
                                ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300'
                                : ''
                              : isDarkMode 
                                ? 'text-gray-400 group-hover:text-gray-300' 
                                : 'text-gray-500 group-hover:text-gray-700'
                          }`}
                          style={isSelected && dimension.id !== 'aera' ? { color: dimension.color } : {}}
                        >
                          {dimension.name}
                        </h4>
                        <p className={`text-sm font-montserrat transition-all duration-300 ${
                          isSelected 
                            ? isDarkMode ? 'text-gray-300' : 'text-gray-700'
                            : isDarkMode 
                              ? 'text-gray-500 group-hover:text-gray-400' 
                              : 'text-gray-500 group-hover:text-gray-600'
                        }`}>
                          {dimension.description}
                        </p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile/Tablet Layout - Completely rebuilt for proper viewport handling */}
      <div className="lg:hidden w-full">
        {/* Mobile Container - Uses proper viewport units and flexible layout */}
        <div 
          className="flex flex-col w-full px-4"
          style={{ 
            minHeight: '100vh',
            paddingTop: '0',
            paddingBottom: 'max(env(safe-area-inset-bottom), 2rem)'
          }}
        >

          {/* Top Section: Dimension Header */}
          <div className="flex flex-col items-center pb-4" style={{ paddingTop: '1.7rem' }}>
            {/* Glowing Orb */}
            <div className="relative flex items-center justify-center mb-6">
              <div 
                className="absolute inset-0 w-16 h-16 rounded-full animate-pulse"
                style={selectedDimension.id === 'aera'
                  ? getAeraGlowStyle(0.4, 10)
                  : {
                      background: `radial-gradient(circle, ${selectedDimension.color}40, transparent 70%)`,
                      filter: 'blur(8px)',
                      animationDuration: '3s'
                    }
                }
              />
              <div 
                className="absolute inset-0 w-16 h-16 rounded-full animate-pulse"
                style={selectedDimension.id === 'aera'
                  ? getAeraGlowStyle(0.3, 15)
                  : {
                      background: `radial-gradient(circle, ${selectedDimension.color}30, transparent 60%)`,
                      filter: 'blur(12px)',
                      animationDuration: '4s',
                      animationDelay: '0.5s'
                    }
                }
              />
              
              {/* Main dark orb */}
              <div 
                className="w-16 h-16 rounded-full relative z-10 bg-black"
                style={selectedDimension.id === 'aera'
                  ? {
                      boxShadow: `0 0 24px #4db6ac60, inset 0 0 12px rgba(0, 0, 0, 0.3)`
                    }
                  : {
                      boxShadow: `0 0 24px ${selectedDimension.color}60, inset 0 0 12px rgba(0, 0, 0, 0.3)`
                    }
                }
              />
            </div>

            {/* Dimension Name & Category */}
            <div className="text-center">
              <h2 
                className={`text-3xl font-adamina font-bold tracking-wide mb-2 transition-all duration-500 ${
                  selectedDimension.id === 'aera'
                    ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300'
                    : ''
                }`}
                style={selectedDimension.id === 'aera' ? {} : { color: selectedDimension.color }}
              >
                {selectedDimension.name}
              </h2>
              <p className="text-sm font-montserrat text-gray-400 uppercase tracking-widest transition-all duration-500">
                {selectedDimension.description}
              </p>
            </div>
          </div>

          {/* Center Section: Prompt Text */}
          <div className="flex-1 flex items-center justify-center py-4 min-h-0">
            <div className="text-center max-w-xs">
              <p className="text-lg font-adamina leading-relaxed tracking-wide text-white transition-all duration-500">
                {selectedDimension.dialog}
              </p>
            </div>
          </div>
          {/* Dimension Selector - Horizontal scroll */}
          <div className="flex items-center gap-2 pb-4">
            {/* Left scroll button */}
              <button
                onClick={() => scrollDimensions('left')}
                className="flex-shrink-0 p-2 rounded-full transition-colors duration-200 text-gray-500 hover:text-gray-200 hover:bg-white/10"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {/* Scrollable List */}
              <div ref={dimensionListRef} className="flex-1 overflow-x-auto scrollbar-hide min-w-0">
                <div className="flex gap-8 py-3 px-4">
                  {dimensions.map((dimension) => {
                    const isSelected = selectedDimension.id === dimension.id;
                    
                    return (
                      <button
                        key={dimension.id}
                        onClick={() => handleDimensionSelect(dimension)}
                        className="flex-shrink-0 text-center transition-all duration-300"
                      >
                        <div className="space-y-2">
                          <h4 
                            className={`font-adamina font-bold text-lg transition-all duration-300 whitespace-nowrap ${
                              isSelected 
                                ? dimension.id === 'aera'
                                  ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300'
                                  : ''
                                : 'text-gray-500'
                            }`}
                            style={isSelected && dimension.id !== 'aera' ? { color: dimension.color } : {}}
                          >
                            {dimension.name}
                          </h4>
                          <p className={`text-xs font-montserrat transition-all duration-300 uppercase tracking-wider whitespace-nowrap ${
                            isSelected 
                              ? 'text-gray-300'
                              : 'text-gray-600'
                          }`}>
                            {dimension.description}
                          </p>
                          {/* Underline indicator */}
                          <div 
                            className={`h-0.5 w-full transition-all duration-300 rounded-full ${
                              isSelected ? 'opacity-100' : 'opacity-0'
                            }`}
                            style={isSelected && dimension.id === 'aera'
                              ? { background: 'linear-gradient(to right, #FFFFFF, #90caf9, #4db6ac)' }
                              : {
                                  backgroundColor: isSelected ? dimension.color : 'transparent'
                                }
                            }
                          />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Right scroll button */}
              <button
                onClick={() => scrollDimensions('right')}
                className="flex-shrink-0 p-2 rounded-full transition-colors duration-200 text-gray-500 hover:text-gray-200 hover:bg-white/10"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

          {/* Bottom Section: Record Slider */}
          <div className="pb-8">
            <ResponsiveRecordSlider
              isDarkMode={isDarkMode}
              isSidebarCollapsed={isSidebarCollapsed}
              selectedDimensionColor={selectedDimension.color}
              onRecordStart={() => onStartRecording(selectedDimension)}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default DimensionSelector;