import React, { useState } from 'react';
import { User, LogOut, Settings as SettingsIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const UserMenu: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { profile, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    setIsOpen(false);
  };

  if (!profile) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-gray-900/30 backdrop-blur-sm border border-gray-700/30 rounded-full hover:bg-gray-800/40 transition-all duration-300"
      >
        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center">
          <User className="w-4 h-4 text-white" />
        </div>
        <span className="text-sm font-montserrat text-gray-300 hidden sm:block">
          {profile.name}
        </span>
      </button>

      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-10"
            onClick={() => setIsOpen(false)}
          />
          
          {/* Menu */}
          <div className="absolute top-full right-0 mt-2 w-48 bg-gray-900/90 backdrop-blur-md border border-gray-700/30 rounded-lg shadow-xl z-20">
            <div className="p-3 border-b border-gray-700/30">
              <p className="text-sm font-montserrat text-white font-medium">
                {profile.name}
              </p>
              <p className="text-xs text-gray-400 truncate">
                {profile.email}
              </p>
            </div>
            
            <div className="p-1">
              <button
                onClick={() => setIsOpen(false)}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm font-montserrat text-gray-300 hover:text-white hover:bg-gray-800/50 rounded-md transition-all duration-200"
              >
                <SettingsIcon className="w-4 h-4" />
                Settings
              </button>
              
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm font-montserrat text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-md transition-all duration-200"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default UserMenu;