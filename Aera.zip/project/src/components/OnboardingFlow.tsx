import React, { useState } from 'react';
import { ChevronRight, ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface OnboardingFlowProps {
  isVisible: boolean;
  onComplete: () => void;
  userId: string;
  isDarkMode: boolean;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ 
  isVisible, 
  onComplete, 
  userId,
  isDarkMode 
}) => {
  const [currentQuestion, setCurrentQuestion] = useState(1);
  const [question1Responses, setQuestion1Responses] = useState<string[]>([]);
  const [question2Responses, setQuestion2Responses] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const question1Options = [
    "I want to document my life",
    "I want to live more mindfully and be aware of every day",
    "I want to be more intentional and live a balanced life",
    "I want to know the recurring thoughts and narratives in my head"
  ];

  const question2Options = [
    "My thoughts and introspections",
    "My feelings and emotions",
    "My achievements",
    "Memorable events",
    "Little things in every day"
  ];

  const handleQuestion1Selection = (option: string) => {
    setQuestion1Responses(prev => {
      if (prev.includes(option)) {
        return prev.filter(item => item !== option);
      } else {
        return [...prev, option];
      }
    });
  };

  const handleQuestion2Selection = (option: string) => {
    setQuestion2Responses(prev => {
      if (prev.includes(option)) {
        return prev.filter(item => item !== option);
      } else {
        return [...prev, option];
      }
    });
  };

  const handleNext = () => {
    if (question1Responses.length > 0) {
      setCurrentQuestion(2);
    }
  };

  const handleComplete = async () => {
    if (question2Responses.length === 0 || isSubmitting) return;

    try {
      setIsSubmitting(true);

      // Save onboarding responses to database
      const { error } = await supabase
        .from('onboarding_responses')
        .insert({
          user_id: userId,
          question_1_responses: question1Responses,
          question_2_responses: question2Responses
        });

      if (error) {
        console.error('Error saving onboarding responses:', error);
        // Continue to app even if saving fails
      }

      onComplete();
    } catch (error) {
      console.error('Error completing onboarding:', error);
      // Continue to app even if there's an error
      onComplete();
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black z-[99] flex items-center justify-center px-6">
      <div className="w-full max-w-2xl">
        {/* Logo */}
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-adamina text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300 tracking-wide">
            Āera
          </h1>
        </div>

        {currentQuestion === 1 ? (
          /* Question 1 */
          <div className="text-center space-y-8">
            {/* Question Title */}
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-adamina text-white tracking-wide">
                What brings you here
              </h1>
              <p className="text-base sm:text-lg font-montserrat text-[#959BA7]">
                Select all the options that apply
              </p>
            </div>

            {/* Options */}
            <div className="space-y-4">
              {question1Options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleQuestion1Selection(option)}
                  className={`w-full p-4 sm:p-5 rounded-xl border-2 transition-all duration-300 text-left ${
                    question1Responses.includes(option)
                      ? 'border-[#0C93FC] bg-[#0C93FC]/10 text-white'
                      : 'border-[#10141B] bg-[#07080C] text-[#959BA7] hover:border-[#0C93FC]/50 hover:text-white'
                  }`}
                >
                  <span className="font-montserrat text-sm sm:text-base">
                    {option}
                  </span>
                </button>
              ))}
            </div>

            {/* Next Button */}
            <div className="pt-6">
              <button
                onClick={handleNext}
                disabled={question1Responses.length === 0}
                className={`flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-montserrat font-medium text-white transition-all duration-300 ${
                  question1Responses.length > 0
                    ? 'bg-[#0C93FC] hover:bg-[#0C93FC]/90 cursor-pointer'
                    : 'bg-[#161616] cursor-not-allowed'
                }`}
              >
                Next
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        ) : (
          /* Question 2 */
          <div className="text-center space-y-8">
            {/* Question Title */}
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-adamina text-white tracking-wide">
                What do you hope to document here
              </h1>
              <p className="text-base sm:text-lg font-montserrat text-[#959BA7]">
                Select all the options that apply
              </p>
            </div>

            {/* Options */}
            <div className="space-y-4">
              {question2Options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleQuestion2Selection(option)}
                  className={`w-full p-4 sm:p-5 rounded-xl border-2 transition-all duration-300 text-left ${
                    question2Responses.includes(option)
                      ? 'border-[#0C93FC] bg-[#0C93FC]/10 text-white'
                      : 'border-[#10141B] bg-[#07080C] text-[#959BA7] hover:border-[#0C93FC]/50 hover:text-white'
                  }`}
                >
                  <span className="font-montserrat text-sm sm:text-base">
                    {option}
                  </span>
                </button>
              ))}
            </div>

            {/* Let's Go Button */}
            <div className="pt-6">
              <button
                onClick={handleComplete}
                disabled={question2Responses.length === 0 || isSubmitting}
                className={`flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-montserrat font-medium text-white transition-all duration-300 ${
                  question2Responses.length > 0 && !isSubmitting
                    ? 'bg-[#0C93FC] hover:bg-[#0C93FC]/90 cursor-pointer'
                    : 'bg-[#161616] cursor-not-allowed'
                }`}
              >
                <ArrowLeft className="w-5 h-5" />
                {isSubmitting ? 'Setting up...' : "Let's Go"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default OnboardingFlow;