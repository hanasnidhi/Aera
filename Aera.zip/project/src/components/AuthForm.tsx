import React, { useState } from 'react';
import { Eye, EyeOff, User, Mail, Lock, LogIn, UserPlus, ArrowLeft, Check } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface AuthFormProps {
  mode: 'signin' | 'signup';
  onToggleMode: () => void;
  isDarkMode: boolean;
}

const AuthForm: React.FC<AuthFormProps> = ({ mode, onToggleMode, isDarkMode }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [forgotPasswordLoading, setForgotPasswordLoading] = useState(false);
  const [forgotPasswordSent, setForgotPasswordSent] = useState(false);

  const { signIn, signUp } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null); // Clear any previous errors

    try {
      let result;
      if (mode === 'signup') {
        console.log('Attempting signup with email:', formData.email);
        result = await signUp(formData.email, formData.password, formData.name);
        console.log('Signup result:', result);
      } else {
        console.log('Attempting signin with email:', formData.email);
        result = await signIn(formData.email, formData.password);
        console.log('Signin result:', result);
      }

      if (result.error) {
        console.log('Auth error received:', result.error);
        
        // Handle specific error cases with more comprehensive checking
        let errorMessage = 'An error occurred';
        
        if (mode === 'signup') {
          // Check for various signup error patterns
          const errorMsg = result.error.message?.toLowerCase() || '';
          console.log('Checking signup error message:', errorMsg);
          
          if (errorMsg.includes('already registered') || 
              errorMsg.includes('already exists') ||
              errorMsg.includes('user already registered') ||
              errorMsg.includes('email already') ||
              errorMsg.includes('duplicate') ||
              errorMsg.includes('email address not confirmed') ||
              result.error.status === 422) {
            errorMessage = 'An account with this email already exists. Please sign in instead.';
          } else if (errorMsg.includes('password')) {
            errorMessage = 'Password must be at least 6 characters';
          } else if (errorMsg.includes('email')) {
            errorMessage = 'Please enter a valid email address';
          } else {
            errorMessage = result.error.message || 'Failed to create account';
          }
        } else {
          // Handle signin errors
          const errorMsg = result.error.message?.toLowerCase() || '';
          console.log('Checking signin error message:', errorMsg);
          
          if (errorMsg.includes('invalid login credentials') ||
              errorMsg.includes('invalid_credentials') ||
              errorMsg.includes('invalid email or password') ||
              errorMsg.includes('invalid user') ||
              errorMsg.includes('user not found')) {
            errorMessage = 'Invalid email or password. Please check your credentials and try again.';
          } else if (errorMsg.includes('email not confirmed')) {
            errorMessage = 'Please check your email and click the confirmation link before signing in.';
          } else if (errorMsg.includes('too many requests')) {
            errorMessage = 'Too many login attempts. Please wait a moment and try again.';
          } else {
            errorMessage = result.error.message || 'Failed to sign in';
          }
        }
        
        console.log('Setting error message:', errorMessage);
        setError(errorMessage);
      } else {
        console.log('Auth successful, no error');
        // Success - the auth context will handle navigation
      }
    } catch (err) {
      console.error('Unexpected error during auth:', err);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!forgotPasswordEmail.trim()) {
      setError('Please enter your email address');
      return;
    }

    if (!/\S+@\S+\.\S+/.test(forgotPasswordEmail)) {
      setError('Please enter a valid email address');
      return;
    }

    setForgotPasswordLoading(true);
    setError(null);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(forgotPasswordEmail, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) {
        console.error('Password reset error:', error);
        
        // Handle specific error cases
        const errorMsg = error.message?.toLowerCase() || '';
        let errorMessage = 'Failed to send reset email';
        
        if (errorMsg.includes('user not found') || errorMsg.includes('invalid email')) {
          errorMessage = 'No account found with this email address.';
        } else if (errorMsg.includes('too many requests')) {
          errorMessage = 'Too many reset requests. Please wait before trying again.';
        } else {
          errorMessage = error.message || 'Failed to send reset email';
        }
        
        setError(errorMessage);
      } else {
        setForgotPasswordSent(true);
      }
    } catch (err) {
      console.error('Unexpected error during password reset:', err);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setForgotPasswordLoading(false);
    }
  };

  const handleBackToSignIn = () => {
    setShowForgotPassword(false);
    setForgotPasswordSent(false);
    setForgotPasswordEmail('');
    setError(null);
  };

  const handleForgotPasswordEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForgotPasswordEmail(e.target.value);
    if (error) {
      setError(null);
    }
  };

  // Check if form is valid to enable/disable submit button
  const isFormValid = () => {
    if (mode === 'signup') {
      return formData.name.trim() !== '' && 
             formData.email.trim() !== '' && 
             formData.password.trim() !== '';
    } else {
      return formData.email.trim() !== '' && 
             formData.password.trim() !== '';
    }
  };

  // Show forgot password confirmation screen
  if (forgotPasswordSent) {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-black text-white' : 'bg-gray-50 text-gray-900'} flex items-center justify-center px-6`}>
        <div className={`absolute inset-0 ${isDarkMode ? 'bg-gradient-to-br from-gray-900/10 via-transparent to-purple-900/10' : 'bg-gradient-to-br from-blue-50/50 via-transparent to-teal-50/50'}`}></div>
        
        <div className="relative z-10 w-full max-w-md text-center">
          {/* Success Icon */}
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-8 h-8 text-green-400" />
          </div>
          
          {/* Header */}
          <h1 className="text-2xl sm:text-3xl font-adamina text-white tracking-wide mb-4">
            Check Your Email
          </h1>
          <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat mb-6 leading-relaxed`}>
            We've sent a password reset link to <span className="font-medium text-white">{forgotPasswordEmail}</span>. 
            Click the link in the email to reset your password.
          </p>
          
          {/* Additional Info */}
          <div className={`p-4 ${isDarkMode ? 'bg-gray-800/30 border-gray-700/30' : 'bg-white/80 border-gray-200/50'} border rounded-lg mb-6`}>
            <p className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} font-montserrat`}>
              Didn't receive the email? Check your spam folder or try again in a few minutes.
            </p>
          </div>
          
          {/* Back to Sign In */}
          <button
            onClick={handleBackToSignIn}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-montserrat font-medium rounded-lg transition-all duration-300 transform hover:scale-[1.02] mx-auto"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Sign In
          </button>
        </div>
      </div>
    );
  }

  // Show forgot password form
  if (showForgotPassword) {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-black text-white' : 'bg-gray-50 text-gray-900'} flex items-center justify-center px-6`}>
        <div className={`absolute inset-0 ${isDarkMode ? 'bg-gradient-to-br from-gray-900/10 via-transparent to-purple-900/10' : 'bg-gradient-to-br from-blue-50/50 via-transparent to-teal-50/50'}`}></div>
        
        <div className="relative z-10 w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-2xl sm:text-3xl font-adamina text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300 tracking-wide mb-2">
              Reset Password
            </h1>
            <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat`}>
              Enter your email to receive a reset link
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleForgotPassword} className="space-y-6">
            {/* Email field */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className={`h-5 w-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
              </div>
              <input
                type="email"
                required
                value={forgotPasswordEmail}
                onChange={handleForgotPasswordEmailChange}
                className={`w-full pl-10 pr-4 py-3 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30 text-white placeholder-gray-400 focus:ring-blue-500/50 focus:border-blue-500/50' : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-blue-500 focus:border-blue-500'} backdrop-blur-sm border rounded-lg focus:outline-none focus:ring-2 transition-all duration-300`}
                placeholder="Enter your email address"
              />
            </div>

            {/* Error message */}
            {error && (
              <div className={`${isDarkMode ? 'text-red-400 bg-red-500/10 border-red-500/20' : 'text-red-600 bg-red-50 border-red-200'} text-sm font-montserrat border rounded-lg p-3 animate-in fade-in duration-300`}>
                {error}
              </div>
            )}

            {/* Submit button */}
            <button
              type="submit"
              disabled={forgotPasswordLoading}
              className="w-full py-3 px-4 bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-montserrat font-medium rounded-lg transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-2"
            >
              {forgotPasswordLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  <Mail className="h-4 w-4" />
                  Send Reset Link
                </>
              )}
            </button>
          </form>

          {/* Back to sign in */}
          <div className="mt-6 text-center">
            <button
              onClick={handleBackToSignIn}
              className={`flex items-center gap-2 ${isDarkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'} font-montserrat font-medium transition-colors duration-200 mx-auto`}
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Sign In
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
    
    // Clear error when user starts typing
    if (error) {
      setError(null);
    }
  };

  // Main sign in/up form
  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-black text-white' : 'bg-gray-50 text-gray-900'} flex items-center justify-center px-6`}>
      <div className={`absolute inset-0 ${isDarkMode ? 'bg-gradient-to-br from-gray-900/10 via-transparent to-purple-900/10' : 'bg-gradient-to-br from-blue-50/50 via-transparent to-teal-50/50'}`}></div>
      
      <div className="relative z-10 w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-adamina text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300 tracking-wide mb-2">
            Āera
          </h1>
          <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat`}>
            {mode === 'signin' ? 'Welcome back' : 'Create your account'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name field - only for signup */}
          {mode === 'signup' && (
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className={`h-5 w-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
              </div>
              <input
                type="text"
                name="name"
                required
                value={formData.name}
                onChange={handleInputChange}
                className={`w-full pl-10 pr-4 py-3 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30 text-white placeholder-gray-400 focus:ring-blue-500/50 focus:border-blue-500/50' : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-blue-500 focus:border-blue-500'} backdrop-blur-sm border rounded-lg focus:outline-none focus:ring-2 transition-all duration-300`}
                placeholder="Full name"
              />
            </div>
          )}

          {/* Email field */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Mail className={`h-5 w-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
            </div>
            <input
              type="email"
              name="email"
              required
              value={formData.email}
              onChange={handleInputChange}
              className={`w-full pl-10 pr-4 py-3 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30 text-white placeholder-gray-400 focus:ring-blue-500/50 focus:border-blue-500/50' : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-blue-500 focus:border-blue-500'} backdrop-blur-sm border rounded-lg focus:outline-none focus:ring-2 transition-all duration-300`}
              placeholder="Email address"
            />
          </div>

          {/* Password field */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Lock className={`h-5 w-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              required
              value={formData.password}
              onChange={handleInputChange}
              className={`w-full pl-10 pr-12 py-3 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30 text-white placeholder-gray-400 focus:ring-blue-500/50 focus:border-blue-500/50' : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-blue-500 focus:border-blue-500'} backdrop-blur-sm border rounded-lg focus:outline-none focus:ring-2 transition-all duration-300`}
              placeholder="Password"
              minLength={6}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className={`absolute inset-y-0 right-0 pr-3 flex items-center ${isDarkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'} transition-colors duration-200`}
            >
              {showPassword ? (
                <EyeOff className="h-5 w-5" />
              ) : (
                <Eye className="h-5 w-5" />
              )}
            </button>
          </div>

          {/* Error message - Always visible when there's an error */}
          {error && (
            <div className={`${isDarkMode ? 'text-red-400 bg-red-500/10 border-red-500/20' : 'text-red-600 bg-red-50 border-red-200'} text-sm font-montserrat border rounded-lg p-3 animate-in fade-in duration-300 leading-relaxed`}>
              {error}
            </div>
          )}

          {/* Submit button */}
          <button
            type="submit"
            disabled={loading || !isFormValid()}
            className={`w-full py-3 px-4 ${isFormValid() ? 'bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600' : 'bg-[#161616]'} text-white font-montserrat font-medium rounded-lg transition-all duration-300 transform ${isFormValid() ? 'hover:scale-[1.02]' : ''} disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-2`}
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              <>
                {mode === 'signin' ? (
                  <LogIn className="h-5 w-5" />
                ) : (
                  <UserPlus className="h-5 w-5" />
                )}
                {mode === 'signin' ? 'Sign In' : 'Create Account'}
              </>
            )}
          </button>
        </form>

        {/* Forgot Password Link - Only show for sign in */}
        {mode === 'signin' && (
          <div className="mt-4 text-center">
            <button
              onClick={() => setShowForgotPassword(true)}
              className={`text-sm ${isDarkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'} font-montserrat font-medium transition-colors duration-200`}
            >
              Forgot your password?
            </button>
          </div>
        )}

        {/* Toggle mode */}
        <div className="mt-6 text-center">
          <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} font-montserrat text-sm`}>
            {mode === 'signin' ? "Don't have an account?" : 'Already have an account?'}
            <button
              onClick={onToggleMode}
              className={`ml-2 ${isDarkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'} font-medium transition-colors duration-200`}
            >
              {mode === 'signin' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;