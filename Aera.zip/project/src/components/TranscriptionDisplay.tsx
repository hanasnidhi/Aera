import React, { useState, useEffect } from 'react';

interface TranscriptionDisplayProps {
  transcript: string;
  interimTranscript: string;
  isRecording: boolean;
  isDarkMode: boolean;
}

const TranscriptionDisplay: React.FC<TranscriptionDisplayProps> = ({ 
  transcript, 
  interimTranscript, 
  isRecording,
  isDarkMode
}) => {
  const [displayWords, setDisplayWords] = useState<string[]>([]);
  const maxVisibleWords = 12; // Show last 12 words

  useEffect(() => {
    const fullText = transcript + interimTranscript;
    const words = fullText.split(' ').filter(word => word.length > 0);
    
    // Keep only the last maxVisibleWords
    const visibleWords = words.slice(-maxVisibleWords);
    setDisplayWords(visibleWords);
  }, [transcript, interimTranscript]);

  const renderWords = () => {
    if (displayWords.length === 0) {
      return (
        <div className="flex items-center justify-center min-h-[80px] sm:min-h-[120px]">
          {isRecording ? (
            <p className={`text-lg sm:text-xl font-adamina ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} tracking-wide italic`}>
              Start speaking...
            </p>
          ) : (
            <p className={`text-lg sm:text-xl font-adamina ${isDarkMode ? 'text-gray-500' : 'text-gray-500'} tracking-wide italic`}>
              Ready to resume...
            </p>
          )}
        </div>
      );
    }

    // Separate final and interim words
    const finalWords = transcript.split(' ').filter(word => word.length > 0);
    const interimWords = interimTranscript.split(' ').filter(word => word.length > 0);
    
    return (
      <div className="min-h-[80px] sm:min-h-[120px] flex flex-col justify-center">
        <div className="text-center space-y-2">
          {displayWords.map((word, index) => {
            const isInterim = index >= displayWords.length - interimWords.length;
            const wordAge = displayWords.length - index - 1;
            
            // Calculate opacity based on word age (newer words are brighter)
            let opacity = 1;
            if (!isInterim) {
              opacity = Math.max(0.3, 1 - (wordAge * 0.1));
            }
            
            return (
              <span
                key={`${word}-${index}`}
                className={`
                  inline-block mx-1 text-base sm:text-xl md:text-2xl font-adamina leading-relaxed tracking-wide font-light
                  transition-all duration-500 ease-out
                  ${isInterim 
                    ? isDarkMode ? 'text-white animate-pulse' : 'text-gray-900 animate-pulse'
                    : isDarkMode ? 'text-gray-100' : 'text-gray-800'
                  }
                `}
                style={{
                  opacity: isInterim ? 1 : opacity,
                  transform: `scale(${isInterim ? 1.05 : 1})`,
                  textShadow: isInterim ? (isDarkMode ? '0 0 10px rgba(255, 255, 255, 0.3)' : '0 0 10px rgba(0, 0, 0, 0.2)') : 'none'
                }}
              >
                {word}
              </span>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="text-center backdrop-blur-sm px-4">
      {renderWords()}
    </div>
  );
};

export default TranscriptionDisplay;