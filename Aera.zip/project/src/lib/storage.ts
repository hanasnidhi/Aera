import { supabase } from './supabase';

export interface PhotoUpload {
  file: File;
  preview: string;
  id: string;
}

export interface SavedPhoto {
  url: string;
  filename: string;
}

// Create storage bucket if it doesn't exist
export const initializeStorage = async () => {
  try {
    // Check if bucket exists
    const { data: buckets, error } = await supabase.storage.listBuckets();
    
    if (error) {
      console.error('Error checking storage buckets:', error);
      console.error('Error details:', {
        message: error.message,
        name: error.name,
        code: error.code,
        details: error.details,
        hint: error.hint,
        status: error.status
      });
      return;
    }
    
    const bucketExists = buckets?.some(bucket => bucket.name === 'journal-photos');
    
    if (!bucketExists) {
      console.warn('Storage bucket "journal-photos" not found. Please create it manually in your Supabase dashboard with the following settings:\n- Name: journal-photos\n- Public: true\n- Allowed MIME types: image/jpeg, image/png, image/webp, image/gif\n- File size limit: 10MB');
    } else {
      console.log('Storage bucket "journal-photos" found and ready');
    }
  } catch (error) {
    console.error('Error initializing storage:', error);
    console.error('Error details:', {
      name: error.name,
      message: error.message,
      stack: error.stack,
      // Log any additional properties that might be present
      ...error
    });
  }
};

// Generate a unique ID for photos
export const generateId = () => Math.random().toString(36).substr(2, 9);

// Upload photos to Supabase Storage with userId in path
export const uploadPhotos = async (userId: string, photos: PhotoUpload[], entryDate: string): Promise<SavedPhoto[]> => {
  const savedPhotos: SavedPhoto[] = [];
  
  console.log(`Uploading ${photos.length} photos for user ${userId} on date ${entryDate}`);
  console.log(`Supabase URL exists: ${!!supabase.supabaseUrl}`);
  console.log(`Supabase key length: ${supabase.supabaseKey?.length || 0}`);
  
  for (const photo of photos) {
    try {
      // Create filename with timestamp and original extension
      const timestamp = Date.now();
      // Sanitize extension - trim whitespace and ensure lowercase
      const rawExtension = photo.file.name.split('.').pop() || 'jpg';
      const extension = rawExtension.trim().toLowerCase();
      
      console.log(`Original extension: "${rawExtension}", Sanitized: "${extension}"`);
      
      const filename = `${timestamp}-${photo.id}.${extension}`;
      
      // Include userId in the file path for RLS compliance
      const filePath = `${userId}/${entryDate}/${filename}`;
      
      console.log(`Processing photo: ${photo.id}`);
      console.log(`File details:`, {
        name: photo.file.name,
        type: photo.file.type,
        size: photo.file.size || 'unknown',
        previewLength: photo.preview?.length || 0
      });
      console.log(`Target path: ${filePath}`);
      
      // Upload file to Supabase Storage
      const { data, error } = await supabase.storage
        .from('journal-photos')
        .upload(filePath, photo.file, {
          contentType: photo.file.type || 'image/jpeg',
          cacheControl: '3600',
          upsert: false
        });
      
      if (error) {
        console.error('Error uploading photo:', error);
        console.error('Error details:', {
          message: error.message,
          name: error.name,
          code: error.code,
          details: error.details,
          hint: error.hint,
          status: error.status
        });
        
        // Try again with explicit content type
        console.log('Retrying with explicit content type...');
        const { data: retryData, error: retryError } = await supabase.storage
          .from('journal-photos')
          .upload(filePath, photo.file, {
            contentType: 'image/jpeg',
            upsert: true
          });
          
        if (retryError) {
          console.error('Retry error:', retryError);
          console.error('Retry error details:', {
            message: retryError.message,
            name: retryError.name,
            code: retryError.code,
            details: retryError.details,
            hint: retryError.hint,
            status: retryError.status
          });
          throw retryError;
        } else {
          console.log('Retry successful:', retryData);
          data = retryData;
        }
      }
      
      console.log('Photo uploaded successfully:', data);
      
      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('journal-photos')
        .getPublicUrl(filePath);
      
      // Verify the URL doesn't have any spaces or problematic characters
      const sanitizedUrl = publicUrl.trim();
      console.log('Original URL:', publicUrl);
      console.log('Sanitized URL:', sanitizedUrl);
      
      savedPhotos.push({
        url: sanitizedUrl,
        filename: filename
      });
      
      console.log('Photo URL generated:', sanitizedUrl);
      
    } catch (error) {
      console.error('Error processing photo upload:', error);
      console.error('Error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack,
        code: error.code,
        // Log any additional properties that might be present
        ...error
      });
      throw error; // Re-throw to be handled by calling function
    }
  }
  
  console.log(`Successfully uploaded ${savedPhotos.length} photos`);
  return savedPhotos;
};

// Delete photo from storage
export const deletePhoto = async (photoUrl: string): Promise<boolean> => {
  try {
    // Extract file path from URL
    console.log(`Attempting to delete photo: ${photoUrl}`);
    
    const urlParts = photoUrl.split('/');
    const bucketIndex = urlParts.findIndex(part => part === 'journal-photos');
    
    if (bucketIndex === -1) {
      console.error('Could not find "journal-photos" in URL path:', photoUrl);
      return false;
    }
    
    const filePath = urlParts.slice(bucketIndex + 1).join('/');
    console.log(`Extracted file path: ${filePath}`);
    
    const { error } = await supabase.storage
      .from('journal-photos')
      .remove([filePath]);
    
    if (error) {
      console.error('Error deleting photo from storage:', error);
      console.error('Error details:', {
        message: error.message,
        name: error.name,
        code: error.code,
        details: error.details,
        hint: error.hint,
        status: error.status
      });
      return false;
    }
    
    console.log('Photo deleted successfully');
    return true;
  } catch (error) {
    console.error('Error deleting photo:', error);
    console.error('Error details:', {
      name: error.name,
      message: error.message,
      stack: error.stack,
      code: error.code,
      // Log any additional properties that might be present
      ...error
    });
    return false;
  }
};

// Get photos for a specific date
export const getPhotosForDate = async (userId: string, date: string): Promise<string[]> => {
  try {
    console.log(`Fetching photos for user ${userId} on date ${date}`);
    
    const { data, error } = await supabase
      .from('journal_entries')
      .select('photos')
      .eq('user_id', userId)
      .eq('entry_date', date)
      .eq('entry_type', 'individual');
    
    if (error) {
      console.error('Error fetching photos for date:', error);
      console.error('Error details:', {
        message: error.message,
        name: error.name,
        code: error.code,
        details: error.details,
        hint: error.hint,
        status: error.status
      });
      return [];
    }
    
    // Flatten all photos from all entries for this date
    const allPhotos = data?.reduce((acc, entry) => {
      if (entry.photos && Array.isArray(entry.photos)) {
        // Sanitize each URL to ensure no spaces or problematic characters
        const sanitizedPhotos = entry.photos.map(url => url.trim());
        return [...acc, ...sanitizedPhotos];
      }
      return acc;
    }, [] as string[]) || [];
    
    console.log(`Found ${allPhotos.length} photos for date ${date}`);
    if (allPhotos.length > 0) {
      console.log(`First photo URL: ${allPhotos[0]}`);
    }
    
    return allPhotos;
  } catch (error) {
    console.error('Error getting photos for date:', error);
    console.error('Error details:', {
      name: error.name,
      message: error.message,
      stack: error.stack,
      code: error.code,
      // Log any additional properties that might be present
      ...error
    });
    return [];
  }
};