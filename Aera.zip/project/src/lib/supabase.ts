import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

// Log configuration for debugging (without exposing sensitive data)
console.log('Supabase configuration:', {
  url: supabaseUrl,
  keyExists: !!supabaseAnonKey,
  keyLength: supabaseAnonKey?.length
});

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          name: string;
          email: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          name: string;
          email: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          email?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      journal_entries: {
        Row: {
          id: string;
          user_id: string;
          title: string | null;
          content: string;
          entry_date: string;
          word_count: number;
          duration_ms: number;
          entry_type: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          title?: string | null;
          content: string;
          entry_date?: string;
          word_count?: number;
          duration_ms?: number;
          entry_type?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          title?: string | null;
          content?: string;
          entry_date?: string;
          word_count?: number;
          duration_ms?: number;
          entry_type?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      summaries: {
        Row: {
          id: string;
          user_id: string;
          summary_date: string;
          content: string;
          emotions: Array<{ emotion: string; confidence: number }>;
          sections: any;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          summary_date: string;
          content: string;
          emotions?: Array<{ emotion: string; confidence: number }>;
          sections?: any;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          summary_date?: string;
          content?: string;
          emotions?: Array<{ emotion: string; confidence: number }>;
          sections?: any;
          created_at?: string;
          updated_at?: string;
        };
      };
      dimension_summaries: {
        Row: {
          id: string;
          user_id: string;
          summary_date: string;
          dimension: string;
          entry: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          summary_date: string;
          dimension: string;
          entry: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          summary_date?: string;
          dimension?: string;
          entry?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      monthly_summaries: {
        Row: {
          id: string;
          user_id: string;
          month: string;
          year: number;
          dimension: string;
          summary: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          month: string;
          year: number;
          dimension: string;
          summary: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          month?: string;
          year?: number;
          dimension?: string;
          summary?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
    Functions: {
      'gemini-proxy': {
        Args: {
          prompt: string;
          model?: string;
          maxTokens?: number;
          temperature?: number;
        };
        Returns: {
          text: string;
          model: string;
          usage: {
            promptTokens: number;
            completionTokens: number;
          };
        };
      };
      'analyze-daily-summary': {
        Args: {
          userId: string;
          date: string;
        };
        Returns: {
          message: string;
          dimensionCount?: number;
          dimensions?: string[];
          summaryId?: string;
        };
      };
      'generate-monthly-summary': {
        Args: {
          userId: string;
          month: string;
          year: number;
        };
        Returns: {
          message: string;
          summaries: any[];
        };
      };
    };
  };
};

// Helper function to call the Gemini proxy
export const callGeminiAPI = async (
  prompt: string,
  options?: {
    model?: string;
    maxTokens?: number;
    temperature?: number;
  }
) => {
  const { data, error } = await supabase.functions.invoke('gemini-proxy', {
    body: {
      prompt,
      model: options?.model || 'gemini-1.5-flash',
      maxTokens: options?.maxTokens || 1000,
      temperature: options?.temperature || 0.7,
    },
  });

  if (error) {
    throw new Error(`Gemini API error: ${error.message}`);
  }

  return data;
};

// Helper function to analyze daily summary
export const analyzeDailySummary = async (userId: string, date: string) => {
  const { data, error } = await supabase.functions.invoke('analyze-daily-summary', {
    body: {
      userId,
      date,
    },
  });

  if (error) {
    throw new Error(`Daily summary analysis error: ${error.message}`);
  }

  return data;
};

// Helper function to generate monthly summary
export const generateMonthlySummary = async (userId: string, month: string, year: number) => {
  const { data, error } = await supabase.functions.invoke('generate-monthly-summary', {
    body: {
      userId,
      month,
      year,
    },
  });

  if (error) {
    throw new Error(`Monthly summary generation error: ${error.message}`);
  }

  return data;
};

// Helper function to get summaries for a user
export const getUserSummaries = async (userId: string, limit?: number) => {
  let query = supabase
    .from('summaries')
    .select('*')
    .eq('user_id', userId)
    .order('summary_date', { ascending: false });

  if (limit) {
    query = query.limit(limit);
  }

  return query;
};

// Helper function to get summary for a specific date
export const getSummaryForDate = async (userId: string, date: string) => {
  return supabase
    .from('summaries')
    .select('*')
    .eq('user_id', userId)
    .eq('summary_date', date)
    .single();
};

// Helper function to get dimension summaries for a specific date
export const getDimensionSummariesForDate = async (userId: string, date: string) => {
  return supabase
    .from('dimension_summaries')
    .select('*')
    .eq('user_id', userId)
    .eq('summary_date', date)
    .order('dimension', { ascending: true });
};

// Helper function to get all dimension summaries for a user
export const getUserDimensionSummaries = async (userId: string, limit?: number) => {
  let query = supabase
    .from('dimension_summaries')
    .select('*')
    .eq('user_id', userId)
    .order('summary_date', { ascending: false })
    .order('dimension', { ascending: true });

  if (limit) {
    query = query.limit(limit);
  }

  return query;
};

// Helper function to get dimension summaries for a specific month
export const getDimensionSummariesForMonth = async (userId: string, year: number, month: number) => {
  const startDate = new Date(year, month - 1, 1).toLocaleDateString('en-CA');
  const endDate = new Date(year, month, 0).toLocaleDateString('en-CA');
  
  return supabase
    .from('dimension_summaries')
    .select('*')
    .eq('user_id', userId)
    .gte('summary_date', startDate)
    .lte('summary_date', endDate)
    .order('summary_date', { ascending: true });
};

// Helper function to get monthly summaries
export const getMonthlySummaries = async (userId: string, year: number, month: string) => {
  return supabase
    .from('monthly_summaries')
    .select('*')
    .eq('user_id', userId)
    .eq('year', year)
    .eq('month', month)
    .order('dimension', { ascending: true });
};

// Helper function to check if monthly summaries exist
export const checkMonthlySummariesExist = async (userId: string, year: number, month: string) => {
  try {
    const { data, error } = await supabase
      .from('monthly_summaries')
      .select('id')
      .eq('user_id', userId)
      .eq('year', year)
      .eq('month', month)
      .limit(1);

    if (error) {
      console.error('Error checking monthly summaries:', error);
      return false;
    }

    return data && data.length > 0;
  } catch (error) {
    console.error('Network error checking monthly summaries:', error);
    return false;
  }
};