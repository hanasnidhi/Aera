import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Mic, X, Pause, Play, Check, Settings as SettingsIcon } from 'lucide-react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { useDarkMode } from './hooks/useDarkMode';
import AuthForm from './components/AuthForm';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import TranscriptionDisplay from './components/TranscriptionDisplay';
import RecordingStats from './components/RecordingStats';
import JournalEditor from './components/JournalEditor';
import JournalsList from './components/JournalsList';
import DimensionSelector from './components/DimensionSelector';
import ResponsiveRecordSlider from './components/ResponsiveRecordSlider';
import SplashScreen from './components/SplashScreen';
import OnboardingFlow from './components/OnboardingFlow';
import { supabase, analyzeDailySummary } from './lib/supabase';

type RecordingState = 'idle' | 'recording' | 'paused';

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  abort(): void;
  onstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
}

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message: string;
}

declare global {
  interface Window {
    SpeechRecognition: {
      new(): SpeechRecognition;
    };
    webkitSpeechRecognition: {
      new(): SpeechRecognition;
    };
  }
}

function AudioJournalApp() {
  const { user, profile, loading, showSplash, showOnboarding, completeSplash, completeOnboarding } = useAuth();
  const { isDarkMode, toggleDarkMode } = useDarkMode();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  // State management
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [currentView, setCurrentView] = useState('new-entry');
  const [recordingState, setRecordingState] = useState<RecordingState>('idle');
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [recordingStartTime, setRecordingStartTime] = useState<number | null>(null);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [pausedDuration, setPausedDuration] = useState(0); // Track total paused time
  const [pauseStartTime, setPauseStartTime] = useState<number | null>(null); // Track when pause started
  const [wordCount, setWordCount] = useState(0);
  const [showJournalEditor, setShowJournalEditor] = useState(false);
  const [showJournalsList, setShowJournalsList] = useState(false);
  const [completedTranscript, setCompletedTranscript] = useState('');
  const [completedDuration, setCompletedDuration] = useState(0);
  const [completedWordCount, setCompletedWordCount] = useState(0);
  const [editingEntry, setEditingEntry] = useState<any>(null);
  const [selectedDimension, setSelectedDimension] = useState<any>(null);
  const [sliderPosition, setSliderPosition] = useState(0);
  
  // Refs
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const restartTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Determine if we should use centered layout (for recording/new-entry pages)
  const shouldCenterContent = (currentView === 'new-entry' && recordingState === 'idle') || recordingState !== 'idle';
  
  // Determine if recording controls should be visible (only on new-entry page during recording)
  const shouldShowRecordingControls = currentView === 'new-entry' && recordingState !== 'idle';

  // Recording functions
  const startRecording = useCallback(() => {
    console.log('Starting recording...');
    setRecordingState('recording');
    setTranscript('');
    setInterimTranscript('');
    
    const now = Date.now();
    setRecordingStartTime(now);
    setRecordingDuration(0);
    setPausedDuration(0);
    setPauseStartTime(null);
    
    setWordCount(0);
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current);
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (error) {
        console.error('Error starting recognition:', error);
      }
    }
  }, []);

  const handleDimensionStartRecording = useCallback((dimension: any) => {
    console.log('handleDimensionStartRecording called with dimension:', dimension);
    setSelectedDimension(dimension);
    console.log('selectedDimension state updated to:', dimension);
    startRecording();
  }, [startRecording]);

  const pauseRecording = useCallback(() => {
    console.log('Pausing recording...');
    setRecordingState('paused');
    setPauseStartTime(Date.now()); // Record when pause started
    
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current);
    }
    recognitionRef.current?.stop();
  }, []);

  const resumeRecording = useCallback(() => {
    console.log('Resuming recording...');
    setRecordingState('recording');
    
    // Add the paused time to total paused duration
    if (pauseStartTime) {
      const pauseTime = Date.now() - pauseStartTime;
      setPausedDuration(prev => prev + pauseTime);
      setPauseStartTime(null);
    }
    
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (error) {
        console.error('Error resuming recognition:', error);
      }
    }
  }, [pauseStartTime]);

  const completeRecording = useCallback(() => {
    // Combine final transcript with any remaining interim transcript
    const finalTranscript = (transcript + ' ' + interimTranscript).trim();
    console.log('Completing recording with transcript:', finalTranscript);
    console.log('Final transcript length:', finalTranscript.length);
    console.log('Original transcript:', transcript);
    console.log('Interim transcript:', interimTranscript);
    
    // Calculate final duration (subtract any paused time)
    let finalDuration = recordingDuration;
    if (pauseStartTime && recordingState === 'paused') {
      // If we're completing while paused, add the current pause time
      const currentPauseTime = Date.now() - pauseStartTime;
      finalDuration = recordingDuration - (pausedDuration + currentPauseTime);
    } else {
      finalDuration = recordingDuration - pausedDuration;
    }
    
    // Store the completed recording data
    setCompletedTranscript(finalTranscript);
    setCompletedDuration(Math.max(0, finalDuration)); // Ensure non-negative
    setCompletedWordCount(wordCount);
    
    // Reset recording state
    setRecordingState('idle');
    setSliderPosition(0);
    setTranscript(''); // Clear transcript
    setInterimTranscript(''); // Clear interim transcript
    setRecordingStartTime(null);
    setRecordingDuration(0);
    setPausedDuration(0);
    setPauseStartTime(null);
    
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current);
    }
    recognitionRef.current?.stop();
    
    // Show the journal editor
    setShowJournalEditor(true);
    
    console.log('Recording completed:', { transcript: finalTranscript, wordCount, duration: finalDuration });
  }, [transcript, interimTranscript, wordCount, recordingDuration, pausedDuration, pauseStartTime, recordingState]);

  const cancelRecording = useCallback(() => {
    setRecordingState('idle');
    setTranscript('');
    setInterimTranscript('');
    setRecordingStartTime(null);
    setRecordingDuration(0);
    setPausedDuration(0);
    setPauseStartTime(null);
    setWordCount(0);
    setSelectedDimension(null);
    setSliderPosition(0);
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current);
    }
    recognitionRef.current?.stop();
  }, []);

  // Journal functions
  const handleSaveJournal = async (content: string, title?: string, photoUrls?: string[]) => {
    if (!user) return;

    console.log('handleSaveJournal called with content:', content);
    console.log('Content length:', content.length);
    console.log('Photo URLs:', photoUrls);
    console.log('User ID:', user.id);

    try {
      const words = content.trim().split(/\s+/).filter(word => word.length > 0);
      
      let error;
      
      if (editingEntry) {
        console.log('Updating existing entry:', editingEntry.id);
        // Update existing entry
        const { error: updateError } = await supabase
          .from('journal_entries')
          .update({
            title: title || null,
            content: content,
            word_count: words.length,
            photos: photoUrls || [],
            updated_at: new Date().toISOString()
          })
          .eq('id', editingEntry.id);
        error = updateError;
      } else {
        console.log('Creating new entry');
        // Create new entry
        const { data, error: insertError } = await supabase
          .from('journal_entries')
          .insert({
            user_id: user.id,
            title: title || null,
            content: content,
            entry_date: new Date().toLocaleDateString('en-CA'), // YYYY-MM-DD format in local timezone
            word_count: words.length,
            duration_ms: completedDuration,
            entry_type: 'individual',
            photos: photoUrls || []
          })
          .select();
        error = insertError;
        console.log('Insert result:', { data, error });

        // If this is a new entry for today, trigger dimension analysis
        if (!error && data && data.length > 0) {
          const today = new Date().toLocaleDateString('en-CA');
          const entryDate = data[0].entry_date;
          
          // Only auto-generate for past dates, not today
          if (entryDate !== today) {
            console.log('Triggering dimension analysis for entry date:', entryDate);
            try {
              await analyzeDailySummary(user.id, entryDate);
              console.log('Dimension analysis completed for:', entryDate);
            } catch (analysisError) {
              console.warn('Dimension analysis failed:', analysisError);
              // Don't fail the save operation if analysis fails
            }
          }
        }
      }

      if (error) {
        console.error('Error saving journal entry:', error);
        throw error;
      }

      // Close editor and reset
      setShowJournalEditor(false);
      setCompletedTranscript('');
      setCompletedDuration(0);
      setCompletedWordCount(0);
      setEditingEntry(null);
      
      console.log(editingEntry ? 'Journal entry updated successfully' : 'Journal entry saved successfully');
      
      // Show success alert with navigation option
      const message = 'Journal entry saved successfully! You can find it on the Journals page.';
      if (typeof window !== 'undefined' && window.confirm(message + '\n\nView in Journals?')) {
        setCurrentView('journals');
      }
    } catch (error) {
      console.error('Error saving journal entry:', error);
      throw error;
    }
  };

  const handleCancelJournal = () => {
    setShowJournalEditor(false);
    setCompletedTranscript('');
    setCompletedDuration(0);
    setCompletedWordCount(0);
    setEditingEntry(null);
  };

  const handleNewJournalEntry = () => {
    setShowJournalsList(false);
    setCurrentView('new-entry');
    // Reset any existing state and return to main screen
  };

  const handleEditJournalEntry = (entry: any) => {
    setEditingEntry(entry);
    setCompletedTranscript(entry.content);
    setCompletedDuration(entry.duration_ms);
    setCompletedWordCount(entry.word_count);
    setShowJournalEditor(true);
    setShowJournalsList(false);
    setCurrentView('new-entry');
  };

  const handleViewChange = (view: string) => {
    // Cancel any ongoing recording when switching views
    if (recordingState !== 'idle') {
      cancelRecording();
    }
    
    setCurrentView(view);
    
    // Close journals list when switching views
    setShowJournalsList(false);
  };

  // Update word count whenever transcript changes
  useEffect(() => {
    const fullText = transcript + interimTranscript;
    const words = fullText.trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
  }, [transcript, interimTranscript]);

  // Update recording duration - only when recording (not when paused)
  useEffect(() => {
    console.log('Recording state changed to:', recordingState);
    if (recordingState === 'recording' && recordingStartTime) {
      durationIntervalRef.current = setInterval(() => {
        const currentTime = Date.now();
        const totalElapsed = currentTime - recordingStartTime;
        // Subtract any paused time from the total elapsed time
        setRecordingDuration(totalElapsed - pausedDuration);
      }, 100);
    } else {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    }

    return () => {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [recordingState, recordingStartTime, pausedDuration]);

  // Initialize speech recognition
  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      if (recognitionRef.current) {
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
          let finalTranscript = '';
          let interimTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcriptResult = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += transcriptResult;
            } else {
              interimTranscript += transcriptResult;
            }
          }

          if (finalTranscript) {
            console.log('Adding final transcript:', finalTranscript);
            setTranscript(prev => prev + finalTranscript);
          }
          console.log('Setting interim transcript:', interimTranscript);
          setInterimTranscript(interimTranscript);
        };

        recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
          console.error('Speech recognition error:', event.error);
          if (event.error === 'no-speech' && recordingState === 'recording') {
            restartTimeoutRef.current = setTimeout(() => {
              if (recordingState === 'recording' && recognitionRef.current) {
                try {
                  recognitionRef.current.start();
                } catch (error) {
                  console.error('Error restarting recognition:', error);
                }
              }
            }, 100);
          }
        };

        recognitionRef.current.onend = () => {
          if (recordingState === 'recording') {
            restartTimeoutRef.current = setTimeout(() => {
              if (recordingState === 'recording' && recognitionRef.current) {
                try {
                  recognitionRef.current.start();
                } catch (error) {
                  console.error('Error restarting recognition:', error);
                }
              }
            }, 50);
          }
        };
      }
    } else {
      console.warn('Speech recognition not supported in this browser');
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current);
      }
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [recordingState]);

  // Show splash screen if needed
  if (showSplash) {
    return <SplashScreen isVisible={showSplash} onComplete={completeSplash} />;
  }

  // Show onboarding flow if needed
  if (showOnboarding && user) {
    return (
      <OnboardingFlow 
        isVisible={showOnboarding} 
        onComplete={completeOnboarding}
        userId={user.id}
        isDarkMode={isDarkMode}
      />
    );
  }

  // Show loading screen while checking auth
  if (loading) {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-black text-white' : 'bg-gray-50 text-gray-900'} flex items-center justify-center px-4`}>
        <div className="text-center">
          <h1 className="text-2xl sm:text-3xl font-adamina text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 tracking-wide mb-4">
            Āera
          </h1>
          <div className={`w-6 h-6 sm:w-8 sm:h-8 border-2 ${isDarkMode ? 'border-blue-500/30 border-t-blue-500' : 'border-blue-400/30 border-t-blue-500'} rounded-full animate-spin mx-auto`}></div>
          <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mt-4`}>Loading...</p>
        </div>
      </div>
    );
  }

  // Show auth form if not authenticated
  if (!user) {
    return (
      <AuthForm 
        mode={authMode} 
        onToggleMode={() => setAuthMode(authMode === 'signin' ? 'signup' : 'signin')} 
        isDarkMode={isDarkMode}
      />
    );
  }

    return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-black text-white' : 'bg-gray-50 text-gray-900'} relative overflow-hidden`}>
      {/* Debug logs */}
      {console.log('Render - selectedDimension:', selectedDimension)}
      {console.log('Render - recordingState:', recordingState)}
      {console.log('Render - shouldShowRecordingControls:', shouldShowRecordingControls)}
      
      {/* The main flex container is removed. The Sidebar is now fully independent, 
        and the main content area will flow underneath it correctly.
      */}
      
      {/* Your Sidebar is self-sufficient and handles its own visibility. */}
      <Sidebar 
        currentView={currentView}
        onViewChange={handleViewChange}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
        isCollapsed={isSidebarCollapsed}
        setIsCollapsed={setIsSidebarCollapsed}
      />
      
      {/* Bolt Badge - Fixed position in top right */}
      <div className="fixed top-[1.35rem] right-4 sm:top-[1.65rem] sm:right-6 z-50">
        <a 
          href="https://bolt.new/" 
          target="_blank" 
          rel="noopener noreferrer"
        >
          <img 
            src="/boltbadge.png" 
            alt="Powered by Bolt" 
            className="w-8 h-8 sm:w-10 sm:h-10"
          />
        </a>
      </div>
      
      {/* Profile Icon - Fixed position in top right */}
      <div className="fixed top-[1.35rem] right-16 sm:top-[1.65rem] sm:right-20 z-50 lg:hidden">
        <button
          onClick={() => handleViewChange('profile')}
          className={`p-2 sm:p-3 ${isDarkMode ? 'bg-[#161616] border-[#10141B]' : 'bg-white border-gray-200'} border rounded-full transition-all duration-300 shadow-lg hover:shadow-xl`}
        >
          <SettingsIcon className="w-5 h-5 sm:w-5 sm:h-5 text-[#959BA7]" strokeWidth={1.5} />
        </button>
      </div>
      
      {/* Main content area */}
      {/* This div now only needs to worry about its own padding. */}
      <div className={`relative flex flex-1 flex-col min-h-screen transition-all duration-300 ease-in-out ${isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-80'}`}>
        
        {/*
          - We removed the extra mobile menu button from here.
          - We ensure consistent padding on all screen sizes (px-4 sm:px-6).
          - We add top padding (pt-20) to prevent the mobile menu button (from your sidebar) from overlapping content.
        */}
        <main className={`flex-1 flex flex-col w-full px-4 sm:px-6 pt-0 ${shouldCenterContent ? 'items-center justify-center' : ''}`}>
          {currentView === 'new-entry' && recordingState === 'idle' ? (
            <DimensionSelector
              isDarkMode={isDarkMode}
              recordingState={recordingState}
              onStartRecording={handleDimensionStartRecording}
              isSidebarCollapsed={isSidebarCollapsed}
              sliderPosition={sliderPosition}
              sliderRef={null}
              handleRef={null}
              handleMouseDown={() => {}}
              handleTouchStart={() => {}}
              isDragging={false}
            />
          ) : currentView !== 'new-entry' ? (
            <div className="w-full">
              <MainContent currentView={currentView} isDarkMode={isDarkMode} />
            </div>
          ) : (
            <div className="w-full max-w-6xl flex flex-col h-full">
              {/* Selected Dimension Display - Only show during recording */}
              {selectedDimension && recordingState !== 'idle' && (
                <div className="w-full flex items-center justify-center gap-3 mb-16" style={{ paddingTop: '1.7rem' }}>
                  {/* Animated Orb */}
                  <div className="relative flex items-center justify-center">
                    {/* Background glow layers */}
                    <div 
                      className="absolute inset-0 w-10 h-10 rounded-full animate-pulse"
                      style={selectedDimension.id === 'aera' 
                        ? {
                            background: `radial-gradient(circle, rgba(77, 182, 172, 0.4), transparent 70%)`,
                            filter: 'blur(8px)',
                            animationDuration: '3s'
                          }
                        : {
                            background: `radial-gradient(circle, ${selectedDimension.color}40, transparent 70%)`,
                            filter: 'blur(8px)',
                            animationDuration: '3s'
                          }
                      }
                    />
                    <div 
                      className="absolute inset-0 w-10 h-10 rounded-full animate-pulse"
                      style={selectedDimension.id === 'aera'
                        ? {
                            background: `radial-gradient(circle, rgba(77, 182, 172, 0.3), transparent 60%)`,
                            filter: 'blur(12px)',
                            animationDuration: '4s',
                            animationDelay: '0.5s'
                          }
                        : {
                            background: `radial-gradient(circle, ${selectedDimension.color}30, transparent 60%)`,
                            filter: 'blur(12px)',
                            animationDuration: '4s',
                            animationDelay: '0.5s'
                          }
                      }
                    />
                    
                    {/* Main dark orb */}
                    <div 
                      className={`w-10 h-10 rounded-full relative z-10 ${isDarkMode ? 'bg-black' : 'bg-gray-900'}`}
                      style={selectedDimension.id === 'aera'
                        ? {
                            boxShadow: `0 0 20px #4db6ac60, inset 0 0 10px rgba(0, 0, 0, 0.3)`
                          }
                        : {
                            boxShadow: `0 0 20px ${selectedDimension.color}60, inset 0 0 10px rgba(0, 0, 0, 0.3)`
                          }
                      }
                    />
                  </div>

                  {/* Name & Description */}
                  <div className="space-y-1">
                    <h2 
                      className={`text-2xl font-adamina font-bold tracking-wide transition-all duration-500 ${
                        selectedDimension.id === 'aera' 
                          ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-200 to-teal-300'
                          : ''
                      }`}
                      style={selectedDimension.id === 'aera' ? {} : { color: selectedDimension.color }}
                    >
                      {selectedDimension.name}
                    </h2>
                    <p className={`text-sm font-montserrat ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} transition-all duration-500`}>
                      {selectedDimension.description}
                    </p>
                  </div>
                </div>
              )}
              
              <div className="flex-1 flex items-center justify-center min-h-0 px-4">
                <TranscriptionDisplay 
                  transcript={transcript}
                  interimTranscript={interimTranscript}
                  isRecording={recordingState === 'recording'}
                  isDarkMode={isDarkMode}
                />
              </div>
            </div>
          )}
        </main>

        {/* Bottom Controls - They use the same padding logic as the main content div */}
        {shouldShowRecordingControls && (
          <div className={`fixed bottom-0 sm:bottom-8 left-0 right-0 z-20 transition-all duration-300 ease-in-out ${isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-80'}`}>
            <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4">
              {/* Recording Controls */}
              <div className="flex items-center justify-between">
                {/* Left: Duration */}
                <div className="flex-1 flex justify-start">
                  <RecordingStats 
                    duration={recordingDuration}
                    wordCount={wordCount}
                    isRecording={recordingState === 'recording'}
                    showOnlyTime={true}
                    isDarkMode={isDarkMode}
                  />
                </div>
                
                {/* Center: Control Buttons */}
                <div className="flex items-center gap-3 sm:gap-4">
                  {/* Cancel Button */}
                  <button
                    onClick={cancelRecording}
                    className={`p-3 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30 text-gray-400 hover:text-white hover:bg-gray-800/50' : 'bg-white/90 border-gray-300/50 text-gray-600 hover:text-gray-900 hover:bg-white'} backdrop-blur-sm border rounded-full transition-all duration-200`}
                  >
                    <X className="w-5 h-5" />
                  </button>
                  
                  {/* Play/Pause Button */}
                  <button
                    onClick={recordingState === 'recording' ? pauseRecording : resumeRecording}
                    className={`p-4 ${isDarkMode ? 'bg-gray-900/30 border-gray-700/30 text-white hover:bg-gray-800/50' : 'bg-white/90 border-gray-300/50 text-gray-900 hover:bg-white'} backdrop-blur-sm border rounded-full transition-all duration-200`}
                  >
                    {recordingState === 'recording' ? (
                      <Pause className="w-6 h-6" />
                    ) : (
                      <Play className="w-6 h-6" />
                    )}
                  </button>
                  
                  {/* Complete Button */}
                  <button
                    onClick={completeRecording}
                    className={`p-3 backdrop-blur-sm border rounded-full transition-all duration-200`}
                    style={selectedDimension ? {
                      backgroundColor: selectedDimension.id === 'aera' 
                        ? 'rgba(77, 182, 172, 0.2)'
                        : `${selectedDimension.color}20`,
                      borderColor: selectedDimension.id === 'aera'
                        ? 'rgba(77, 182, 172, 0.3)'
                        : `${selectedDimension.color}30`,
                      color: selectedDimension.id === 'aera'
                        ? '#4db6ac'
                        : selectedDimension.color
                    } : {
                      backgroundColor: isDarkMode ? 'rgba(34, 197, 94, 0.2)' : 'rgb(240, 253, 244)',
                      borderColor: isDarkMode ? 'rgba(34, 197, 94, 0.3)' : 'rgb(187, 247, 208)',
                      color: isDarkMode ? 'rgb(74, 222, 128)' : 'rgb(22, 163, 74)'
                    }}
                  >
                    <Check className="w-5 h-5" />
                  </button>
                </div>
                
                {/* Right: Word Count */}
                <div className="flex-1 flex justify-end">
                  <RecordingStats 
                    duration={recordingDuration}
                    wordCount={wordCount}
                    isRecording={recordingState === 'recording'}
                    showOnlyWords={true}
                    isDarkMode={isDarkMode}
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Journal Editor Modal */}
      <JournalEditor
        transcript={editingEntry ? editingEntry.content : completedTranscript}
        duration={completedDuration}
        wordCount={completedWordCount}
        userId={user?.id || ''}
        onSave={handleSaveJournal}
        onCancel={handleCancelJournal}
        isVisible={showJournalEditor}
        isSidebarCollapsed={isSidebarCollapsed}
        isDarkMode={isDarkMode}
      />
      
      {/* Journals List Modal */}
      <JournalsList
        isVisible={showJournalsList}
        onClose={() => setShowJournalsList(false)}
        onNewEntry={handleNewJournalEntry}
        onEditEntry={handleEditJournalEntry}
        isDarkMode={isDarkMode}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AudioJournalApp />
    </AuthProvider>
  );
}

export default App;