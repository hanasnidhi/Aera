import { supabase, analyzeDailySummary } from '../lib/supabase';

// Function to automatically generate summaries for missing historical dates
export const autoGenerateHistoricalSummaries = async (userId: string) => {
  try {
    console.log('Auto-generating historical summaries for user:', userId);
    
    // Get all unique dates that have journal entries
    const { data: entriesWithDates, error: entriesError } = await supabase
      .from('journal_entries')
      .select('entry_date')
      .eq('user_id', userId)
      .eq('entry_type', 'individual')
      .order('entry_date', { ascending: true });

    if (entriesError) {
      console.error('Error fetching journal entries:', entriesError);
      return;
    }

    if (!entriesWithDates || entriesWithDates.length === 0) {
      console.log('No journal entries found for auto-generation');
      return;
    }

    // Get unique dates
    const uniqueDates = [...new Set(entriesWithDates.map(entry => entry.entry_date))];
    
    // Get existing dimension summaries to avoid duplicates
    const { data: existingDimensions, error: dimensionsError } = await supabase
      .from('dimension_summaries')
      .select('summary_date')
      .eq('user_id', userId);

    if (dimensionsError) {
      console.error('Error fetching existing dimension summaries:', dimensionsError);
      return;
    }

    const existingDimensionDates = new Set(
      existingDimensions?.map(summary => summary.summary_date) || []
    );

    // Filter out dates that already have dimension summaries and today's date
    const today = new Date().toLocaleDateString('en-CA');
    const datesToProcess = uniqueDates.filter(date => 
      !existingDimensionDates.has(date) && date !== today
    );
    
    if (datesToProcess.length === 0) {
      console.log('No missing dimension summaries to generate');
      return;
    }

    console.log(`Auto-generating dimension summaries for ${datesToProcess.length} dates:`, datesToProcess);

    // Process each date with error handling
    for (const date of datesToProcess) {
      try {
        console.log(`Auto-generating dimension summary for date: ${date}`);
        
        const result = await analyzeDailySummary(userId, date);
        console.log(`Successfully generated dimension summary for ${date}:`, result.message);
        
        // Add a small delay between requests to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 2000));
        
      } catch (error) {
        console.error(`Error auto-generating dimension summary for date ${date}:`, error);
        // Continue with next date even if one fails
      }
    }

    console.log('Auto-generation of historical dimension summaries completed');

  } catch (error) {
    console.error('Error in autoGenerateHistoricalSummaries:', error);
  }
};

// Function to check and generate summary for yesterday (to be called daily)
export const generateYesterdaySummary = async (userId: string) => {
  try {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayString = yesterday.toLocaleDateString('en-CA');
    
    console.log('Checking if dimension summary needed for yesterday:', yesterdayString);
    
    // Check if dimension summaries already exist
    const { data: existingDimensions } = await supabase
      .from('dimension_summaries')
      .select('id')
      .eq('user_id', userId)
      .eq('summary_date', yesterdayString);

    if (existingDimensions && existingDimensions.length > 0) {
      console.log('Dimension summaries already exist for yesterday');
      return;
    }

    // Check if there are journal entries for yesterday
    const { data: entries } = await supabase
      .from('journal_entries')
      .select('id')
      .eq('user_id', userId)
      .eq('entry_date', yesterdayString)
      .eq('entry_type', 'individual');

    if (!entries || entries.length === 0) {
      console.log('No journal entries found for yesterday');
      return;
    }

    console.log(`Generating dimension summary for yesterday (${yesterdayString}) with ${entries.length} entries`);
    
    const result = await analyzeDailySummary(userId, yesterdayString);
    console.log('Successfully generated yesterday\'s dimension summary:', result.message);
    
  } catch (error) {
    console.error('Error generating yesterday\'s dimension summary:', error);
  }
};