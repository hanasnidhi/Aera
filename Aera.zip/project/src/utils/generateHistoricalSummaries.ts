import { supabase, analyzeDailySummary } from '../lib/supabase';

export const generateHistoricalSummaries = async (userId: string) => {
  try {
    console.log('Starting historical summary generation for user:', userId);
    
    // Get all unique dates that have journal entries but no dimension summaries
    const { data: entriesWithDates, error: entriesError } = await supabase
      .from('journal_entries')
      .select('entry_date')
      .eq('user_id', userId)
      .eq('entry_type', 'individual')
      .order('entry_date', { ascending: true });

    if (entriesError) {
      console.error('Error fetching journal entries:', entriesError);
      throw entriesError;
    }

    if (!entriesWithDates || entriesWithDates.length === 0) {
      console.log('No journal entries found');
      return { message: 'No journal entries found', summaries: [] };
    }

    // Get unique dates
    const uniqueDates = [...new Set(entriesWithDates.map(entry => entry.entry_date))];
    console.log('Found entries for dates:', uniqueDates);

    // Get existing dimension summaries to avoid duplicates
    const { data: existingDimensions, error: dimensionsError } = await supabase
      .from('dimension_summaries')
      .select('summary_date')
      .eq('user_id', userId);

    if (dimensionsError) {
      console.error('Error fetching existing dimension summaries:', dimensionsError);
      throw dimensionsError;
    }

    const existingDimensionDates = new Set(
      existingDimensions?.map(summary => summary.summary_date) || []
    );

    // Filter out dates that already have dimension summaries
    const datesToProcess = uniqueDates.filter(date => !existingDimensionDates.has(date));
    
    if (datesToProcess.length === 0) {
      console.log('All dates already have dimension summaries');
      return { message: 'All dates already have dimension summaries', summaries: [] };
    }

    console.log('Dates to process:', datesToProcess);

    const results = [];

    // Process each date
    for (const date of datesToProcess) {
      try {
        console.log(`Processing date: ${date}`);
        
        // Skip today's date (don't generate summary for current day)
        const today = new Date().toLocaleDateString('en-CA');
        if (date === today) {
          console.log(`Skipping today's date: ${date}`);
          continue;
        }

        const result = await analyzeDailySummary(userId, date);
        results.push({
          date,
          success: true,
          dimensionCount: result.dimensionCount || 0,
          dimensions: result.dimensions || [],
          message: result.message
        });
        
        console.log(`Successfully processed ${date}:`, result.message);
        
        // Add a small delay between requests to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        console.error(`Error processing date ${date}:`, error);
        results.push({
          date,
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    return {
      message: `Processed ${results.length} dates`,
      summaries: results
    };

  } catch (error) {
    console.error('Error in generateHistoricalSummaries:', error);
    throw error;
  }
};

// Helper function to get summary statistics
export const getSummaryStats = async (userId: string) => {
  try {
    // Get count of journal entries by date
    const { data: entryCounts, error: entryError } = await supabase
      .from('journal_entries')
      .select('entry_date')
      .eq('user_id', userId)
      .eq('entry_type', 'individual');

    if (entryError) throw entryError;

    // Get count of dimension summaries
    const { data: dimensionSummaries, error: dimensionError } = await supabase
      .from('dimension_summaries')
      .select('summary_date')
      .eq('user_id', userId);

    if (dimensionError) throw dimensionError;

    const uniqueEntryDates = [...new Set(entryCounts?.map(e => e.entry_date) || [])];
    const dimensionSummaryDates = [...new Set(dimensionSummaries?.map(s => s.summary_date) || [])];

    return {
      totalEntryDates: uniqueEntryDates.length,
      totalSummaries: dimensionSummaryDates.length,
      entryDates: uniqueEntryDates.sort(),
      summaryDates: dimensionSummaryDates.sort(),
      missingDates: uniqueEntryDates.filter(date => !dimensionSummaryDates.includes(date))
    };
  } catch (error) {
    console.error('Error getting summary stats:', error);
    throw error;
  }
};