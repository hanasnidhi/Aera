/*
# Storage RLS Policies for Journal Photos

1. Storage Policies
   - Allow authenticated users to upload photos to their own folders
   - Allow authenticated users to read photos from their own folders
   - Allow authenticated users to delete photos from their own folders

2. Security
   - Users can only access files in folders that match their user ID
   - Prevents unauthorized access to other users' photos
*/

-- Enable RLS on storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy for uploading photos (INSERT)
CREATE POLICY "Users can upload photos to own folder"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'journal-photos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy for viewing photos (SELECT)
CREATE POLICY "Users can view own photos"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'journal-photos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy for deleting photos (DELETE)
CREATE POLICY "Users can delete own photos"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'journal-photos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy for updating photos (UPDATE) - in case needed for metadata updates
CREATE POLICY "Users can update own photos"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'journal-photos' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'journal-photos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);