/*
  # Create Supabase storage bucket for journal photos

  1. Extension Setup
    - Enable supabase_storage extension to access storage functions

  2. Storage Bucket
    - Create 'journal-photos' bucket with public access
    - Set file size limit to 10MB
    - Allow common image formats

  3. Security Policies
    - Users can upload photos to their own folder (user_id/filename)
    - Users can read their own photos
    - Public read access for sharing
    - Users can delete/update their own photos
*/

-- Enable the supabase_storage extension to access storage functions
CREATE EXTENSION IF NOT EXISTS supabase_storage;

-- Create the storage bucket for journal photos with explicit type casting
DO $$
BEGIN
  -- Check if bucket already exists to avoid errors
  IF NOT EXISTS (
    SELECT 1 FROM storage.buckets WHERE id = 'journal-photos'
  ) THEN
    -- Create bucket with explicit text casting
    PERFORM storage.create_bucket(
      'journal-photos'::text,
      '{
        "public": true,
        "file_size_limit": 10485760,
        "allowed_mime_types": ["image/jpeg", "image/png", "image/gif", "image/webp", "image/jpg"]
      }'::jsonb
    );
  END IF;
END $$;

-- Create storage policies for the journal-photos bucket
-- We need to check if policies exist first since CREATE POLICY IF NOT EXISTS is not supported

-- Policy for authenticated users to upload photos to their own folder
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can upload own photos'
  ) THEN
    CREATE POLICY "Users can upload own photos"
      ON storage.objects
      FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

-- Policy for authenticated users to read their own photos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can read own photos'
  ) THEN
    CREATE POLICY "Users can read own photos"
      ON storage.objects
      FOR SELECT
      TO authenticated
      USING (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

-- Policy for public read access (for sharing photos)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Public can read photos'
  ) THEN
    CREATE POLICY "Public can read photos"
      ON storage.objects
      FOR SELECT
      TO public
      USING (bucket_id = 'journal-photos');
  END IF;
END $$;

-- Policy for authenticated users to delete their own photos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can delete own photos'
  ) THEN
    CREATE POLICY "Users can delete own photos"
      ON storage.objects
      FOR DELETE
      TO authenticated
      USING (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

-- Policy for authenticated users to update their own photos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can update own photos'
  ) THEN
    CREATE POLICY "Users can update own photos"
      ON storage.objects
      FOR UPDATE
      TO authenticated
      USING (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;