/*
  # Create storage bucket and policies using direct table operations

  1. Storage Setup
    - Create journal-photos bucket directly in storage.buckets table
    - Set up bucket configuration for photo uploads
    - Configure file size limits and allowed MIME types

  2. Security Policies
    - Users can upload photos to their own folder structure
    - Users can read their own photos
    - Public read access for sharing
    - Users can delete and update their own photos

  3. Direct Table Approach
    - Uses INSERT statements instead of storage functions
    - Avoids dependency on storage extension functions
    - More reliable across different Supabase configurations
*/

-- Create the storage bucket directly in the buckets table
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types, created_at, updated_at)
SELECT 
  'journal-photos',
  'journal-photos', 
  true,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/jpg'],
  now(),
  now()
WHERE NOT EXISTS (
  SELECT 1 FROM storage.buckets WHERE id = 'journal-photos'
);

-- Enable RLS on storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create storage policies for the journal-photos bucket

-- Policy for authenticated users to upload photos to their own folder
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can upload own photos'
  ) THEN
    CREATE POLICY "Users can upload own photos"
      ON storage.objects
      FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

-- Policy for authenticated users to read their own photos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can read own photos'
  ) THEN
    CREATE POLICY "Users can read own photos"
      ON storage.objects
      FOR SELECT
      TO authenticated
      USING (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

-- Policy for public read access (for sharing photos)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Public can read photos'
  ) THEN
    CREATE POLICY "Public can read photos"
      ON storage.objects
      FOR SELECT
      TO public
      USING (bucket_id = 'journal-photos');
  END IF;
END $$;

-- Policy for authenticated users to delete their own photos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can delete own photos'
  ) THEN
    CREATE POLICY "Users can delete own photos"
      ON storage.objects
      FOR DELETE
      TO authenticated
      USING (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

-- Policy for authenticated users to update their own photos
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can update own photos'
  ) THEN
    CREATE POLICY "Users can update own photos"
      ON storage.objects
      FOR UPDATE
      TO authenticated
      USING (
        bucket_id = 'journal-photos' AND
        (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;